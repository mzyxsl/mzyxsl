package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2846;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3244.class)
public class ServerGamePacketListenerImpl_interactionUpdatesMixin
{
    @Inject(method = "handleUseItemOn", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayerGameMode;useItemOn(Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/InteractionHand;Lnet/minecraft/world/phys/BlockHitResult;)Lnet/minecraft/world/InteractionResult;",
            shift = At.Shift.BEFORE
    ))
    private void beforeBlockInteracted(class_2885 playerInteractBlockC2SPacket_1, CallbackInfo ci)
    {
        if (!CarpetSettings.interactionUpdates)
            CarpetSettings.impendingFillSkipUpdates.set(true);
    }

    @Inject(method = "handleUseItemOn", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayerGameMode;useItemOn(Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/InteractionHand;Lnet/minecraft/world/phys/BlockHitResult;)Lnet/minecraft/world/InteractionResult;",
            shift = At.Shift.AFTER
    ))
    private void afterBlockInteracted(class_2885 playerInteractBlockC2SPacket_1, CallbackInfo ci)
    {
        if (!CarpetSettings.interactionUpdates)
            CarpetSettings.impendingFillSkipUpdates.set(false);
    }

    @Inject(method = "handleUseItem", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayerGameMode;useItem(Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResult;",
            shift = At.Shift.BEFORE
    ))
    private void beforeItemInteracted(class_2886 packet, CallbackInfo ci)
    {
        if (!CarpetSettings.interactionUpdates)
            CarpetSettings.impendingFillSkipUpdates.set(true);
    }

    @Inject(method = "handleUseItem", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayerGameMode;useItem(Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResult;",
            shift = At.Shift.AFTER
    ))
    private void afterItemInteracted(class_2886 packet, CallbackInfo ci)
    {
        if (!CarpetSettings.interactionUpdates)
            CarpetSettings.impendingFillSkipUpdates.set(false);
    }
    @Inject(method = "handlePlayerAction", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayerGameMode;handleBlockBreakAction(Lnet/minecraft/core/BlockPos;Lnet/minecraft/network/protocol/game/ServerboundPlayerActionPacket$Action;Lnet/minecraft/core/Direction;II)V",
            shift = At.Shift.BEFORE
    ))
    private void beforeBlockBroken(class_2846 packet, CallbackInfo ci)
    {
        if (!CarpetSettings.interactionUpdates)
            CarpetSettings.impendingFillSkipUpdates.set(true);
    }

    @Inject(method = "handlePlayerAction", at = @At(
            value = "INVOKE",
            target ="Lnet/minecraft/server/level/ServerPlayerGameMode;handleBlockBreakAction(Lnet/minecraft/core/BlockPos;Lnet/minecraft/network/protocol/game/ServerboundPlayerActionPacket$Action;Lnet/minecraft/core/Direction;II)V",
            shift = At.Shift.AFTER
    ))
    private void afterBlockBroken(class_2846 packet, CallbackInfo ci)
    {
        if (!CarpetSettings.interactionUpdates)
            CarpetSettings.impendingFillSkipUpdates.set(false);
    }

}
