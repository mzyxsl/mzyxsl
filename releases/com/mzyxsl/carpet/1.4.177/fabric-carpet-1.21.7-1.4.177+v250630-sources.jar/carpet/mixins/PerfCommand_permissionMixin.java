package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_11413;
import net.minecraft.class_11456;
import net.minecraft.class_2170;
import net.minecraft.class_6413;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_6413.class)
public class PerfCommand_permissionMixin
{
    @Redirect(method = "register", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/commands/Commands;hasPermission(I)Lnet/minecraft/server/commands/PermissionCheck;"
    ))
    private static class_11413<class_11456> canRun(int i)
    {
        return class_2170.method_71774(CarpetSettings.perfPermissionLevel);
    }

}
