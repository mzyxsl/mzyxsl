package carpet.mixins;

import carpet.CarpetSettings;
import carpet.fakes.ItemEntityInterface;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_1542;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1542.class)
public abstract class ItemEntityMixin extends class_1297 implements ItemEntityInterface
{
    @Shadow private int age;
    @Shadow private int pickupDelay;

    public ItemEntityMixin(class_1299<?> entityType_1, class_1937 world_1) {
        super(entityType_1, world_1);
    }

    @Override
    public void method_5800(class_3218 world, class_1538 lightning) {
        if (CarpetSettings.lightningKillsDropsFix) {
            if (this.age > 8) { //Only kill item if it's older than 8 ticks
                super.method_5800(world, lightning);
            }
        } else {
            super.method_5800(world, lightning);
        }
    }

    @Override
    public int getPickupDelayCM() {
        return this.pickupDelay;
    }
}
