package carpet.mixins;

import carpet.fakes.CoralFeatureInterface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Random;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2978;
import net.minecraft.class_5819;

@Mixin(class_2978.class)
public abstract class CoralFeature_renewableCoralMixin implements CoralFeatureInterface
{

    @Shadow protected abstract boolean placeFeature(class_1936 var1, class_5819 var2, class_2338 var3, class_2680 var4);

    @Override
    public boolean growSpecific(class_1937 worldIn, class_5819 random, class_2338 pos, class_2680 blockUnder)
    {
        return placeFeature(worldIn, random, pos, blockUnder);
    }
}
