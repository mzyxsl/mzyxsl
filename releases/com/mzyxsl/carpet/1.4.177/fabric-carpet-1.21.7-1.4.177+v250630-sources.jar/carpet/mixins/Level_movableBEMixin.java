package carpet.mixins;

import carpet.fakes.WorldChunkInterface;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2618;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3194;
import carpet.fakes.LevelInterface;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1937.class)
public abstract class Level_movableBEMixin implements LevelInterface, class_1936
{
    @Shadow
    @Final
    public boolean isClientSide;

    @Shadow
    public abstract class_2818 getChunkAt(class_2338 blockPos_1);
    
    @Shadow
    public abstract void setBlocksDirty(class_2338 blockPos_1, class_2680 s1, class_2680 s2);
    
    @Shadow
    public abstract void sendBlockUpdated(class_2338 var1, class_2680 var2, class_2680 var3, int var4);

    @Shadow public abstract void updateNeighbourForOutputSignal(class_2338 pos, class_2248 block);

    @Shadow public abstract boolean isDebug();

    @Shadow public abstract void updatePOIOnBlockStateChange(final class_2338 blockPos, final class_2680 blockState, final class_2680 blockState2);

    /**
     * @author 2No2Name
     */
    @Override
    public boolean setBlockStateWithBlockEntity(class_2338 blockPos_1, class_2680 blockState_1, class_2586 newBlockEntity, int int_1)
    {
        if (method_31606(blockPos_1) || !this.isClientSide && isDebug()) return false;
        class_2818 worldChunk_1 = this.getChunkAt(blockPos_1);
        class_2248 block_1 = blockState_1.method_26204();

        class_2680 blockState_2;
        if (newBlockEntity != null && block_1 instanceof class_2343)
        {
            blockState_2 = ((WorldChunkInterface) worldChunk_1).setBlockStateWithBlockEntity(blockPos_1, blockState_1, newBlockEntity, int_1);
            if (newBlockEntity instanceof class_2618)
            {
                method_64310(blockPos_1, block_1, 5);
            }
        }
        else
        {
            blockState_2 = worldChunk_1.method_12010(blockPos_1, blockState_1, int_1);
        }

        if (blockState_2 == null)
        {
            return false;
        }

        class_2680 blockState_3 = this.method_8320(blockPos_1);

        if (blockState_3 == blockState_1)
        {
            if (blockState_2 != blockState_3)
            {
                this.setBlocksDirty(blockPos_1, blockState_2, blockState_3);
            }

            if ((int_1 & 2) != 0 && (!this.isClientSide || (int_1 & 4) == 0) && (this.isClientSide || worldChunk_1.method_12225() != null && worldChunk_1.method_12225().method_14014(class_3194.field_44856)))
            {
                this.sendBlockUpdated(blockPos_1, blockState_2, blockState_1, int_1);
            }

            if (!this.isClientSide && (int_1 & 1) != 0)
            {
                this.method_8408(blockPos_1, blockState_2.method_26204());
                if (blockState_1.method_26221())
                {
                    updateNeighbourForOutputSignal(blockPos_1, block_1);
                }
            }

            if ((int_1 & 16) == 0)
            {
                int int_2 = int_1 & -34;
                blockState_2.method_30102(this, blockPos_1, int_2); // prepare
                blockState_1.method_30101(this, blockPos_1, int_2); // updateNeighbours
                blockState_1.method_30102(this, blockPos_1, int_2); // prepare
            }
            updatePOIOnBlockStateChange(blockPos_1, blockState_2, blockState_3);
        }
        return true;
    }
}
