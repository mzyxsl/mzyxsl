package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2643;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2643.class)
public class TheEndGatewayBlockEntity_creativeNoClipMixin
{
    // removeme
}
