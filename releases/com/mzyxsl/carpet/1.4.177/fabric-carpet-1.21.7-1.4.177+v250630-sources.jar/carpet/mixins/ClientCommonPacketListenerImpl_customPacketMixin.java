package carpet.mixins;

import carpet.network.CarpetClient;
import net.minecraft.class_2658;
import net.minecraft.class_8673;
import net.minecraft.class_9812;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_8673.class)
public class ClientCommonPacketListenerImpl_customPacketMixin
{
    @Inject(method = "onDisconnect", at = @At("HEAD"))
    private void onCMDisconnected(class_9812 reason, CallbackInfo ci)
    {
        CarpetClient.disconnect();
    }

    @Inject(method = "handleCustomPayload(Lnet/minecraft/network/protocol/common/ClientboundCustomPayloadPacket;)V",
    at = @At("HEAD"))
    private void onOnCustomPayload(class_2658 packet, CallbackInfo ci)
    {
        //System.out.println("CustomPayload of : " + packet.payload());
    }

}
