package carpet.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import carpet.CarpetSettings;
import net.minecraft.class_1936;
import net.minecraft.class_2247;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

@Mixin(class_2247.class)
public class BlockInput_fillUpdatesMixin
{
    @Redirect(method = "place", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/block/Block;updateFromNeighbourShapes(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState;"
    ))
    private class_2680 postProcessStateProxy(class_2680 state, class_1936 serverWorld, class_2338 blockPos)
    {
        if (CarpetSettings.impendingFillSkipUpdates.get())
        {
            return state;
        }
        
        return class_2248.method_9510(state, serverWorld, blockPos);
    }
}
