package carpet.mixins;

import carpet.fakes.BlockStateArgumentInterface;
import net.minecraft.class_2247;
import net.minecraft.class_2487;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_2247.class)
public class BlockInput_scarpetMixin implements BlockStateArgumentInterface
{
    @Shadow @Final private @Nullable class_2487 tag;

    @Override
    public class_2487 getCMTag()
    {
        return tag;
    }
}
