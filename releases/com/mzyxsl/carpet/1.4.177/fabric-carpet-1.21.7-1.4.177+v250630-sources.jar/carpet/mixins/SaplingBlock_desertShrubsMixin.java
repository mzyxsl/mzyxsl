package carpet.mixins;

import carpet.CarpetSettings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;
import net.minecraft.class_1936;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2473;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3486;
import net.minecraft.class_5819;
import net.minecraft.class_6908;

@Mixin(class_2473.class)
public abstract class SaplingBlock_desertShrubsMixin
{
    @Inject(method = "advanceTree", at = @At(value = "INVOKE", shift = At.Shift.BEFORE,
            target = "Lnet/minecraft/world/level/block/grower/TreeGrower;growTree(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/level/chunk/ChunkGenerator;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/util/RandomSource;)Z"),
            cancellable = true)
    private void onGenerate(class_3218 level, class_2338 pos, class_2680 blockState, class_5819 random, CallbackInfo ci)
    {
        if (CarpetSettings.desertShrubs && level.method_23753(pos).method_40220(class_6908.field_36520) && !nearWater(level, pos))
        {
            level.method_8652(pos, class_2246.field_10428.method_9564(), class_2248.field_31036);
            ci.cancel();
        }
    }

    @Unique
    private static boolean nearWater(class_1936 level, class_2338 pos)
    {
        for (class_2338 blockPos : class_2338.method_10097(pos.method_10069(-4, -4, -4), pos.method_10069(4, 1, 4)))
        {
            if (level.method_8316(blockPos).method_15767(class_3486.field_15517))
            {
                return true;
            }
        }

        return false;
    }
}
