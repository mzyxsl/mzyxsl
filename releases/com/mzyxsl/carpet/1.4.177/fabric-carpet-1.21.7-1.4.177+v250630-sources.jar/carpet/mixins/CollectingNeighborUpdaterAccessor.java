package carpet.mixins;

import net.minecraft.class_7159;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_7159.class)
public interface CollectingNeighborUpdaterAccessor {
    @Accessor("count")
    void setCount(int count);
    @Accessor("maxChainedNeighborUpdates")
    int getMaxChainedNeighborUpdates();
}
