package carpet.mixins;

import carpet.network.CarpetClient;
import carpet.network.ClientNetworkHandler;
import net.minecraft.class_2535;
import net.minecraft.class_2678;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_8673;
import net.minecraft.class_8675;
import net.minecraft.class_8710;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public abstract class ClientPacketListener_customPacketsMixin extends class_8673
{

    protected ClientPacketListener_customPacketsMixin(final class_310 minecraft, final class_2535 connection, final class_8675 commonListenerCookie)
    {
        super(minecraft, connection, commonListenerCookie);
    }

    @Inject(method = "handleLogin", at = @At("RETURN"))
    private void onGameJoined(class_2678 packet, CallbackInfo info)
    {
        CarpetClient.gameJoined( field_45588.field_1724);
    }

    @Inject(method = "handleUnknownCustomPayload", at = @At(
            value = "HEAD"
            ), cancellable = true)
    private void onOnCustomPayload(class_8710 packet, CallbackInfo ci)
    {
        if (packet instanceof CarpetClient.CarpetPayload cpp)
        {
            ClientNetworkHandler.onServerData(cpp.data(), field_45588.field_1724);
            ci.cancel();
        }
    }

}
