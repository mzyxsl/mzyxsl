package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_3486;
import net.minecraft.class_3609;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2404.class)
public abstract class LiquidBlock_renewableBlackstoneMixin
{
    @Shadow @Final protected class_3609 fluid;

    @Shadow protected abstract void fizz(class_1936 world, class_2338 pos);

    @Inject(method = "shouldSpreadLiquid", at = @At("TAIL"), cancellable = true)
    private void receiveFluidToBlackstone(class_1937 world, class_2338 pos, class_2680 state, CallbackInfoReturnable<Boolean> cir)
    {
        if (CarpetSettings.renewableBlackstone)
        {
            if (fluid.method_15791(class_3486.field_15518)) {
                for(class_2350 direction : class_2350.values())
                {
                    if (direction != class_2350.field_11033) {
                        class_2338 blockPos = pos.method_10093(direction); // offset
                        if (world.method_8320(blockPos).method_27852(class_2246.field_10384)) {
                            world.method_8501(pos, class_2246.field_23869.method_9564());
                            fizz(world, pos);
                            cir.setReturnValue(false);
                        }
                    }
                }
            }
        }
    }
}
