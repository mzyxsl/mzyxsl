package carpet.mixins;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1927;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_9892;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import static carpet.script.CarpetEventServer.Event.EXPLOSION_OUTCOME;

@Mixin(value = class_9892.class, priority = 990)
public abstract class Explosion_scarpetEventMixin
{
    @Shadow @Final private class_3218 level;
    @Shadow @Final private class_243 center;
    @Shadow @Final private float radius;
    @Shadow @Final private boolean fire;
    @Shadow @Final private class_1927.class_4179 blockInteraction;
    @Shadow @Final private @Nullable class_1297 source;

    @Shadow /*@Nullable*/ public abstract /*@Nullable*/ class_1309 getIndirectSourceEntity();

    private List<class_1297> affectedEntities = new ArrayList<>();

    @Inject(method = "explode", at = @At("HEAD"))
    private void explodeCM(CallbackInfo ci)
    {
        affectedEntities.clear();
    }

    @Redirect(method = "hurtEntities", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;onExplosionHit(Lnet/minecraft/world/entity/Entity;)V"))
    private void onEntityHit(class_1297 instance, class_1297 entity)
    {
        affectedEntities.add(instance);
        instance.method_56918(entity);
    }

    @Inject(method = "explode", locals = LocalCapture.CAPTURE_FAILHARD, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/ServerExplosion;hurtEntities()V", shift = At.Shift.AFTER))
    private void onExplosionDone(CallbackInfo ci, List list)
    {
        if (EXPLOSION_OUTCOME.isNeeded() && !level.method_8608())
        {
            EXPLOSION_OUTCOME.onExplosion((class_3218) level, source, this::getIndirectSourceEntity, center, radius, fire, list, affectedEntities, blockInteraction);
        }
    }
}
