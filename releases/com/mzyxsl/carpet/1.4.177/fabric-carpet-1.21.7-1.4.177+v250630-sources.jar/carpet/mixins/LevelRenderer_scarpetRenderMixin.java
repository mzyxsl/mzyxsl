package carpet.mixins;

import carpet.network.CarpetClient;
import carpet.script.utils.ShapesRenderer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4599;
import net.minecraft.class_761;
import net.minecraft.class_824;
import net.minecraft.class_898;
import net.minecraft.class_9909;
import net.minecraft.class_9916;
import net.minecraft.class_9960;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class LevelRenderer_scarpetRenderMixin
{
    @Shadow @Final private class_9960 targets;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void addRenderers(class_310 minecraft, class_898 entityRenderDispatcher, class_824 blockEntityRenderDispatcher, class_4599 renderBuffers, CallbackInfo ci)
    {
        CarpetClient.shapes = new ShapesRenderer(minecraft);
    }

    @Inject(method = "addParticlesPass", at = @At("RETURN"))
    private void renderScarpetThingsLate(class_9909 frameGraphBuilder, class_4184 camera, float f, GpuBufferSlice fogParameters, CallbackInfo ci)
    {
        // in normal circumstances we want to render shapes at the very end so it appears correctly behind stuff.
        // we might actually not need to play with render hooks here.
        //if (!FabricAPIHooks.WORLD_RENDER_EVENTS && CarpetClient.shapes != null )
        if (CarpetClient.shapes != null)
        {
            class_9916 pass = frameGraphBuilder.method_61911("scarpet_shapes");
            targets.field_53091 = pass.method_61933(targets.field_53091);
            pass.method_61929(() -> CarpetClient.shapes.render(null, camera, f));
        }
    }
}
