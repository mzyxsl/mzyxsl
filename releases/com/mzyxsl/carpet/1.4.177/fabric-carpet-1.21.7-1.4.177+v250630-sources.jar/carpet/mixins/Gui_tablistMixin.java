package carpet.mixins;

import carpet.fakes.PlayerListHudInterface;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_355;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_329.class)
public abstract class Gui_tablistMixin
{
    @Shadow
    @Final
    private class_310 minecraft;

    @Shadow @Final private class_355 tabList;

    @Redirect(method = "renderTabList", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;isLocalServer()Z"))
    private boolean onDraw(class_310 minecraftClient)
    {
        return this.minecraft.method_1542() && !((PlayerListHudInterface) tabList).hasFooterOrHeader();
    }

}
