package carpet.mixins;

import carpet.CarpetServer;
import carpet.network.ServerNetworkHandler;
import net.minecraft.class_2535;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_8792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3324.class)
public class PlayerList_coreMixin
{

    @Inject(method = "placeNewPlayer", at = @At("RETURN"))
    private void onPlayerConnected(class_2535 connection, class_3222 player, class_8792 i, CallbackInfo ci)
    {
        CarpetServer.onPlayerLoggedIn(player);
    }

    @Inject(method = "sendLevelInfo", at = @At("RETURN"))
    private void onLevelChanged(final class_3222 serverPlayer, final class_3218 serverLevel, final CallbackInfo ci)
    {
        ServerNetworkHandler.sendPlayerLevelData(serverPlayer, serverLevel);
    }
}
