package carpet.mixins;

import carpet.fakes.TicketsFetcherInterface;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;
import net.minecraft.class_10592;
import net.minecraft.class_3228;

@Mixin(class_10592.class)
public class TicketStorage_scarpetMixin implements TicketsFetcherInterface
{
    @Shadow @Final private Long2ObjectOpenHashMap<List<class_3228>> tickets;

    @Override
    public Long2ObjectOpenHashMap<List<class_3228>> getTicketsByPosition()
    {
        return tickets;
    }
}
