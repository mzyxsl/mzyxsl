package carpet.mixins;

import carpet.helpers.CarpetTaintedList;
import carpet.network.CarpetClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

@Mixin(class_8710.class)
public interface CustomPacketPayload_networkStuffMixin
{
    @Inject(method = "codec(Lnet/minecraft/network/protocol/common/custom/CustomPacketPayload$FallbackProvider;Ljava/util/List;)Lnet/minecraft/network/codec/StreamCodec;", at = @At("HEAD"), cancellable = true)
    private static <B extends class_2540> void onCodec(final class_8710.class_9153<B> fallbackProvider, final List<class_8710.class_9155<? super B, ?>> list, final CallbackInfoReturnable<class_9139<B, class_8710>> cir)
    {
        // this is stupid hack to make sure carpet payloads are always registered
        // that might collide with other mods that do the same thing
        // so we may need to adjust this in the future
        if (!(list instanceof CarpetTaintedList))
        {
            List<class_8710.class_9155<? super B, ?>> extendedList = new CarpetTaintedList<>(list);
            extendedList.add(new class_8710.class_9155<>(CarpetClient.CarpetPayload.TYPE, CarpetClient.CarpetPayload.STREAM_CODEC));
            cir.setReturnValue(class_8710.method_56485(fallbackProvider, extendedList));
        }
    }
}
