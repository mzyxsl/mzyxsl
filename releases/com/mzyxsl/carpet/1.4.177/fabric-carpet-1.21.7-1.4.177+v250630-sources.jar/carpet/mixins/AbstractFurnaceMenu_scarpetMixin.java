package carpet.mixins;

import carpet.fakes.AbstractContainerMenuInterface;
import net.minecraft.class_1661;
import net.minecraft.class_1720;
import net.minecraft.class_1729;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8786;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1720.class)
public class AbstractFurnaceMenu_scarpetMixin
{
    @Inject(method = "handlePlacement",at = @At("HEAD"), cancellable = true)
    private void selectRecipeCallback(boolean craftAll, boolean b, class_8786<?> recipe, class_3218 level, class_1661 player, CallbackInfoReturnable<class_1729.class_9885> cir) {
        if(((AbstractContainerMenuInterface) this).callSelectRecipeListener((class_3222) player.field_7546 ,recipe,craftAll))
            cir.setReturnValue(class_1729.class_9885.field_52572);
    }
}
