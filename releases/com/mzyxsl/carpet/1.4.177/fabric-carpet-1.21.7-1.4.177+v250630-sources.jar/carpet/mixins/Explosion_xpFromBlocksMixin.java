package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_4970.class)
public class Explosion_xpFromBlocksMixin {

    @Redirect(method = "onExplosionHit", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/block/state/BlockState;spawnAfterBreak(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/item/ItemStack;Z)V"
    ))
    private void spawnXPAfterBreak(class_2680 instance, class_3218 serverLevel, class_2338 blockPos, class_1799 itemStack, boolean b)
    {
        instance.method_26180(serverLevel, blockPos, itemStack, b || CarpetSettings.xpFromExplosions);
    }
}
