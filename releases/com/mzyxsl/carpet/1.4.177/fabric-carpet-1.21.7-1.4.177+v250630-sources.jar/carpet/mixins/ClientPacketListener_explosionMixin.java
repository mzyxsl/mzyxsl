package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_243;
import net.minecraft.class_2535;
import net.minecraft.class_2664;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_8673;
import net.minecraft.class_8675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public abstract class ClientPacketListener_explosionMixin extends class_8673
{

    private static class_243 vec3dmem;
    private static long tickmem;
    // For disabling the explosion particles and sounds if explosions are stacking up

    protected ClientPacketListener_explosionMixin(final class_310 minecraft, final class_2535 connection, final class_8675 commonListenerCookie)
    {
        super(minecraft, connection, commonListenerCookie);
    }


    @Inject(method = "handleExplosion", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/multiplayer/ClientLevel;playLocalSound(DDDLnet/minecraft/sounds/SoundEvent;Lnet/minecraft/sounds/SoundSource;FFZ)V"
    ), cancellable = true)
    private void onHandleExplosion(final class_2664 clientboundExplodePacket, final CallbackInfo ci)
    {

        if (CarpetSettings.optimizedTNT)
        {
            class_243 vec3d = clientboundExplodePacket.comp_2883();
            long tick = field_45588.field_1687.method_8510();
            if (vec3dmem == null || !vec3dmem.equals(vec3d) || tickmem != tick) {
                vec3dmem = vec3d;
                tickmem = tick;
            } else {
                ci.cancel();
            }
        }
    }
}
