package carpet.mixins;

import carpet.fakes.BlockPredicateInterface;
import carpet.script.value.StringValue;
import carpet.script.value.Value;
import carpet.script.value.ValueConversions;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.class_2248;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_6862;

@Mixin(targets = "net.minecraft.commands.arguments.blocks.BlockPredicateArgument$BlockPredicate")
public class BlockPredicate_scarpetMixin implements BlockPredicateInterface
{

    @Shadow @Final private class_2680 state;

    @Shadow @Final /*@Nullable*/ private class_2487 nbt;

    @Shadow @Final private Set<class_2769<?>> properties;

    @Override
    public class_2680 getCMBlockState()
    {
        return state;
    }

    @Override
    public class_6862<class_2248> getCMBlockTagKey()
    {
        return null;
    }

    @Override
    public Map<Value, Value> getCMProperties()
    {
        return properties.stream().collect(Collectors.toMap(
                p -> StringValue.of(p.method_11899()),
                p -> ValueConversions.fromProperty(state, p),
                (a, b) -> b
        ));
    }

    @Override
    public class_2487 getCMDataTag()
    {
        return nbt;
    }
}
