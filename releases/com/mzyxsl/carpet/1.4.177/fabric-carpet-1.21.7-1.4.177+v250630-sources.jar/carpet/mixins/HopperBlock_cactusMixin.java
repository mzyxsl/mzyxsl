package carpet.mixins;

import carpet.helpers.BlockRotator;
import net.minecraft.class_1750;
import net.minecraft.class_2350;
import net.minecraft.class_2377;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_2377.class)
public class HopperBlock_cactusMixin
{
    @Redirect(method = "getStateForPlacement", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/item/context/BlockPlaceContext;getClickedFace()Lnet/minecraft/core/Direction;"
    ))
    private class_2350 getOppositeOpposite(class_1750 context)
    {
        if (BlockRotator.flippinEligibility(context.method_8036()))
        {
            return context.method_8038().method_10153();
        }
        return context.method_8038();
    }
}
