package carpet.mixins;

import carpet.CarpetSettings;
import carpet.fakes.LevelInterface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1301;
import net.minecraft.class_1309;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_3218;

@Mixin(class_1309.class)
public abstract class LivingEntity_maxCollisionsMixin extends class_1297
{

    public LivingEntity_maxCollisionsMixin(class_1299<?> entityType_1, class_1937 world_1)
    {
        super(entityType_1, world_1);
    }

    @Shadow protected abstract void doPush(class_1297 entity_1);

    @Inject(method = "pushEntities", cancellable = true, at = @At("HEAD"))
    private void tickPushingReplacement(CallbackInfo ci) {
        if (CarpetSettings.maxEntityCollisions == 0)
        {
            return;
        }

        if (!(this.method_37908() instanceof class_3218 serverLevel))
        {
            return;
        }

        List<class_1297> entities;
        int maxEntityCramming =-1;
        if (CarpetSettings.maxEntityCollisions > 0)
        {
            maxEntityCramming = serverLevel.method_64395().method_8356(class_1928.field_19405);
            entities = ((LevelInterface) serverLevel).getOtherEntitiesLimited(
                    this,
                    this.method_5829(),
                    class_1301.method_5911(this),
                    Math.max(CarpetSettings.maxEntityCollisions, maxEntityCramming));
        }
        else
        {
            entities = serverLevel.method_8333(this, this.method_5829(), class_1301.method_5911(this));
        }

        if (!entities.isEmpty()) {
            if (maxEntityCramming < 0) maxEntityCramming = serverLevel.method_64395().method_8356(class_1928.field_19405);
            if (maxEntityCramming > 0 && entities.size() > maxEntityCramming - 1 && this.field_5974.method_43048(4) == 0) {
                int candidates = 0;

                for (class_1297 entity : entities) {
                    if (!entity.method_5765()) {
                        ++candidates;
                    }
                }

                if (candidates > maxEntityCramming - 1) {
                    this.method_64419(method_48923().method_48823(), 6.0F);
                }
            }
            if (CarpetSettings.maxEntityCollisions > 0 && entities.size() > CarpetSettings.maxEntityCollisions)
            {
                for (class_1297 entity : entities.subList(0, CarpetSettings.maxEntityCollisions))
                {
                    this.doPush(entity);
                }
            }
            else
            {
                for (class_1297 entity : entities)
                {
                    this.doPush(entity);
                }
            }
        }
        ci.cancel();
    }


}
