package carpet.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import static carpet.script.CarpetEventServer.Event.PLAYER_PLACES_BLOCK;
import static carpet.script.CarpetEventServer.Event.PLAYER_PLACING_BLOCK;

import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_2680;
import net.minecraft.class_3222;

@Mixin(class_1747.class)
public class BlockItem_scarpetEventMixin
{
    @Inject(method = "place(Lnet/minecraft/world/item/context/BlockPlaceContext;)Lnet/minecraft/world/InteractionResult;", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/block/Block;setPlacedBy(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;)V",
            shift = At.Shift.AFTER
    ))
    private void afterPlacement(class_1750 context, CallbackInfoReturnable<class_1269> cir)
    {
        if (context.method_8036() instanceof class_3222 && PLAYER_PLACES_BLOCK.isNeeded())
            PLAYER_PLACES_BLOCK.onBlockPlaced((class_3222) context.method_8036(), context.method_8037(), context.method_20287(), context.method_8041());
    }
    
    @Inject(method = "placeBlock", at = @At("HEAD"), cancellable = true)
    private void beforePlacement(class_1750 context, class_2680 placementState, CallbackInfoReturnable<Boolean> cir) {
        if (context.method_8036() instanceof class_3222 && PLAYER_PLACING_BLOCK.isNeeded()) {
            if (PLAYER_PLACING_BLOCK.onBlockPlaced((class_3222) context.method_8036(), context.method_8037(), context.method_20287(), context.method_8041())) {
                cir.setReturnValue(false);
                cir.cancel();
            }
        }
    }
}
