package carpet.mixins;

import carpet.fakes.DefaultRedstoneWireEvaluatorInferface;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_9901;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_9901.class)
public abstract class DefaultRedstoneWireEvaluator_redstoneMixin implements DefaultRedstoneWireEvaluatorInferface
{
    @Shadow protected abstract int calculateTargetStrength(final class_1937 level, final class_2338 blockPos);

    @Override
    public int calculateTargetStrengthCM(final class_1937 level, final class_2338 pos)
    {
        return calculateTargetStrength(level, pos);
    }
}
