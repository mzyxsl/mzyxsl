package carpet.mixins;

import carpet.fakes.TicketsFetcherInterface;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;
import net.minecraft.class_10592;
import net.minecraft.class_3204;
import net.minecraft.class_3228;

@Mixin(class_3204.class)
public abstract class DistanceManager_scarpetMixin implements TicketsFetcherInterface
{
    @Shadow @Final private class_10592 ticketStorage;

    @Override
    public Long2ObjectOpenHashMap<List<class_3228>>  getTicketsByPosition()
    {
        return ((TicketsFetcherInterface)ticketStorage).getTicketsByPosition();
    }

}
