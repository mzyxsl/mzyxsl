package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2384;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2384.class)
public abstract class InfestedBlock_gravelMixin extends class_2248
{
    public InfestedBlock_gravelMixin(class_2251 block$Settings_1)
    {
        super(block$Settings_1);
    }

    @Inject(method = "spawnInfestation", at = @At(value = "INVOKE", shift = At.Shift.AFTER,
            target = "Lnet/minecraft/world/entity/monster/Silverfish;spawnAnim()V"))
    private void onOnStacksDropped(class_3218 serverWorld, class_2338 pos, CallbackInfo ci)
    {
        if (CarpetSettings.silverFishDropGravel)
        {
            method_9577(serverWorld, pos, new class_1799(class_2246.field_10255));
        }
    }
}