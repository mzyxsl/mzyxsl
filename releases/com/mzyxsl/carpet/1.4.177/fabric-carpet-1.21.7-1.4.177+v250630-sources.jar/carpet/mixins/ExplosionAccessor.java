package carpet.mixins;

import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_9892;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_9892.class)
public interface ExplosionAccessor {

    @Accessor
    class_3218 getLevel();

    @Accessor
    class_243 getCenter();

    @Accessor
    float getRadius();

    @Accessor
    class_1297 getSource();

    @Accessor
    class_1282 getDamageSource();

}
