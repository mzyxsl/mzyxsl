package carpet.mixins;

import carpet.CarpetServer;
import carpet.network.CarpetClient;
import net.minecraft.class_2535;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_746;
import net.minecraft.class_8673;
import net.minecraft.class_8675;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public abstract class ClientPacketListener_clientCommandMixin extends class_8673
{

    protected ClientPacketListener_clientCommandMixin(final class_310 minecraft, final class_2535 connection, final class_8675 commonListenerCookie)
    {
        super(minecraft, connection, commonListenerCookie);
    }

    @Inject(method = "sendCommand", at = @At("HEAD"))
    private void inspectMessage(String string, CallbackInfo ci)
    {
        if (string.startsWith("call "))
        {
            String command = string.substring(5);
            CarpetClient.sendClientCommand(command);
        }
        if (CarpetServer.minecraft_server == null && !CarpetClient.isCarpet() && field_45588.field_1724 != null)
        {
            class_746 playerSource = field_45588.field_1724;
            CarpetServer.forEachManager(sm -> sm.inspectClientsideCommand("/" + string));
        }
    }
}
