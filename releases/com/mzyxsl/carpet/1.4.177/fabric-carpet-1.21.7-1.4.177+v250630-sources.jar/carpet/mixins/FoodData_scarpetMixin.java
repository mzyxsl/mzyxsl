package carpet.mixins;

import carpet.fakes.FoodDataInterface;
import net.minecraft.class_1702;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1702.class)
public class FoodData_scarpetMixin implements FoodDataInterface
{
    @Shadow private float exhaustionLevel;

    @Override
    public float getCMExhaustionLevel()
    {
        return exhaustionLevel;
    }

    @Override
    public void setExhaustion(float aFloat)
    {
        exhaustionLevel = aFloat;
    }
}
