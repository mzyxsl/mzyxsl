package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1299;
import net.minecraft.class_1538;
import net.minecraft.class_1550;
import net.minecraft.class_1577;
import net.minecraft.class_1588;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1577.class)
public abstract class Guardian_renewableSpongesMixin extends class_1588
{
    protected Guardian_renewableSpongesMixin(class_1299<? extends class_1588> entityType_1, class_1937 world_1)
    {
        super(entityType_1, world_1);
    }

    @Override
    public void method_5800(class_3218 serverWorld, class_1538 lightningEntity)
    {                                // isRemoved()
        if (!this.method_37908().field_9236 && !this.method_31481() && CarpetSettings.renewableSponges && !((Object)this instanceof class_1550))
        {
            class_1550 elderGuardian = new class_1550(class_1299.field_6086 ,this.method_37908());
            elderGuardian.method_5808(this.method_23317(), this.method_23318(), this.method_23321(), this.method_36454(), this.method_36455());
            elderGuardian.method_5943(serverWorld ,this.method_37908().method_8404(elderGuardian.method_24515()), class_3730.field_16468, null);
            elderGuardian.method_5977(this.method_5987());
            
            if (this.method_16914())
            {
                elderGuardian.method_5665(this.method_5797());
                elderGuardian.method_5880(this.method_5807());
            }
            
            this.method_37908().method_8649(elderGuardian);
            this.method_31472(); // discard remove();
        }
        else
        {
            super.method_5800(serverWorld, lightningEntity);
        }
    }
}
