package carpet.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import carpet.helpers.QuasiConnectivity;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2665;
import net.minecraft.class_8235;

@Mixin(class_2665.class)
public class PistonBaseBlock_qcMixin {

    @Inject(
        method = "getNeighborSignal",
        cancellable = true,
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/core/BlockPos;above()Lnet/minecraft/core/BlockPos;"
        )
    )
    private void carpet_checkQuasiSignal(class_8235 level, class_2338 pos, class_2350 facing, CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(QuasiConnectivity.hasQuasiSignal(level, pos));
    }
}
