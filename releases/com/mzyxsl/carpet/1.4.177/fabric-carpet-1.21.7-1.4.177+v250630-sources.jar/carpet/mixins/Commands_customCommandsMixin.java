package carpet.mixins;

import carpet.CarpetServer;
import carpet.CarpetSettings;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.ParseResults;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_7157;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2170.class)
public abstract class Commands_customCommandsMixin
{

    @Shadow
    @Final
    private CommandDispatcher<class_2168> dispatcher;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void onRegister(class_2170.class_5364 commandSelection, class_7157 commandBuildContext, CallbackInfo ci) {
        CarpetServer.registerCarpetCommands(this.dispatcher, commandSelection, commandBuildContext);
    }

    @Inject(method = "performCommand", at = @At("HEAD"))
    private void onExecuteBegin(ParseResults<class_2168> parseResults, String string, CallbackInfo ci)
    {
        if (!CarpetSettings.fillUpdates)
            CarpetSettings.impendingFillSkipUpdates.set(true);
    }

    @Inject(method = "performCommand", at = @At("RETURN"))
    private void onExecuteEnd(ParseResults<class_2168> parseResults, String string, CallbackInfo ci)
    {
        CarpetSettings.impendingFillSkipUpdates.set(false);
    }

    @Redirect(method = "performCommand", at = @At(
                value = "INVOKE",
                target = "Lorg/slf4j/Logger;isDebugEnabled()Z",
                remap = false
            ),
        require = 0
    )
    private boolean doesOutputCommandStackTrace(Logger logger)
    {
        if (CarpetSettings.superSecretSetting)
            return true;
        return logger.isDebugEnabled();
    }
}
