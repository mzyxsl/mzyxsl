package carpet.mixins;

import carpet.fakes.AbstractContainerMenuInterface;
import carpet.script.value.ScreenValue;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1712;
import net.minecraft.class_1713;
import net.minecraft.class_3222;
import net.minecraft.class_3915;
import net.minecraft.class_8786;

@Mixin(class_1703.class)
public abstract class AbstractContainerMenu_scarpetMixin implements AbstractContainerMenuInterface
{
    @Shadow @Final private List<class_1712> containerListeners;
    @Shadow public abstract void sendAllDataToRemote();
    @Shadow @Final private List<class_3915> dataSlots;

    @Inject(method = "doClick", at = @At("HEAD"), cancellable = true)
    private void callSlotClickListener(int slotIndex, int button, class_1713 actionType, class_1657 player, CallbackInfo ci) {
        if(!(player instanceof class_3222 serverPlayerEntity)) return;
        for(class_1712 screenHandlerListener : this.containerListeners) {
            if(screenHandlerListener instanceof ScreenValue.ScarpetScreenHandlerListener scarpetScreenHandlerListener) {
                if(scarpetScreenHandlerListener.onSlotClick(serverPlayerEntity, actionType, slotIndex, button)) {
                    ci.cancel();
                    sendAllDataToRemote();
                }
            }
        }
    }

    @Inject(method = "removed", at = @At("HEAD"), cancellable = true)
    private void callCloseListener(class_1657 player, CallbackInfo ci) {
        if(!(player instanceof class_3222 serverPlayerEntity)) return;
        for(class_1712 screenHandlerListener : this.containerListeners) {
            if(screenHandlerListener instanceof ScreenValue.ScarpetScreenHandlerListener scarpetScreenHandlerListener) {
                scarpetScreenHandlerListener.onClose(serverPlayerEntity);
            }
        }
    }

    @Override
    public boolean callButtonClickListener(int button, class_1657 player) {
        if(!(player instanceof class_3222 serverPlayerEntity)) return false;
        for(class_1712 screenHandlerListener : containerListeners) {
            if(screenHandlerListener instanceof ScreenValue.ScarpetScreenHandlerListener scarpetScreenHandlerListener) {
                if(scarpetScreenHandlerListener.onButtonClick(serverPlayerEntity, button))
                    return true;
            }
        }
        return false;
    }

    @Override
    public boolean callSelectRecipeListener(class_3222 player, class_8786<?> recipe, boolean craftAll) {
        for(class_1712 screenHandlerListener : containerListeners) {
            if(screenHandlerListener instanceof ScreenValue.ScarpetScreenHandlerListener scarpetScreenHandlerListener) {
                if(scarpetScreenHandlerListener.onSelectRecipe(player, recipe, craftAll))
                    return true;
            }
        }
        return false;
    }

    @Override
    public class_3915 getDataSlot(int index) {
        return this.dataSlots.get(index);
    }
}