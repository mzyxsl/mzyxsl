package carpet.mixins;


import carpet.CarpetSettings;
import net.minecraft.class_5704;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5704.class_8241.class)
public class SculkSensorBlockEntityVibrationConfig_sculkSensorRangeMixin
{
    @Inject(method = "getListenerRadius", at = @At("HEAD"), cancellable = true)
    private void sculkSensorRange(CallbackInfoReturnable<Integer> cir)
    {
        if (CarpetSettings.sculkSensorRange != class_5704.class_8241.field_43292) {
            cir.setReturnValue(CarpetSettings.sculkSensorRange);
        }
    }
}
