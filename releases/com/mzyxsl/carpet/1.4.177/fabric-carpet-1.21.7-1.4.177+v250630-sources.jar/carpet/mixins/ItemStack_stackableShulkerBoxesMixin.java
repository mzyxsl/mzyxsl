package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2480;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1799.class)
public class ItemStack_stackableShulkerBoxesMixin
{
    @Inject(method = "getMaxStackSize", at = @At("HEAD"), cancellable = true)
    private void getCMMAxStackSize(CallbackInfoReturnable<Integer> cir)
    {
        if (CarpetSettings.shulkerBoxStackSize > 1
                && ((class_1799)((Object)this)).method_7909() instanceof class_1747 blockItem
                && blockItem.method_7711() instanceof class_2480
                && ((class_1799) ((Object) this)).method_58695(class_9334.field_49622, class_9288.field_49334).method_57489().findAny().isEmpty()
        ) {
            cir.setReturnValue(CarpetSettings.shulkerBoxStackSize);
        }
    }
}
