package carpet.mixins;

import carpet.CarpetSettings;
import carpet.utils.SpawnOverrides;
import net.minecraft.class_1576;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_5425;
import net.minecraft.class_7058;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1576.class)
public class Husk_templesMixin
{
    @Redirect(method = "checkHuskSpawnRules", at = @At(value = "INVOKE", target="Lnet/minecraft/world/level/ServerLevelAccessor;canSeeSky(Lnet/minecraft/core/BlockPos;)Z"))
    private static boolean isSkylightOrTempleVisible(class_5425 serverWorldAccess, class_2338 pos)
    {
        return serverWorldAccess.method_8311(pos) ||
                (CarpetSettings.huskSpawningInTemples && SpawnOverrides.isStructureAtPosition((class_3218)serverWorldAccess, class_7058.field_37173, pos));
    }
}
