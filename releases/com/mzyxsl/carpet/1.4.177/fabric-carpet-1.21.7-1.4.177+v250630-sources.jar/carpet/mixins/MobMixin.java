package carpet.mixins;

import carpet.fakes.MobEntityInterface;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1308;
import net.minecraft.class_1352;
import net.minecraft.class_1355;

@Mixin(class_1308.class)
public abstract class MobMixin implements MobEntityInterface
{
    @Shadow @Final protected class_1355 targetSelector;
    @Shadow @Final protected class_1355 goalSelector;
    @Shadow private boolean persistenceRequired;
    public final Map<String, class_1352> temporaryTasks = new HashMap<>();

    @Override
    public class_1355 getAI(boolean target)
    {
        return target?targetSelector:goalSelector;
    }

    @Override
    public Map<String, class_1352> getTemporaryTasks()
    {
        return temporaryTasks;
    }

    @Override
    public void setPersistence(boolean what)
    {
        persistenceRequired = what;
    }
}
