package carpet.mixins;

import carpet.network.CarpetClient;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftMixin
{
    @Shadow public class_638 level;
    
    @Inject(method = "disconnect(Lnet/minecraft/client/gui/screens/Screen;Z)V", at = @At("HEAD"))
    private void onCloseGame(class_437 screen, boolean b, CallbackInfo ci)
    {
        CarpetClient.disconnect();
    }
    
    @Inject(at = @At("HEAD"), method = "tick")
    private void onClientTick(CallbackInfo info) {
        if (this.level != null) {
            boolean runsNormally = level.method_54719().method_54751();
            // hope server doesn't need to tick - should be handled by the server on its own
            if (!runsNormally)
                CarpetClient.shapes.renewShapes();
        }
    }
}
