package carpet.mixins;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static carpet.script.CarpetEventServer.Event.PLAYER_TRADES;

import net.minecraft.class_1657;
import net.minecraft.class_1725;
import net.minecraft.class_1727;
import net.minecraft.class_1799;
import net.minecraft.class_1915;
import net.minecraft.class_3222;

@Mixin(class_1727.class)
public abstract class MerchantResultSlot_scarpetEventMixin {
    @Shadow @Final private class_1915 merchant;

    @Shadow @Final private class_1725 slots;

    @Inject(method = "onTake", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/item/trading/Merchant;notifyTrade(Lnet/minecraft/world/item/trading/MerchantOffer;)V")
    )
    private void onTrade(class_1657 player, class_1799 stack, CallbackInfo ci) {
        if(PLAYER_TRADES.isNeeded() && !player.method_37908().method_8608())
        {
            PLAYER_TRADES.onTrade((class_3222) player, merchant, slots.method_7642());
        }
    }
}
