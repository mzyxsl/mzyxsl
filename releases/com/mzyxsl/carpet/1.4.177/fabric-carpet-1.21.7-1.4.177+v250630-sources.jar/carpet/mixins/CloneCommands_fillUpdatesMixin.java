package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3023;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_3023.class)
public abstract class CloneCommands_fillUpdatesMixin
{
    @Redirect(method = "clone", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerLevel;updateNeighboursOnBlockSet(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V"
    ))
    private static void conditionalUpdating(class_3218 serverWorld, class_2338 blockPos_1, class_2680 block_1)
    {
        if (CarpetSettings.fillUpdates) serverWorld.method_70635(blockPos_1, block_1);
    }
}
