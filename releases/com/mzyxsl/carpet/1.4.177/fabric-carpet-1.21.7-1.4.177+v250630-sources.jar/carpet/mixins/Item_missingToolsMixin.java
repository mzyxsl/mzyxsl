package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3489;
import net.minecraft.class_9334;
import net.minecraft.class_9424;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1792.class)
public class Item_missingToolsMixin
{
    @Inject(method = "getDestroySpeed", at = @At("HEAD"), cancellable = true)
    public void getDestroySpeed(class_1799 itemStack, class_2680 blockState, CallbackInfoReturnable<Float> cir) {
        if (CarpetSettings.missingTools && blockState.method_26231() == class_2498.field_11537 && itemStack.method_31573(class_3489.field_42614))
        {
            class_9424 tool = itemStack.method_58694(class_9334.field_50077);
            if (tool != null) {
                cir.setReturnValue(tool.method_58425(class_2246.field_10340.method_9564()));
            }
        }
    }
}
