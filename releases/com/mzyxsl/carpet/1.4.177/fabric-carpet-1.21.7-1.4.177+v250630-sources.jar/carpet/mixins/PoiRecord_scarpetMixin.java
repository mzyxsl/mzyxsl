package carpet.mixins;

import net.minecraft.class_4156;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4156.class)
public interface PoiRecord_scarpetMixin
{
    @Accessor("freeTickets")
    int getFreeTickets();

    @Invoker
    boolean callAcquireTicket();
}
