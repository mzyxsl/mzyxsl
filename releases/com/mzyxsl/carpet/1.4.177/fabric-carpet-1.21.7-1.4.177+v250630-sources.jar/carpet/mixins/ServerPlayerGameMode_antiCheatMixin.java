package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_1657.class)
public abstract class ServerPlayerGameMode_antiCheatMixin extends class_1309
{
    @Shadow public abstract double entityInteractionRange();

    @Shadow public abstract double blockInteractionRange();

    protected ServerPlayerGameMode_antiCheatMixin(final class_1299<? extends class_1309> entityType, final class_1937 level)
    {
        super(entityType, level);
    }

    @Inject(method = "canInteractWithBlock", at = @At("HEAD"), cancellable = true)
    private void canInteractLongRangeBlock(class_2338 pos, double d, CallbackInfoReturnable<Boolean> cir)
    {
        double maxRange = blockInteractionRange() + d;
        maxRange = maxRange * maxRange;
        if (CarpetSettings.antiCheatDisabled && maxRange < 1024 && method_33571().method_1025(class_243.method_24953(pos)) < 1024) cir.setReturnValue(true);
    }

    @Inject(method = "canInteractWithEntity(Lnet/minecraft/world/phys/AABB;D)Z", at = @At("HEAD"), cancellable = true)
    private void canInteractLongRangeEntity(class_238 aabb, double d, CallbackInfoReturnable<Boolean> cir)
    {
        double maxRange = entityInteractionRange() + d;
        maxRange = maxRange * maxRange;
        if (CarpetSettings.antiCheatDisabled && maxRange < 1024 && aabb.method_49271(method_33571()) < 1024) cir.setReturnValue(true);
    }
}
