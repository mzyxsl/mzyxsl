package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2338;
import net.minecraft.class_2791;
import net.minecraft.class_3443;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_3443.class)
public class StructurePiece_scarpetPlopMixin
{
    @Redirect(method = "placeBlock", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/chunk/ChunkAccess;markPosForPostprocessing(Lnet/minecraft/core/BlockPos;)V"
    ))
    private void markOrNot(class_2791 chunk, class_2338 pos)
    {
        if (!CarpetSettings.skipGenerationChecks.get()) chunk.method_12039(pos);
    }
}
