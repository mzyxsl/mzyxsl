package carpet.mixins;

import carpet.script.CarpetEventServer;
import carpet.script.CarpetScriptServer;
import net.minecraft.class_1297;
import net.minecraft.class_5568;
import net.minecraft.class_5579;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5579.class)
public class PersistentEntitySectionManager_scarpetMixin
{
    @Inject(method = "addEntity(Lnet/minecraft/world/level/entity/EntityAccess;Z)Z", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/entity/Visibility;isTicking()Z"
    ))
    private void handleAddedEntity(class_5568 entityLike, boolean existing, CallbackInfoReturnable<Boolean> cir)
    {
        class_1297 entity = (class_1297)entityLike;
        CarpetEventServer.Event event = CarpetEventServer.Event.ENTITY_HANDLER.get(entity.method_5864());
        if (event != null)
        {
            if (event.isNeeded())
            {
                event.onEntityAction(entity, !existing);
            }
        }
        else
        {
            CarpetScriptServer.LOG.error("Failed to handle entity type " + entity.method_5864().method_5882());
        }

        event = CarpetEventServer.Event.ENTITY_LOAD.get(entity.method_5864());
        if (event != null)
        {
            if (event.isNeeded())
            {
                event.onEntityAction(entity, true);
            }
        }
        else
        {
            CarpetScriptServer.LOG.error("Failed to handle entity type " + entity.method_5864().method_5882());
        }

    }

}
