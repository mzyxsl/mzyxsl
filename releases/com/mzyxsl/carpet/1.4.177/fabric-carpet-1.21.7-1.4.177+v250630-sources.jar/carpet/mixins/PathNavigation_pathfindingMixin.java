package carpet.mixins;

import carpet.logging.LoggerRegistry;
import carpet.logging.logHelpers.PathfindingVisualizer;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.Set;
import net.minecraft.class_11;
import net.minecraft.class_1308;
import net.minecraft.class_1408;
import net.minecraft.class_2338;
import net.minecraft.class_243;

@Mixin(class_1408.class)
public abstract class PathNavigation_pathfindingMixin
{

    @Shadow @Final protected class_1308 mob;


    @Shadow protected @Nullable abstract class_11 createPath(Set<class_2338> set, int i, boolean bl, int j);

    @Redirect(method =  "createPath(Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/pathfinder/Path;", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/ai/navigation/PathNavigation;createPath(Ljava/util/Set;IZI)Lnet/minecraft/world/level/pathfinder/Path;"
    ))
    private class_11 pathToBlock(class_1408 entityNavigation, Set<class_2338> set_1, int int_1, boolean boolean_1, int int_2)
    {
        if (!LoggerRegistry.__pathfinding)
            return createPath(set_1, int_1, boolean_1, int_2);
        long start = System.nanoTime();
        class_11 path = createPath(set_1, int_1, boolean_1, int_2);
        long finish = System.nanoTime();
        float duration = (1.0F*((finish - start)/1000))/1000;
        set_1.forEach(b -> PathfindingVisualizer.slowPath(mob, class_243.method_24955(b), duration, path != null)); // ground centered position
        return path;
    }

    @Redirect(method =  "createPath(Lnet/minecraft/world/entity/Entity;I)Lnet/minecraft/world/level/pathfinder/Path;", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/ai/navigation/PathNavigation;createPath(Ljava/util/Set;IZI)Lnet/minecraft/world/level/pathfinder/Path;"
    ))
    private class_11 pathToEntity(class_1408 entityNavigation, Set<class_2338> set_1, int int_1, boolean boolean_1, int int_2)
    {
        if (!LoggerRegistry.__pathfinding)
            return createPath(set_1, int_1, boolean_1, int_2);
        long start = System.nanoTime();
        class_11 path = createPath(set_1, int_1, boolean_1, int_2);
        long finish = System.nanoTime();
        float duration = (1.0F*((finish - start)/1000))/1000;
        set_1.forEach(b -> PathfindingVisualizer.slowPath(mob, class_243.method_24955(b), duration, path != null));
        return path;
    }
}
