package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1299;
import net.minecraft.class_1317;
import net.minecraft.class_9168;
import net.minecraft.class_9169;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1317.class)
public class PiglinBrute_getPlacementTypeMixin {
	@Inject(method = "getPlacementType", at = @At("HEAD"), cancellable = true)
	private static void getPlacementType(final class_1299<?> entityType, final CallbackInfoReturnable<class_9168> cir) {
		if (CarpetSettings.piglinsSpawningInBastions && entityType == class_1299.field_25751) {
			cir.setReturnValue(class_9169.field_48745);
		}
	}
}
