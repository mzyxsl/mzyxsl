package carpet.mixins;

import it.unimi.dsi.fastutil.objects.Reference2ObjectMap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_274;

@Mixin(class_269.class)
public interface Scoreboard_scarpetMixin {
    @Accessor("objectivesByCriteria")
    Reference2ObjectMap<class_274, List<class_266>> getObjectivesByCriterion();
}
