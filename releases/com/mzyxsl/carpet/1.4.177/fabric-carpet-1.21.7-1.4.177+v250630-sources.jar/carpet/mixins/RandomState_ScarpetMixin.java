package carpet.mixins;

import carpet.fakes.RandomStateVisitorAccessor;
import net.minecraft.class_6910;
import net.minecraft.class_7138;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(class_7138.class)
public class RandomState_ScarpetMixin implements RandomStateVisitorAccessor {
    @Unique
    private class_6910.class_6915 visitor;

    @ModifyArg(
            method = "<init>",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/level/levelgen/NoiseRouter;mapAll(Lnet/minecraft/world/level/levelgen/DensityFunction$Visitor;)Lnet/minecraft/world/level/levelgen/NoiseRouter;"
            ),
            index = 0
    )
    private class_6910.class_6915 captureVisitor(class_6910.class_6915 visitor) {
        this.visitor = visitor;
        return visitor;
    }

    @Override
    public class_6910.class_6915 getVisitor() {
        return this.visitor;
    }
}
