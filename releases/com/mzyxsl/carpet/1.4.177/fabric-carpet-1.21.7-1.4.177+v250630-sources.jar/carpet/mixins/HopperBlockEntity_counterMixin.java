package carpet.mixins;

import carpet.CarpetSettings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import carpet.helpers.HopperCounter;
import carpet.utils.WoolTool;
import net.minecraft.class_1263;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2377;
import net.minecraft.class_2591;
import net.minecraft.class_2614;
import net.minecraft.class_2621;
import net.minecraft.class_2680;

/**
 * The {@link Mixin} which removes items in a hopper if it points into a wool counter, and calls {@link HopperCounter#add}
 */
@Mixin(class_2614.class)
public abstract class HopperBlockEntity_counterMixin extends class_2621
{
    protected HopperBlockEntity_counterMixin(class_2591<?> blockEntityType, class_2338 blockPos, class_2680 blockState) {
        super(blockEntityType, blockPos, blockState);
    }

    //@Shadow public abstract int getContainerSize();

    //@Shadow public abstract void setItem(int slot, ItemStack stack);

    @Shadow private class_2350 facing;

    /**
     * A method to remove items from hoppers pointing into wool and count them via {@link HopperCounter#add} method
     */
    @Inject(method = "ejectItems", at = @At("HEAD"), cancellable = true)
    private static void onInsert(class_1937 world, class_2338 blockPos, class_2614 hopperBlockEntity, CallbackInfoReturnable<Boolean> cir)
    {
        if (CarpetSettings.hopperCounters) {
            class_2350 hopperFacing = world.method_8320(blockPos).method_11654(class_2377.field_11129);
            class_1767 woolColor = WoolTool.getWoolColorAtPosition(
                    world,
                    blockPos.method_10093(hopperFacing));
            if (woolColor != null)
            {
                class_1263 inventory = class_2614.method_11250(world, blockPos);
                for (int i = 0; i < inventory.method_5439(); ++i)
                {
                    if (!inventory.method_5438(i).method_7960())
                    {
                        class_1799 itemstack = inventory.method_5438(i);//.copy();
                        HopperCounter.getCounter(woolColor).add(world.method_8503(), itemstack);
                        inventory.method_5447(i, class_1799.field_8037);
                    }
                }
                cir.setReturnValue(true);
            }
        }
    }
}
