package carpet.mixins;

import carpet.CarpetSettings;
import carpet.fakes.EntityInterface;
import carpet.helpers.BlockRotator;
import net.minecraft.class_1297;
import net.minecraft.class_2350;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_2350.class)
public abstract class DirectionMixin
{
    @Redirect(method = "orderedByNearest", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getViewYRot(F)F"))
    private static float getYaw(class_1297 entity, float float_1)
    {
        float yaw;
        if (!CarpetSettings.placementRotationFix)
        {
            yaw = entity.method_5705(float_1);
        }
        else
        {
            yaw = ((EntityInterface) entity).getMainYaw(float_1);
        }
        if (BlockRotator.flippinEligibility(entity))
        {
            yaw += 180f;
        }
        return yaw;
    }
    @Redirect(method = "orderedByNearest", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getViewXRot(F)F"))
    private static float getPitch(class_1297 entity, float float_1)
    {
        float pitch = entity.method_5695(float_1);
        if (BlockRotator.flippinEligibility(entity))
        {
            pitch = -pitch;
        }
        return pitch;
    }
}
