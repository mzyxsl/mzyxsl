package carpet.mixins;

import carpet.fakes.ServerPlayerInterface;
import carpet.script.external.Vanilla;
import net.minecraft.class_1297;
import net.minecraft.class_2556;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_7471;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import static carpet.script.CarpetEventServer.Event.PLAYER_MESSAGE;
import static carpet.script.CarpetEventServer.Event.PLAYER_RESPAWNS;

@Mixin(class_3324.class)
public class PlayerList_scarpetEventsMixin
{
    @Shadow @Final private MinecraftServer server;

    @Inject(method = "respawn", at = @At("HEAD"))
    private void onResp(class_3222 serverPlayer, boolean olive, class_1297.class_5529 removalReason, CallbackInfoReturnable<class_3222> cir)
    {
        PLAYER_RESPAWNS.onPlayerEvent(serverPlayer);
    }

    @Inject(method = "broadcastChatMessage(Lnet/minecraft/network/chat/PlayerChatMessage;Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/network/chat/ChatType$Bound;)V",
            at = @At("HEAD"),
            cancellable = true)
    private void cancellableChatMessageEvent(class_7471 message, class_3222 player, class_2556.class_7602 params, CallbackInfo ci) {
        // having this earlier breaks signatures
        if (PLAYER_MESSAGE.isNeeded())
        {
            if (PLAYER_MESSAGE.onPlayerMessage(player, message.method_44862())) ci.cancel();
        }
    }

    @Inject(method = "respawn", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;initInventoryMenu()V"
    ))
    private void invalidatePreviousInstance(class_3222 player, boolean alive, class_1297.class_5529 removalReason, CallbackInfoReturnable<class_3222> cir)
    {
        ((ServerPlayerInterface)player).invalidateEntityObjectReference();
    }

    @Inject(method = "reloadResources", at = @At("HEAD"))
    private void reloadCommands(CallbackInfo ci)
    {
        Vanilla.MinecraftServer_getScriptServer(server).reAddCommands();
    }
}
