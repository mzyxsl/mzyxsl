package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_3222;
import net.minecraft.class_3898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3898.class)
public class ChunkMap_creativePlayersLoadChunksMixin {

    @Inject(method = "skipPlayer(Lnet/minecraft/server/level/ServerPlayer;)Z", at = @At("HEAD"), cancellable = true)
    private void startProfilerSection(class_3222 serverPlayer, CallbackInfoReturnable<Boolean> cir)
    {
        if (!CarpetSettings.creativePlayersLoadChunks && serverPlayer.method_68878()) {
            cir.setReturnValue(true);
        }
    }
}
