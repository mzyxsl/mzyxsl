package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3489;
import net.minecraft.class_5543;
import net.minecraft.class_7924;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_5543.class)
public class BuddingAmethystBlock_movableAmethystMixin extends class_2248 {
    public BuddingAmethystBlock_movableAmethystMixin(class_2251 settings) {
        super(settings);
    }

    @Override
    public void method_9556(class_1937 world, class_1657 player, class_2338 pos, class_2680 state, @Nullable class_2586 blockEntity, class_1799 stack) {
        super.method_9556(world, player, pos, state, blockEntity, stack);
        // doing it here rather than though loottables since loottables are loaded on reload
        // drawback - not controlled via loottables, but hey
        if (CarpetSettings.movableAmethyst &&
                stack.method_31573(class_3489.field_42614) &&
                class_1890.method_8225(world.method_30349().method_30530(class_7924.field_41265).method_46747(class_1893.field_9099), stack) > 0
        )
            method_9577(world, pos, class_1802.field_27065.method_7854());
    }
}
