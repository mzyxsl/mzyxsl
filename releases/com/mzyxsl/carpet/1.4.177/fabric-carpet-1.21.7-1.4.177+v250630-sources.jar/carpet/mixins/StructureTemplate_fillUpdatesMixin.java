package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_3492;
import net.minecraft.class_3499;
import net.minecraft.class_5425;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_3499.class)
public class StructureTemplate_fillUpdatesMixin
{
    @Redirect( method = "placeInWorld", at = @At(
            value = "INVOKE",
            target =  "Lnet/minecraft/world/level/ServerLevelAccessor;updateNeighborsAt(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;)V"
    ))
    private void skipUpdateNeighbours(class_5425 serverWorldAccess, class_2338 pos, class_2248 block)
    {
        if (!CarpetSettings.impendingFillSkipUpdates.get())
            serverWorldAccess.method_8408(pos, block);
    }

    @Redirect(method = "placeInWorld", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructurePlaceSettings;getKnownShape()Z"
    ))
    private boolean skipPostprocess(class_3492 structurePlacementData)
    {
        return structurePlacementData.method_16444() || CarpetSettings.impendingFillSkipUpdates.get();
    }
}
