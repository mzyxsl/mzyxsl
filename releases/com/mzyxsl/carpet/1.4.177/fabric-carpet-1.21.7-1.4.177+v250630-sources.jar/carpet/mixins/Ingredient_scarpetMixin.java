package carpet.mixins;

import net.minecraft.class_1856;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1856.class)
public class Ingredient_scarpetMixin// implements IngredientInterface
{

}
