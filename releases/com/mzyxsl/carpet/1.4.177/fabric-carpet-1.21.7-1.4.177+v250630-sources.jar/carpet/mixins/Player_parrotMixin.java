package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1656;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class Player_parrotMixin extends class_1309
{
    @Shadow @Final public class_1656 abilities;
    
    @Shadow protected abstract void removeEntitiesOnShoulder();
    
    @Shadow public abstract class_2487 getShoulderEntityLeft();
    
    @Shadow protected abstract void setShoulderEntityLeft(class_2487 NbtCompound_1);
    
    @Shadow protected abstract void setShoulderEntityRight(class_2487 NbtCompound_1);
    
    @Shadow public abstract class_2487 getShoulderEntityRight();

    @Shadow protected abstract void respawnEntityOnShoulder(class_2487 entityNbt);

    protected Player_parrotMixin(class_1299<? extends class_1309> entityType_1, class_1937 world_1)
    {
        super(entityType_1, world_1);
    }
    
    @Redirect(method = "aiStep", at = @At(value = "INVOKE",
              target = "Lnet/minecraft/world/entity/player/Player;removeEntitiesOnShoulder()V"))
    private void cancelDropShoulderEntities1(class_1657 playerEntity)
    {
    
    }
    
    @Inject(method = "aiStep", at = @At(value = "INVOKE", shift = At.Shift.AFTER, ordinal = 1,
            target = "Lnet/minecraft/world/entity/player/Player;playShoulderEntityAmbientSound(Lnet/minecraft/nbt/CompoundTag;)V"))
    private void onTickMovement(CallbackInfo ci)
    {
        boolean parrots_will_drop = !CarpetSettings.persistentParrots || this.abilities.field_7480;
        if (!this.method_37908().field_9236 && ((parrots_will_drop && this.field_6017 > 0.5F) || this.method_5799() || this.abilities.field_7479 || method_6113()))
        {
            this.removeEntitiesOnShoulder();
        }
    }
    
    @Redirect(method = "hurtServer", at = @At(value = "INVOKE",
              target = "Lnet/minecraft/world/entity/player/Player;removeEntitiesOnShoulder()V"))
    private void cancelDropShoulderEntities2(class_1657 playerEntity)
    {
    
    }
    
    protected void dismount_left()
    {
        respawnEntityOnShoulder(this.getShoulderEntityLeft());
        this.setShoulderEntityLeft(new class_2487());
    }
    
    protected void dismount_right()
    {
        respawnEntityOnShoulder(this.getShoulderEntityRight());
        this.setShoulderEntityRight(new class_2487());
    }
    
    @Inject(method = "hurtServer", at = @At(value = "INVOKE", shift = At.Shift.BEFORE,
            target = "Lnet/minecraft/world/entity/player/Player;removeEntitiesOnShoulder()V"))
    private void onDamage(class_3218 serverLevel, class_1282 damageSource_1, float float_1, CallbackInfoReturnable<Boolean> cir)
    {
        if (CarpetSettings.persistentParrots && !this.method_5715())
        {
            if (this.field_5974.method_43057() < ((float_1)/15.0) )
            {
                this.dismount_left();
            }
            if (this.field_5974.method_43057() < ((float_1)/15.0) )
            {
                this.dismount_right();
            }
        }
    }
}
