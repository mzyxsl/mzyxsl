package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2633;
import net.minecraft.class_827;
import net.minecraft.class_838;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_838.class)
public abstract class StructureBlockRenderer_mixin implements class_827<class_2633>
{
    @Inject(method = "getViewDistance", at = @At("HEAD"), cancellable = true)
    void newLimit(CallbackInfoReturnable<Integer> cir)
    {
        if (CarpetSettings.structureBlockOutlineDistance != 96)
            cir.setReturnValue(CarpetSettings.structureBlockOutlineDistance);
    }
}
