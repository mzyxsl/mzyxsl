package carpet.mixins;

import carpet.network.CarpetClient;
import carpet.network.ServerNetworkHandler;
import net.minecraft.class_2600;
import net.minecraft.class_2792;
import net.minecraft.class_2817;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3244.class)
public class ServerGamePacketListenerimpl_connectionMixin
{
    @Shadow
    public class_3222 player;

    @Inject(method = "handleCustomPayload", at = @At("HEAD"), cancellable = true)
    private void onCustomCarpetPayload(class_2817 serverboundCustomPayloadPacket, CallbackInfo ci)
    {
        if (serverboundCustomPayloadPacket.comp_1647() instanceof CarpetClient.CarpetPayload cpp) {
            // We should force onto the main thread here
            // ServerNetworkHandler.handleData can possibly mutate data that isn't
            // thread safe, and also allows for client commands to be executed
            class_2600.method_11073(serverboundCustomPayloadPacket, (class_2792) this, player.method_51469());
            ServerNetworkHandler.onClientData(player, cpp.data());
            ci.cancel();
        }
    }
}
