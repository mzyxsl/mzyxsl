package carpet.mixins;

import carpet.fakes.EntityInterface;
import carpet.fakes.ServerPlayerInterface;
import carpet.script.EntityEventsGroup;
import com.mojang.authlib.GameProfile;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3445;
import net.minecraft.class_5321;
import net.minecraft.class_5454;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import static carpet.script.CarpetEventServer.Event.PLAYER_CHANGES_DIMENSION;
import static carpet.script.CarpetEventServer.Event.PLAYER_DIES;
import static carpet.script.CarpetEventServer.Event.PLAYER_FINISHED_USING_ITEM;
import static carpet.script.CarpetEventServer.Event.STATISTICS;

@Mixin(class_3222.class)
public abstract class ServerPlayer_scarpetEventMixin extends class_1657 implements ServerPlayerInterface
{
    // to denote if the player reference is valid

    @Unique
    private boolean isInvalidReference = false;

    public ServerPlayer_scarpetEventMixin(class_1937 level, GameProfile gameProfile) {
        super(level, gameProfile);
    }

    //@Shadow protected abstract void completeUsingItem();

    @Shadow public boolean wonGame;

    @Redirect(method = "completeUsingItem", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/entity/player/Player;completeUsingItem()V"
    ))
    private void finishedUsingItem(class_1657 playerEntity)
    {
        if (PLAYER_FINISHED_USING_ITEM.isNeeded())
        {
            class_1268 hand = method_6058();
            if(!PLAYER_FINISHED_USING_ITEM.onItemAction((class_3222) (Object)this, hand, method_6030())) {
                // do vanilla
                super.method_6040();
            }
        }
        else
        {
            // do vanilla
            super.method_6040();
        }
    }

    @Inject(method = "awardStat", at = @At("HEAD"))
    private void grabStat(class_3445<?> stat, int amount, CallbackInfo ci)
    {
        STATISTICS.onPlayerStatistic((class_3222) (Object)this, stat, amount);
    }

    @Inject(method = "die", at = @At("HEAD"))
    private void onDeathEvent(class_1282 source, CallbackInfo ci)
    {
        ((EntityInterface)this).getEventContainer().onEvent(EntityEventsGroup.Event.ON_DEATH, source.method_5525());
        if (PLAYER_DIES.isNeeded())
        {
            PLAYER_DIES.onPlayerEvent((class_3222) (Object)this);
        }
    }

    private class_243 previousLocation;
    private class_5321<class_1937> previousDimension;

    @Inject(method = "teleport", at = @At("HEAD"))
    private void logPreviousCoordinates(class_5454 serverWorld, CallbackInfoReturnable<class_1297> cir)
    {
        previousLocation = method_19538();
        previousDimension = method_37908().method_27983();  //dimension type
    }

    @Inject(method = "teleport", at = @At("RETURN"))
    private void atChangeDimension(class_5454 destinationP, CallbackInfoReturnable<class_1297> cir)
    {
        if (PLAYER_CHANGES_DIMENSION.isNeeded())
        {
            class_3222 player = (class_3222) (Object)this;
            class_5454 destinationTransition = destinationP;
            class_3218 destination = destinationTransition.comp_2820();
            class_243 to = null;
            if (!wonGame || previousDimension != class_1937.field_25181 || destination.method_27983() != class_1937.field_25179)
            {
                to = method_19538();
            }
            PLAYER_CHANGES_DIMENSION.onDimensionChange(player, previousLocation, to, previousDimension, destination.method_27983());
        }
    };

    @Override
    public void invalidateEntityObjectReference()
    {
        isInvalidReference = true;
    }

    @Override
    public boolean isInvalidEntityObject()
    {
        return isInvalidReference;
    }
}
