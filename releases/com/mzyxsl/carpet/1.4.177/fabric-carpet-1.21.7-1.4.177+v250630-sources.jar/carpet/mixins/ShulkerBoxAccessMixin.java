package carpet.mixins;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(net.minecraft.class_834.class)
public interface ShulkerBoxAccessMixin {
}