package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class Player_antiCheatDisabledMixin extends class_1309
{
    protected Player_antiCheatDisabledMixin(final class_1299<? extends class_1309> entityType, final class_1937 level)
    {
        super(entityType, level);
    }

    @Shadow public abstract void startFallFlying();

    @Shadow public abstract class_1661 getInventory();

    @Inject(method = "tryToStartFallFlying", at = @At("HEAD"), cancellable = true)
    private void allowDeploys(CallbackInfoReturnable<Boolean> cir)
    {
        if (CarpetSettings.antiCheatDisabled && (Object)this instanceof class_3222 sp && sp.method_5682().method_3816())
        {
            class_1799 itemStack_1 = field_56535.method_66659(class_1304.field_6174);
            if (itemStack_1.method_7909() == class_1802.field_8833 && !itemStack_1.method_63692()) {
                startFallFlying();
                cir.setReturnValue(true);
            }
        }
    }
}
