package carpet.mixins;

import carpet.fakes.EntityInterface;
import net.minecraft.class_10185;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1863;
import net.minecraft.class_2811;
import net.minecraft.class_2828;
import net.minecraft.class_2840;
import net.minecraft.class_2846;
import net.minecraft.class_2848;
import net.minecraft.class_2851;
import net.minecraft.class_2868;
import net.minecraft.class_2879;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_3965;
import net.minecraft.class_7472;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static carpet.script.CarpetEventServer.Event.PLAYER_CLICKS_BLOCK;
import static carpet.script.CarpetEventServer.Event.PLAYER_DEPLOYS_ELYTRA;
import static carpet.script.CarpetEventServer.Event.PLAYER_DROPS_ITEM;
import static carpet.script.CarpetEventServer.Event.PLAYER_DROPS_STACK;
import static carpet.script.CarpetEventServer.Event.PLAYER_ESCAPES_SLEEP;
import static carpet.script.CarpetEventServer.Event.PLAYER_RELEASED_ITEM;
import static carpet.script.CarpetEventServer.Event.PLAYER_RIDES;
import static carpet.script.CarpetEventServer.Event.PLAYER_JUMPS;
import static carpet.script.CarpetEventServer.Event.PLAYER_RIGHT_CLICKS_BLOCK;
import static carpet.script.CarpetEventServer.Event.PLAYER_CHOOSES_RECIPE;
import static carpet.script.CarpetEventServer.Event.PLAYER_STARTS_SNEAKING;
import static carpet.script.CarpetEventServer.Event.PLAYER_STARTS_SPRINTING;
import static carpet.script.CarpetEventServer.Event.PLAYER_STOPS_SNEAKING;
import static carpet.script.CarpetEventServer.Event.PLAYER_STOPS_SPRINTING;
import static carpet.script.CarpetEventServer.Event.PLAYER_SWAPS_HANDS;
import static carpet.script.CarpetEventServer.Event.PLAYER_SWINGS_HAND;
import static carpet.script.CarpetEventServer.Event.PLAYER_SWITCHES_SLOT;
import static carpet.script.CarpetEventServer.Event.PLAYER_COMMAND;
import static carpet.script.CarpetEventServer.Event.PLAYER_USES_ITEM;
import static carpet.script.CarpetEventServer.Event.PLAYER_WAKES_UP;


@Mixin(class_3244.class)
public class ServerGamePacketListenerImpl_scarpetEventsMixin
{
    @Shadow public class_3222 player;

    @Inject(method = "handlePlayerInput", at = @At("HEAD"))
    private void checkMoves(class_2851 p, CallbackInfo ci)
    {
        // todo this may not ride on the right thread moment, so needs to be checked

        class_10185 input = p.comp_3139();

        if (player.method_5854() != null && !((EntityInterface)player.method_5854()).isPermanentVehicle()) // won't since that method makes sure its not null
            player.method_5660(p.comp_3139().comp_3164());

        if (PLAYER_RIDES.isNeeded() && (input.comp_3163() || input.comp_3164() || input.comp_3159() || input.comp_3160() || input.comp_3161() || input.comp_3162()))
        {
            PLAYER_RIDES.onMountControls(player, input.comp_3161() == input.comp_3162() ? 0 : (input.comp_3161() ? -1 : 1 ), input.comp_3159() == input.comp_3160() ? 0 : (input.comp_3159() ? 1 : -1), input.comp_3163(), input.comp_3164());
        }
    }

    @Inject(method = "handlePlayerAction", cancellable = true, at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;drop(Z)Z", // dropSelectedItem
            ordinal = 0,
            shift = At.Shift.BEFORE
    ))
    private void onQItem(class_2846 playerActionC2SPacket_1, CallbackInfo ci)
    {
        if(PLAYER_DROPS_ITEM.onPlayerEvent(player)) {
            ci.cancel();
        }
    }

    @Inject(method = "handlePlayerAction", cancellable = true, at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;getItemInHand(Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/item/ItemStack;",
            ordinal = 0,
            shift = At.Shift.BEFORE
    ))
    private void onHandSwap(class_2846 playerActionC2SPacket_1, CallbackInfo ci)
    {
        if(PLAYER_SWAPS_HANDS.onPlayerEvent(player)) ci.cancel();
    }

    @Inject(method = "handlePlayerAction", cancellable = true, at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;drop(Z)Z", // dropSelectedItem
            ordinal = 1,
            shift = At.Shift.BEFORE
    ))
    private void onCtrlQItem(class_2846 playerActionC2SPacket_1, CallbackInfo ci)
    {
        if(PLAYER_DROPS_STACK.onPlayerEvent(player)) {
            ci.cancel();
        }
    }


    @Inject(method = "handleMovePlayer", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;jumpFromGround()V"
    ))
    private void onJump(class_2828 playerMoveC2SPacket_1, CallbackInfo ci)
    {
        PLAYER_JUMPS.onPlayerEvent(player);
    }

    @Inject(method = "handlePlayerAction", cancellable = true, at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayerGameMode;handleBlockBreakAction(Lnet/minecraft/core/BlockPos;Lnet/minecraft/network/protocol/game/ServerboundPlayerActionPacket$Action;Lnet/minecraft/core/Direction;II)V",
            shift = At.Shift.BEFORE
    ))
    private void onClicked(class_2846 packet, CallbackInfo ci)
    {
        if (packet.method_12363() == class_2846.class_2847.field_12968)
            if(PLAYER_CLICKS_BLOCK.onBlockAction(player, packet.method_12362(), packet.method_12360())) {
                ci.cancel();
            }
    }

    @Redirect(method = "handlePlayerAction", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;releaseUsingItem()V"
    ))
    private void onStopUsing(class_3222 serverPlayerEntity)
    {
        if (PLAYER_RELEASED_ITEM.isNeeded())
        {
            class_1268 hand = serverPlayerEntity.method_6058();
            class_1799 stack = serverPlayerEntity.method_6030().method_7972();
            serverPlayerEntity.method_6075();
            PLAYER_RELEASED_ITEM.onItemAction(player, hand, stack);
        }
        else
        {
            serverPlayerEntity.method_6075();
        }
    }

    @Inject(method = "handleUseItemOn", cancellable = true, at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayerGameMode;useItemOn(Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/InteractionHand;Lnet/minecraft/world/phys/BlockHitResult;)Lnet/minecraft/world/InteractionResult;"
    ))
    private void onBlockInteracted(class_2885 playerInteractBlockC2SPacket_1, CallbackInfo ci)
    {
        if (PLAYER_RIGHT_CLICKS_BLOCK.isNeeded())
        {
            class_1268 hand = playerInteractBlockC2SPacket_1.method_12546();
            class_3965 hitRes = playerInteractBlockC2SPacket_1.method_12543();
            if(PLAYER_RIGHT_CLICKS_BLOCK.onBlockHit(player, hand, hitRes)) {
                ci.cancel();
            }
        }
    }

    @Inject(method = "handleUseItem", cancellable = true, at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;resetLastActionTime()V"
    ))
    private void onItemClicked(class_2886 playerInteractItemC2SPacket_1, CallbackInfo ci)
    {
        if (PLAYER_USES_ITEM.isNeeded())
        {
            class_1268 hand = playerInteractItemC2SPacket_1.method_12551();
            if(PLAYER_USES_ITEM.onItemAction(player, hand, player.method_5998(hand).method_7972())) {
                ci.cancel();
            }
        }
    }

    @Inject(method = "handlePlayerInput", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;setLastClientInput(Lnet/minecraft/world/entity/player/Input;)V"
    ))
    private void onStartSneaking(class_2851 serverboundPlayerInputPacket, CallbackInfo ci)
    {
        boolean wasDown = player.method_5715();
        boolean isDown = serverboundPlayerInputPacket.comp_3139().comp_3164();
        if (wasDown != isDown)
        {
            if (isDown)
            {
                PLAYER_STARTS_SNEAKING.onPlayerEvent(player);
            }
            else
            {
                PLAYER_STOPS_SNEAKING.onPlayerEvent(player);
            }
        }
    }

    @Inject(method = "handlePlayerCommand", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;setSprinting(Z)V",
            ordinal = 0
    ))
    private void onStartSprinting(class_2848 clientCommandC2SPacket_1, CallbackInfo ci)
    {
        PLAYER_STARTS_SPRINTING.onPlayerEvent(player);
    }

    @Inject(method = "handlePlayerCommand", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;setSprinting(Z)V",
            ordinal = 1
    ))
    private void onStopSprinting(class_2848 clientCommandC2SPacket_1, CallbackInfo ci)
    {
        PLAYER_STOPS_SPRINTING.onPlayerEvent(player);
    }

    @Inject(method = "handlePlayerCommand", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;isSleeping()Z",
            shift = At.Shift.BEFORE
    ))
    private void onWakeUp(class_2848 clientCommandC2SPacket_1, CallbackInfo ci)
    {
        //weird one - doesn't seem to work, maybe MP
        if (player.method_6113())
            PLAYER_WAKES_UP.onPlayerEvent(player);
        else
            PLAYER_ESCAPES_SLEEP.onPlayerEvent(player);

    }

    @Inject(method = "handlePlayerCommand", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/server/level/ServerPlayer;tryToStartFallFlying()Z",
            shift = At.Shift.BEFORE
    ))
    private void onElytraEngage(class_2848 clientCommandC2SPacket_1, CallbackInfo ci)
    {
        PLAYER_DEPLOYS_ELYTRA.onPlayerEvent(player);
    }

    @Inject(method = "handleContainerButtonClick", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayer;resetLastActionTime()V"))
    private void onItemBeingPickedFromInventory(class_2811 packet, CallbackInfo ci)
    {
        // crafts not int the crafting window
        //CarpetSettings.LOG.error("Player clicks button "+packet.getButtonId());
    }
    @Inject(method = "handlePlaceRecipe", cancellable = true, at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayer;resetLastActionTime()V"))
    private void onRecipeSelectedInRecipeManager(class_2840 packet, CallbackInfo ci)
    {
        if (PLAYER_CHOOSES_RECIPE.isNeeded())
        {
            class_1863.class_10288 displayInfo = player.method_5682().method_3772().method_64686(packet.comp_3244());
            if (displayInfo == null) {
                return;
            }
            if(PLAYER_CHOOSES_RECIPE.onRecipeSelected(player, displayInfo.comp_3250().comp_1932().method_29177(), packet.comp_3245())) ci.cancel();
        }
    }

    @Inject(method = "handleSetCarriedItem", at = @At("HEAD"))
    private void onUpdatedSelectedSLot(class_2868 packet, CallbackInfo ci)
    {
        if (PLAYER_SWITCHES_SLOT.isNeeded() && player.method_5682() != null && player.method_5682().method_18854())
        {
            PLAYER_SWITCHES_SLOT.onSlotSwitch(player, player.method_31548().method_67532(), packet.method_12442());
        }
    }

    @Inject(method = "handleAnimate", at = @At(
            value = "INVOKE", target =
            "Lnet/minecraft/server/level/ServerPlayer;resetLastActionTime()V",
            shift = At.Shift.BEFORE)
    )
    private void onSwing(class_2879 packet, CallbackInfo ci)
    {
        if (PLAYER_SWINGS_HAND.isNeeded() && !player.field_6252)
        {
            PLAYER_SWINGS_HAND.onHandAction(player, packet.method_12512());
        }
    }

    @Inject(method = "handleChatCommand(Lnet/minecraft/network/protocol/game/ServerboundChatCommandPacket;)V",
            at = @At(value = "HEAD")
    )
    private void onChatCommandMessage(class_7472 serverboundChatCommandPacket, CallbackInfo ci) {
        if (PLAYER_COMMAND.isNeeded())
        {
            PLAYER_COMMAND.onPlayerMessage(player, serverboundChatCommandPacket.comp_808());
        }
    }
}
