package carpet.mixins;

import carpet.CarpetSettings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

@Mixin(class_1657.class)
public abstract class Player_xpNoCooldownMixin {

    @Shadow
    protected abstract void touch(class_1297 entity);

    @Redirect(method = "aiStep",at = @At(value = "INVOKE", target = "java/util/List.add(Ljava/lang/Object;)Z"))
    public boolean processXpOrbCollisions(List<class_1297> instance, Object e) {
        class_1297 entity = (class_1297) e;
        if (CarpetSettings.xpNoCooldown) {
            this.touch(entity);
            return true;
        }
        return instance.add(entity);
    }
}
