package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1309.class)
public abstract class LivingEntity_cleanLogsMixin extends class_1297
{

    public LivingEntity_cleanLogsMixin(class_1299<?> type, class_1937 world)
    {
        super(type, world);
    }

    @Redirect(method = "die", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;hasCustomName()Z"))
    private boolean shouldLogDeaths(class_1309 livingEntity)
    {
        return livingEntity.method_16914() && CarpetSettings.cleanLogs && livingEntity.method_5682().method_3767().method_8355(class_1928.field_19398);
    }
}
