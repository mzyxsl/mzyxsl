package carpet.mixins;

import carpet.helpers.OptimizedExplosion;
import carpet.CarpetSettings;
import carpet.logging.LoggerRegistry;
import carpet.logging.logHelpers.ExplosionLogHelper;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1922;
import net.minecraft.class_1927;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_5362;
import net.minecraft.class_8949;
import net.minecraft.class_9892;

@Mixin(value = class_9892.class)
public abstract class Explosion_optimizedTntMixin
{
    @Shadow @Final private class_3218 level;

    @Shadow @Nullable public abstract class_1309 getIndirectSourceEntity();

    private ExplosionLogHelper eLogger;

    @Inject(method = "calculateExplodedPositions", at = @At("HEAD"),
            cancellable = true)
    private void calculateExplodedPositionsCM(final CallbackInfoReturnable<List<class_2338>> cir)
    {
        if (CarpetSettings.optimizedTNT && !level.field_9236 && !(getIndirectSourceEntity() instanceof class_8949))
        {
            cir.setReturnValue(OptimizedExplosion.doExplosionA((class_1927) (Object) this, eLogger));
        }
    }

    @Inject(method = "interactWithBlocks", at = @At("HEAD"))
    private void interactWithBlocksCM(final List<class_2338> list, final CallbackInfo ci)
    {
        if (eLogger != null)
        {
            eLogger.setAffectBlocks( ! list.isEmpty());
            eLogger.onExplosionDone(this.level.method_8510());
        }
        if (CarpetSettings.explosionNoBlockDamage)
        {
            list.clear();
        }
    }

    //optional due to Overwrite in Lithium
    //should kill most checks if no block damage is requested
    @Redirect(method = "calculateExplodedPositions", require = 0, at = @At(value = "INVOKE",
            target ="Lnet/minecraft/world/level/ExplosionDamageCalculator;getBlockExplosionResistance(Lnet/minecraft/world/level/Explosion;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/material/FluidState;)Ljava/util/Optional;"))
    private Optional<Float> noBlockCalcsWithNoBLockDamage(final class_5362 instance, final class_1927 explosion, final class_1922 blockGetter, final class_2338 blockPos, final class_2680 blockState, final class_3610 fluidState)
    {
        if (CarpetSettings.explosionNoBlockDamage) return Optional.of(class_2246.field_9987.method_9520());
        return instance.method_29555(explosion, blockGetter, blockPos, blockState, fluidState);
    }

    @Inject(method = "<init>",
            at = @At(value = "RETURN"))
    private void onExplostion(class_3218 world, class_1297 entity, class_1282 damageSource, final class_5362 explosionBehavior, final class_243 vec3, final float power, final boolean createFire, final class_1927.class_4179 destructionType, final CallbackInfo ci)
    {
        if (LoggerRegistry.__explosions && ! world.field_9236)
        {
            eLogger = new ExplosionLogHelper(vec3.field_1352, vec3.field_1351, vec3.field_1350, power, createFire, destructionType, level.method_30349());
        }
    }

    @Redirect(method = "hurtEntities",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;push(Lnet/minecraft/world/phys/Vec3;)V"))
    private void setVelocityAndUpdateLogging(class_1297 entity, class_243 velocity)
    {
        if (eLogger != null) {
            eLogger.onEntityImpacted(entity, velocity.method_1020(entity.method_18798()));
        }
        entity.method_60491(velocity);
    }
}
