package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2540;
import net.minecraft.class_2633;
import net.minecraft.class_2875;
import net.minecraft.class_3532;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2875.class)
public class ServerboundSetStructureBlockPacketMixin {
    @Mutable @Final @Shadow
    private class_2338 offset;
    @Mutable @Final @Shadow
    private class_2382 size;

    @Inject(
            method = "<init>(Lnet/minecraft/network/FriendlyByteBuf;)V",
            at = @At("TAIL")
    )
    private void structureBlockLimitsRead(class_2540 buf, CallbackInfo ci) {
        if (buf.readableBytes() == 6*4) {
            // This will throw an exception if carpet is not installed on client
            offset = new class_2338(class_3532.method_15340(buf.readInt(), -CarpetSettings.structureBlockLimit, CarpetSettings.structureBlockLimit), class_3532.method_15340(buf.readInt(), -CarpetSettings.structureBlockLimit, CarpetSettings.structureBlockLimit), class_3532.method_15340(buf.readInt(), -CarpetSettings.structureBlockLimit, CarpetSettings.structureBlockLimit));
            size = new class_2382(class_3532.method_15340(buf.readInt(), 0, CarpetSettings.structureBlockLimit), class_3532.method_15340(buf.readInt(), 0, CarpetSettings.structureBlockLimit), class_3532.method_15340(buf.readInt(), 0, CarpetSettings.structureBlockLimit));
        }
    }

    @Inject(
            method = "write",
            at = @At("TAIL")
    )
    private void structureBlockLimitsWrite(class_2540 buf, CallbackInfo ci) {
        //client method, only applicable if with carpet is on the server, or running locally
        if (CarpetSettings.structureBlockLimit != class_2633.field_31365)
        {
            buf.method_53002(this.offset.method_10263());
            buf.method_53002(this.offset.method_10264());
            buf.method_53002(this.offset.method_10260());
            buf.method_53002(this.size.method_10263());
            buf.method_53002(this.size.method_10264());
            buf.method_53002(this.size.method_10260());
        }
    }
}
