package carpet.mixins;

import carpet.CarpetServer;
import carpet.fakes.ServerGamePacketListenerImplInterface;
import net.minecraft.class_2535;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_8609;
import net.minecraft.class_8792;
import net.minecraft.class_9812;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3244.class)
public abstract class ServerGamePacketListenerImpl_coreMixin extends class_8609 implements ServerGamePacketListenerImplInterface {
    @Shadow
    public class_3222 player;

    public ServerGamePacketListenerImpl_coreMixin(final MinecraftServer minecraftServer, final class_2535 connection, final class_8792 i)
    {
        super(minecraftServer, connection, i);
    }

    @Inject(method = "onDisconnect", at = @At("HEAD"))
    private void onPlayerDisconnect(class_9812 reason, CallbackInfo ci) {
        CarpetServer.onPlayerLoggedOut(this.player, reason.comp_2853());
    }

    @Override
    public class_2535 getConnection() {
        return field_45013;
    }
}
