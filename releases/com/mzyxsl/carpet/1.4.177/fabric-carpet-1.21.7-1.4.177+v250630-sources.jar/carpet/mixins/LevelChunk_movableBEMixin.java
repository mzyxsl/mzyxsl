package carpet.mixins;

import carpet.CarpetSettings;
import carpet.fakes.WorldChunkInterface;
import net.minecraft.class_10209;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2241;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2378;
import net.minecraft.class_2586;
import net.minecraft.class_2667;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2843;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3558;
import net.minecraft.class_3695;
import net.minecraft.class_4076;
import net.minecraft.class_5539;
import net.minecraft.class_6749;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_2818.class)
public abstract class LevelChunk_movableBEMixin extends class_2791 implements WorldChunkInterface
{
    @Shadow
    @Final
    class_1937 level;

    public LevelChunk_movableBEMixin(class_1923 pos, class_2843 upgradeData, class_5539 heightLimitView, class_2378<class_1959> biome, long inhabitedTime, @Nullable class_2826[] sectionArrayInitializer, @Nullable class_6749 blendingData) {
        super(pos, upgradeData, heightLimitView, biome, inhabitedTime, sectionArrayInitializer, blendingData);
    }

    @Shadow
    /* @Nullable */
    public abstract class_2586 getBlockEntity(class_2338 blockPos_1, class_2818.class_2819 worldChunk$CreationType_1);

    @Shadow protected abstract <T extends class_2586> void updateBlockEntityTicker(T blockEntity);

    @Shadow public abstract void addAndRegisterBlockEntity(class_2586 blockEntity);

    // Fix Failure: If a moving BlockEntity is placed while BlockEntities are ticking, this will not find it and then replace it with a new TileEntity!
    // blockEntity_2 = this.getBlockEntity(blockPos_1, WorldChunk.CreationType.CHECK);
    // question is - with the changes in the BE handling this might not be a case anymore
    @Redirect(method = "setBlockState", at = @At(value = "INVOKE", ordinal = 0,
            target = "Lnet/minecraft/world/level/chunk/LevelChunk;getBlockEntity(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/chunk/LevelChunk$EntityCreationType;)Lnet/minecraft/world/level/block/entity/BlockEntity;"))
    private class_2586 ifGetBlockEntity(class_2818 worldChunk, class_2338 blockPos_1,
            class_2818.class_2819 worldChunk$CreationType_1)
    {
        if (!CarpetSettings.movableBlockEntities)
        {
            return this.getBlockEntity(blockPos_1, class_2818.class_2819.field_12859);
        }
        else
        {
            return this.level.method_8321(blockPos_1);
        }
    }
    
    
    /**
     * Sets the Blockstate and the BlockEntity.
     * Only sets BlockEntity if Block is BlockEntityProvider, but doesn't check if it actually matches (e.g. can assign beacon to chest entity).
     *
     * @author 2No2Name
     */
    /* @Nullable */
    // todo update me to the new version
    @Override
    public class_2680 setBlockStateWithBlockEntity(class_2338 blockPos_1, class_2680 newBlockState, class_2586 newBlockEntity,
            int flags)
    {

        int y = blockPos_1.method_10264();

        class_2826 chunkSection = this.method_38259(this.method_31602(y));

        boolean hadOnlyAir = chunkSection.method_38292();

        if (hadOnlyAir && newBlockState.method_26215())
        {
            return null;
        }

        int x = blockPos_1.method_10263() & 15;
        int chunkY = blockPos_1.method_10264() & 15;
        int z = blockPos_1.method_10260() & 15;
        class_2680 oldBlockState = chunkSection.method_16675(x, chunkY, z, newBlockState);
        if (oldBlockState == newBlockState)
        {
            return null;
        }
        class_2248 newBlock = newBlockState.method_26204();
        this.field_34541.get(class_2902.class_2903.field_13197).method_12597(x, y, z, newBlockState);
        this.field_34541.get(class_2902.class_2903.field_13203).method_12597(x, y, z, newBlockState);
        this.field_34541.get(class_2902.class_2903.field_13200).method_12597(x, y, z, newBlockState);
        this.field_34541.get(class_2902.class_2903.field_13202).method_12597(x, y, z, newBlockState);
        boolean hasOnlyAir = chunkSection.method_38292();
        if (hadOnlyAir != hasOnlyAir)
        {
            this.level.method_8398().method_12130().method_15552(blockPos_1, hasOnlyAir);
            this.level.method_8398().method_62872(field_34538.field_9181, class_4076.method_18675(y), field_34538.field_9180, hasOnlyAir);
        }

        if (class_3558.method_51561(oldBlockState, newBlockState)) {
            class_3695 profiler = class_10209.method_64146();
            profiler.method_15396("updateSkyLightSources");
            field_44708.method_51536(this, x, chunkY, z);
            profiler.method_15405("queueCheckLight");
            level.method_8398().method_12130().method_15513(blockPos_1);
            profiler.method_15407();
        }

        boolean blockChanged = !oldBlockState.method_27852(newBlock);
        boolean boolean_1 = (flags & 64) != 0; // moved by pistons
        boolean sideEffects = (flags & class_2248.field_55739) == 0;

        if (blockChanged && oldBlockState.method_31709()) {
            if (level instanceof class_3218 serverLevel && !(oldBlockState.method_26204() instanceof class_2667)) {
                if (sideEffects) {
                    class_2586 blockEntity = level.method_8321(blockPos_1);
                    if (blockEntity != null) {
                        blockEntity.method_66473(blockPos_1, oldBlockState);
                    }
                }
            }
            method_12041(blockPos_1);
        }

        if (blockChanged || newBlock instanceof class_2241)
        {
            if (level instanceof class_3218 serverLevel && !(oldBlockState.method_26204() instanceof class_2667))
            {
                if ((flags & class_2248.field_31027) != 0 || boolean_1)
                {
                    oldBlockState.method_66478(serverLevel, blockPos_1, boolean_1);
                }
            }
        }


                if (chunkSection.method_12254(x, chunkY, z).method_26204() != newBlock)
        {
            return null;
        }

        if (!level.field_9236 && sideEffects) {
            // this updates stuff, schedule ticks - do we want that since its only be called from MovingPistonBlock really?
            newBlockState.method_26182(level, blockPos_1, oldBlockState, boolean_1);
        }

        class_2586 oldBlockEntity = null;
        if (oldBlockState.method_31709())
        {
            oldBlockEntity = this.getBlockEntity(blockPos_1, class_2818.class_2819.field_12859);
            if (oldBlockEntity != null && !oldBlockEntity.method_61176(oldBlockState))
            {
                oldBlockEntity.method_31664(oldBlockState);
                updateBlockEntityTicker(oldBlockEntity);
            }
            else
            {
                if (newBlockEntity == null)
                {
                    newBlockEntity = ((class_2343) newBlock).method_10123(blockPos_1, newBlockState);
                    if (newBlockEntity != null)
                    {
                        addAndRegisterBlockEntity(newBlockEntity);
                    }
                }
                if (newBlockEntity != oldBlockEntity && newBlockEntity != null)
                {
                    newBlockEntity.method_10996();
                    this.level.method_8438(newBlockEntity);
                    newBlockEntity.method_31664(newBlockState);
                    updateBlockEntityTicker(newBlockEntity);
                }
            }
        }

        method_65063();
        return oldBlockState;
    }
}
