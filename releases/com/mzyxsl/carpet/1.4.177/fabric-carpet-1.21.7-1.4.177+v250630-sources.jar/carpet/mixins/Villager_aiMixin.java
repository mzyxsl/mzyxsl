package carpet.mixins;

import carpet.helpers.ParticleDisplay;
import carpet.utils.Messenger;
import carpet.utils.MobAI;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import net.minecraft.class_11;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1748;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2388;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3988;
import net.minecraft.class_4140;
import net.minecraft.class_4153;
import net.minecraft.class_4156;
import net.minecraft.class_4168;
import net.minecraft.class_4208;
import net.minecraft.class_4831;
import net.minecraft.class_7477;

@Mixin(class_1646.class)
public abstract class Villager_aiMixin extends class_3988
{
    @Shadow protected abstract void setUnhappy();

    @Shadow protected abstract int countFoodPointsInInventory();

    @Shadow public abstract void eatAndDigestFood();

    int totalFood;
    boolean hasBed;
    int displayAge;

    public Villager_aiMixin(class_1299<? extends class_3988> entityType_1, class_1937 world_1)
    {
        super(entityType_1, world_1);
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void ontick(CallbackInfo ci)
    {
        if (MobAI.isTracking(this, MobAI.TrackingType.IRON_GOLEM_SPAWNING))
        {
            long time;
            Optional<? extends class_4831<?>> last_seen = this.field_18321.method_35058().get(class_4140.field_25754);
            if (!last_seen.isPresent())
            {
                time = 0;
            }
            else
            {
                time = last_seen.get().method_35127();
            }
            boolean recentlySeen = time > 0;
            Optional<Long> optional_11 = this.field_18321.method_18904(class_4140.field_19385);
            //Optional<Timestamp> optional_22 = this.brain.getOptionalMemory(MemoryModuleType.LAST_WORKED_AT_POI);
            //boolean work = false;
            boolean sleep = false;
            boolean panic = this.field_18321.method_18906(class_4168.field_18599);
            long currentTime = this.method_37908().method_8510();
            if (optional_11.isPresent()) {
                sleep = (currentTime - optional_11.get()) < 24000L;
            }
            //if (optional_22.isPresent()) {
            //    work = (currentTime - optional_22.get().getTime()) < 36000L;
            //}

            this.method_5665(Messenger.c(
                    (sleep?"eb ":"fb ")+"\u263d ",
                    //(work?"eb ":"fb ")+"\u2692 ",//"\u26CF ",
                    (panic?"lb ":"fb ")+"\u2623 ",//"\u2622 \u2620 \u26A1 ",
                    (recentlySeen?"rb ":"lb ")+time ));
            this.method_5880(true);
        }
        else if (MobAI.isTracking(this, MobAI.TrackingType.BREEDING))
        {
            if (field_6012 % 50 == 0 || field_6012 < 20)
            {
                totalFood = countFoodPointsInInventory() / 12;
                hasBed = this.field_18321.method_18904(class_4140.field_18438).isPresent();
                displayAge = method_5618();

            }
            if (Math.abs(displayAge) < 100 && displayAge !=0) displayAge = method_5618();

            this.method_5665(Messenger.c(
                    (hasBed?"eb ":"fb ")+"\u2616 ",//"\u263d ",
                    (totalFood>0?"eb ":"fb ")+"\u2668",(totalFood>0?"e ":"f ")+totalFood+" ",
                    (displayAge==0?"eb ":"fb ")+"\u2661",(displayAge==0?"e ":"f "+displayAge)
            ));
            this.method_5880(true);
        }
    }

    @Inject(method = "mobInteract", at = @At("HEAD"), cancellable = true)
    private void onInteract(class_1657 playerEntity_1, class_1268 hand_1, CallbackInfoReturnable<class_1269> cir)
    {
        if (MobAI.isTracking(this, MobAI.TrackingType.BREEDING))
        {
            class_1799 itemStack_1 = playerEntity_1.method_5998(hand_1);
            if (itemStack_1.method_7909() == class_1802.field_8687)
            {
                class_4208 bedPos = this.field_18321.method_18904(class_4140.field_18438).orElse(null);
                if (bedPos == null || bedPos.comp_2207() != method_37908().method_27983()) // get Dimension
                {
                    setUnhappy();
                    ((class_3218) method_37908()).method_65096(new class_2388(class_2398.field_35434, class_2246.field_10499.method_9564()), method_23317(), method_23318() + method_5751() + 1, method_23321(), 1, 0.1, 0.1, 0.1, 0.0);
                }
                else
                {

                    ParticleDisplay.drawParticleLine((class_3222) playerEntity_1, method_19538(), class_243.method_24953(bedPos.comp_2208()), new class_2390(0xff000000, 1),  class_2398.field_11211, 100, 0.2); // pos+0.5v
                }
            }
            else if (itemStack_1.method_7909() == class_1802.field_8511)
            {
                while(countFoodPointsInInventory() >= 12) eatAndDigestFood();

            }
            else if (itemStack_1.method_7909() instanceof class_1748)
            {
                List<class_4156> list_1 = ((class_3218) method_37908()).method_19494().method_19125(
                        type -> type.method_40225(class_7477.field_39291),
                        method_24515(),
                        48, class_4153.class_4155.field_18489).toList();
                for (class_4156 poi : list_1)
                {
                    class_243 pv = class_243.method_24953(poi.method_19141());
                    if (!poi.method_19139())
                    {
                        ((class_3218) method_37908()).method_65096(class_2398.field_11211,
                                pv.field_1352, pv.field_1351+1.5, pv.field_1350,
                                50, 0.1, 0.3, 0.1, 0.0);
                    }
                    else if (canReachHome((class_1646)(Object)this, poi.method_19141(), poi))
                        ((class_3218) method_37908()).method_65096(class_2398.field_11207,
                                pv.field_1352, pv.field_1351+1, pv.field_1350,
                                50, 0.1, 0.3, 0.1, 0.0);
                    else
                        ((class_3218) method_37908()).method_65096(new class_2388(class_2398.field_35434, class_2246.field_10499.method_9564()),
                                pv.field_1352, pv.field_1351+1, pv.field_1350,
                                1, 0.1, 0.1, 0.1, 0.0);
                }
            }
            cir.setReturnValue(class_1269.field_5814);
            cir.cancel();
        }
    }

    // stolen from VillagerMakeLove
    private boolean canReachHome(class_1646 villager, class_2338 pos, class_4156 poi) {
        class_11 path = villager.method_5942().method_6348(pos, poi.method_19142().comp_349().comp_817());
        return path != null && path.method_21655();
    }


    @Inject(method = "spawnGolemIfNeeded", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/phys/AABB;inflate(DDD)Lnet/minecraft/world/phys/AABB;",
            shift = At.Shift.AFTER
    ))
    private void particleIt(class_3218 serverWorld, long l, int i, CallbackInfo ci)
    {
        if (MobAI.isTracking(this, MobAI.TrackingType.IRON_GOLEM_SPAWNING))
        {
            ((class_3218) method_37908()).method_65096(new class_2388(class_2398.field_35434, class_2246.field_10499.method_9564()), method_23317(), method_23318()+3, method_23321(), 1, 0.1, 0.1, 0.1, 0.0);
        }
    }


}
