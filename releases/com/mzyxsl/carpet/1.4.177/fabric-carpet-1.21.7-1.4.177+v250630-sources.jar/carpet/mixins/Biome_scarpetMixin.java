package carpet.mixins;

import carpet.fakes.BiomeInterface;
import net.minecraft.class_1959;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1959.class)
public class Biome_scarpetMixin implements BiomeInterface {
    @Shadow
    private class_1959.class_5482 climateSettings;

    @Override
    public class_1959.class_5482 getClimateSettings() {
        return climateSettings;
    }
}
