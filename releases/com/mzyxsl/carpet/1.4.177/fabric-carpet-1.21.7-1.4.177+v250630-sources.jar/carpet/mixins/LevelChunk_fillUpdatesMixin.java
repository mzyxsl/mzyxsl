package carpet.mixins;

import carpet.CarpetSettings;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_2818.class)
public class LevelChunk_fillUpdatesMixin
{
    // todo onStateReplaced needs a bit more love since it removes be which is needed
    @Redirect(method = "setBlockState", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/block/state/BlockState;onPlace(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Z)V"
    ))
    private void onAdded(class_2680 blockState, class_1937 world_1, class_2338 blockPos_1, class_2680 blockState_1, boolean boolean_1)
    {
        if (!CarpetSettings.impendingFillSkipUpdates.get())
            blockState.method_26182(world_1, blockPos_1, blockState_1, boolean_1);
    }

    @Redirect(method = "setBlockState", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/block/entity/BlockEntity;preRemoveSideEffects(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V"
    ))
    private void onPreRemoveSideEffects(class_2586 blockEntity, class_2338 blockPos_1, class_2680 blockState_1)
    {
        if (!CarpetSettings.impendingFillSkipUpdates.get())
        {
            blockEntity.method_66473(blockPos_1, blockState_1);
        }
    }

    @Redirect(method = "setBlockState", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/block/state/BlockState;affectNeighborsAfterRemoval(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/core/BlockPos;Z)V"
    ))
    private void onAffectNeighborsAfterRemoval(final class_2680 instance, final class_3218 serverLevel, final class_2338 blockPos, final boolean b)
    {
        if (!CarpetSettings.impendingFillSkipUpdates.get())
        {
            instance.method_66478(serverLevel, blockPos, b);
        }
    }
}
