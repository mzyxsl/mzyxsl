package carpet.network;

import carpet.CarpetServer;
import carpet.CarpetSettings;
import carpet.script.utils.ShapesRenderer;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_746;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public class CarpetClient
{
    public record CarpetPayload(class_2487 data) implements class_8710
    {
        public static final class_9139<class_2540, CarpetPayload> STREAM_CODEC = class_8710.method_56484(CarpetPayload::write, CarpetPayload::new);

        public static final class_9154<CarpetPayload> TYPE = new class_8710.class_9154<>(CARPET_CHANNEL);

        public CarpetPayload(class_2540 input)
        {
            this(input.method_10798());
        }

        public void write(class_2540 output)
        {
            output.method_10794(data);
        }

        @Override public class_9154<CarpetPayload> method_56479()
        {
            return TYPE;
        }
    }

    public static final String HI = "69";
    public static final String HELLO = "420";

    public static ShapesRenderer shapes = null;

    private static class_746 clientPlayer = null;
    private static boolean isServerCarpet = false;
    public static String serverCarpetVersion;
    public static final class_2960 CARPET_CHANNEL = class_2960.method_60655("carpet", "hello");

    public static void gameJoined(class_746 player)
    {
        clientPlayer = player;
    }

    public static void disconnect()
    {
        if (isServerCarpet) // multiplayer connection
        {
            isServerCarpet = false;
            clientPlayer = null;
            CarpetServer.onServerClosed(null);
            CarpetServer.onServerDoneClosing(null);
        }
        else // singleplayer disconnect
        {
            CarpetServer.clientPreClosing();
        }
    }

    public static void setCarpet()
    {
        isServerCarpet = true;
    }

    public static class_746 getPlayer()
    {
        return clientPlayer;
    }

    public static boolean isCarpet()
    {
        return isServerCarpet;
    }

    public static boolean sendClientCommand(String command)
    {
        if (!isServerCarpet && CarpetServer.minecraft_server == null)
        {
            return false;
        }
        ClientNetworkHandler.clientCommand(command);
        return true;
    }

    public static void onClientCommand(class_2520 t)
    {
        CarpetSettings.LOG.info("Server Response:");
        class_2487 tag = (class_2487) t;
        CarpetSettings.LOG.info(" - id: " + tag.method_10558("id"));
        if (tag.method_10545("error"))
        {
            CarpetSettings.LOG.warn(" - error: " + tag.method_10558("error"));
        }
        if (tag.method_10545("output"))
        {
            class_2499 outputTag = (class_2499) tag.method_10580("output");
            for (int i = 0; i < outputTag.size(); i++)
            {
                CarpetSettings.LOG.info(" - response: " + outputTag.method_10608(i).orElseThrow());
            }
        }
    }
}
