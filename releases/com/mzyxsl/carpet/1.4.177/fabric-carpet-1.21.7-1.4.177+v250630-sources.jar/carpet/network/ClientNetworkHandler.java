package carpet.network;

import carpet.CarpetServer;
import carpet.CarpetExtension;
import carpet.CarpetSettings;
import carpet.api.settings.CarpetRule;
import carpet.api.settings.InvalidRuleValueException;
import carpet.api.settings.SettingsManager;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2817;
import net.minecraft.class_746;

public class ClientNetworkHandler
{
    private static final Map<String, BiConsumer<class_746, class_2520>> dataHandlers = new HashMap<String, BiConsumer<class_746, class_2520>>();

    static
    {
        dataHandlers.put(CarpetClient.HI, (p, t) -> onHi(t.method_68658().orElseThrow()));
        dataHandlers.put("Rules", (p, t) -> {
            class_2487 ruleset = (class_2487) t;
            for (String ruleKey : ruleset.method_10541())
            {
                class_2487 ruleNBT = (class_2487) ruleset.method_10580(ruleKey);
                SettingsManager manager = null;
                String ruleName;
                if (ruleNBT.method_10545("Manager"))
                {
                    ruleName = ruleNBT.method_10558("Rule").orElseThrow();
                    String managerName = ruleNBT.method_10558("Manager").orElseThrow();
                    if (managerName.equals("carpet"))
                    {
                        manager = CarpetServer.settingsManager;
                    }
                    else
                    {
                        for (CarpetExtension extension : CarpetServer.extensions)
                        {
                            SettingsManager eManager = extension.extensionSettingsManager();
                            if (eManager != null && managerName.equals(eManager.identifier()))
                            {
                                manager = eManager;
                                break;
                            }
                        }
                    }
                }
                else // Backwards compatibility
                {
                    manager = CarpetServer.settingsManager;
                    ruleName = ruleKey;
                }
                CarpetRule<?> rule = (manager != null) ? manager.getCarpetRule(ruleName) : null;
                if (rule != null)
                {
                    String value = ruleNBT.method_10558("Value").orElseThrow();
                    try
                    {
                        rule.set(null, value);
                    }
                    catch (InvalidRuleValueException ignored)
                    {
                    }
                }
            }
        });
        dataHandlers.put("scShape", (p, t) -> { // deprecated // and unused // should remove for 1.17
            if (CarpetClient.shapes != null)
            {
                CarpetClient.shapes.addShape((class_2487) t);
            }
        });
        dataHandlers.put("scShapes", (p, t) -> {
            if (CarpetClient.shapes != null)
            {
                CarpetClient.shapes.addShapes((class_2499) t);
            }
        });
        dataHandlers.put("clientCommand", (p, t) -> CarpetClient.onClientCommand(t));
    }

    // Ran on the Main Minecraft Thread

    private static void onHi(String version)
    {
        CarpetClient.setCarpet();
        CarpetClient.serverCarpetVersion = version;
        if (CarpetSettings.carpetVersion.equals(CarpetClient.serverCarpetVersion))
        {
            CarpetSettings.LOG.info("Joined carpet server with matching carpet version");
        }
        else
        {
            CarpetSettings.LOG.warn("Joined carpet server with another carpet version: " + CarpetClient.serverCarpetVersion);
        }
        // We can ensure that this packet is
        // processed AFTER the player has joined
        respondHello();
    }

    public static void respondHello()
    {
        class_2487 data = new class_2487();
        data.method_10582(CarpetClient.HELLO, CarpetSettings.carpetVersion);
        CarpetClient.getPlayer().field_3944.method_52787(new class_2817(
                new CarpetClient.CarpetPayload(data)
        ));
    }

    public static void onServerData(class_2487 compound, class_746 player)
    {
        for (String key : compound.method_10541())
        {
            if (dataHandlers.containsKey(key))
            {
                try
                {
                    dataHandlers.get(key).accept(player, compound.method_10580(key));
                }
                catch (Exception exc)
                {
                    CarpetSettings.LOG.info("Corrupt carpet data for " + key);
                }
            }
            else
            {
                CarpetSettings.LOG.error("Unknown carpet data: " + key);
            }
        }
    }

    public static void clientCommand(String command)
    {
        class_2487 tag = new class_2487();
        tag.method_10582("id", command);
        tag.method_10582("command", command);
        class_2487 outer = new class_2487();
        outer.method_10566("clientCommand", tag);
        CarpetClient.getPlayer().field_3944.method_52787(new class_2817(
                new CarpetClient.CarpetPayload(outer)
        ));
    }
}
