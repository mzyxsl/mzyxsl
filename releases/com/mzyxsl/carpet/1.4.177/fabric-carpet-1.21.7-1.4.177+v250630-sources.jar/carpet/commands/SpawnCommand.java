package carpet.commands;

import carpet.CarpetSettings;
import carpet.fakes.SpawnGroupInterface;
import carpet.helpers.HopperCounter;
import carpet.utils.CommandHelper;
import carpet.utils.Messenger;
import carpet.utils.SpawnReporter;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.util.Arrays;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.class_1311;
import net.minecraft.class_1767;
import net.minecraft.class_2168;
import net.minecraft.class_2181;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3341;
import net.minecraft.class_7157;
import net.minecraft.class_8915;

import static com.mojang.brigadier.arguments.IntegerArgumentType.getInteger;
import static com.mojang.brigadier.arguments.IntegerArgumentType.integer;
import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.string;
import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;
import static net.minecraft.class_2172.method_35510;

public class SpawnCommand
{
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 commandBuildContext)
    {
        LiteralArgumentBuilder<class_2168> literalargumentbuilder = method_9247("spawn").
                requires((player) -> CommandHelper.canUseCommand(player, CarpetSettings.commandSpawn));

        literalargumentbuilder.
                then(method_9247("list").
                        then(method_9244("pos", class_2262.method_9698()).
                                executes( (c) -> listSpawns(c.getSource(), class_2262.method_9697(c, "pos"))))).
                then(method_9247("tracking").
                        executes( (c) -> printTrackingReport(c.getSource())).
                        then(method_9247("start").
                                executes( (c) -> startTracking(c.getSource(), null)).
                                then(method_9244("from", class_2262.method_9698()).
                                        then(method_9244("to", class_2262.method_9698()).
                                                executes( (c) -> startTracking(
                                                        c.getSource(),
                                                        class_3341.method_34390(
                                                                class_2262.method_9697(c, "from"),
                                                                class_2262.method_9697(c, "to"))))))).
                        then(method_9247("stop").
                                executes( (c) -> stopTracking(c.getSource()))).
                        then(method_9244("type", word()).
                                suggests( (c, b) -> method_9264(Arrays.stream(SpawnReporter.cachedMobCategories()).map(class_1311::method_6133),b)).
                                executes( (c) -> recentSpawnsForType(c.getSource(), getString(c, "type"))))).
                then(method_9247("test").
                        executes( (c)-> runTest(c.getSource(), 72000, null)).
                        then(method_9244("ticks", integer(10)).
                                executes( (c)-> runTest(
                                        c.getSource(),
                                        getInteger(c, "ticks"),
                                        null)).
                                then(method_9244("counter", word()).
                                        suggests( (c, b) -> method_9264(Arrays.stream(class_1767.values()).map(class_1767::toString),b)).
                                        executes((c)-> runTest(
                                                c.getSource(),
                                                getInteger(c, "ticks"),
                                                getString(c, "counter")))))).
                then(method_9247("mocking").
                        then(method_9244("to do or not to do?", BoolArgumentType.bool()).
                            executes( (c) -> toggleMocking(c.getSource(), BoolArgumentType.getBool(c, "to do or not to do?"))))).
                then(method_9247("rates").
                        executes( (c) -> generalMobcaps(c.getSource())).
                        then(method_9247("reset").
                                executes( (c) -> resetSpawnRates(c.getSource()))).
                        then(method_9244("type", word()).
                                suggests( (c, b) -> method_9264(Arrays.stream(SpawnReporter.cachedMobCategories()).map(class_1311::method_6133),b)).
                                then(method_9244("rounds", integer(0)).
                                        suggests( (c, b) -> method_9253(new String[]{"1"},b)).
                                        executes( (c) -> setSpawnRates(
                                                c.getSource(),
                                                getString(c, "type"),
                                                getInteger(c, "rounds")))))).
                then(method_9247("mobcaps").
                        executes( (c) -> generalMobcaps(c.getSource())).
                        then(method_9247("set").
                                then(method_9244("cap (hostile)", integer(1,1400)).
                                        executes( (c) -> setMobcaps(c.getSource(), getInteger(c, "cap (hostile)"))))).
                        then(method_9244("dimension", class_2181.method_9288()).
                                executes( (c)-> mobcapsForDimension(c.getSource(), class_2181.method_9289(c, "dimension"))))).
                then(method_9247("entities").
                        executes( (c) -> generalMobcaps(c.getSource()) ).
                        then(method_9244("type", string()).
                                suggests( (c, b)->method_9264(Arrays.stream(SpawnReporter.cachedMobCategories()).map(class_1311::method_6133), b)).
                                executes( (c) -> listEntitiesOfType(c.getSource(), getString(c, "type"), false)).
                                then(method_9247("all").executes( (c) -> listEntitiesOfType(c.getSource(), getString(c, "type"), true)))));

        dispatcher.register(literalargumentbuilder);
    }

    private static final Map<String, class_1311> MOB_CATEGORY_MAP = Arrays.stream(SpawnReporter.cachedMobCategories()).collect(Collectors.toMap(class_1311::method_6133, Function.identity()));

    private static class_1311 getCategory(String string) throws CommandSyntaxException
    {
        if (!Arrays.stream(SpawnReporter.cachedMobCategories()).map(class_1311::method_6133).collect(Collectors.toSet()).contains(string))
        {
            throw new SimpleCommandExceptionType(Messenger.c("r Wrong mob type: "+string+" should be "+ Arrays.stream(SpawnReporter.cachedMobCategories()).map(class_1311::method_6133).collect(Collectors.joining(", ")))).create();
        }
        return MOB_CATEGORY_MAP.get(string.toLowerCase(Locale.ROOT));
    }


    private static int listSpawns(class_2168 source, class_2338 pos)
    {
        Messenger.send(source, SpawnReporter.report(pos, source.method_9225()));
        return 1;
    }

    private static int printTrackingReport(class_2168 source)
    {
        Messenger.send(source, SpawnReporter.makeTrackingReport(source.method_9225()));
        return 1;
    }

    private static int startTracking(class_2168 source, class_3341 filter)
    {
        if (SpawnReporter.trackingSpawns())
        {
            Messenger.m(source, "r You are already tracking spawning.");
            return 0;
        }
        SpawnReporter.startTracking(source.method_9211(), filter);
        Messenger.m(source, "gi Spawning tracking started.");
        return 1;
    }

    private static int stopTracking(class_2168 source)
    {
        Messenger.send(source, SpawnReporter.makeTrackingReport(source.method_9225()));
        SpawnReporter.stopTracking(source.method_9211());
        Messenger.m(source, "gi Spawning tracking stopped.");
        return 1;
    }

    private static int recentSpawnsForType(class_2168 source, String mob_type) throws CommandSyntaxException
    {
        class_1311 cat = getCategory(mob_type);
        Messenger.send(source, SpawnReporter.getRecentSpawns(source.method_9225(), cat));
        return 1;
    }

    private static int runTest(class_2168 source, int ticks, String counter)
    {
        // Start tracking
        SpawnReporter.startTracking(source.method_9211(), null);
        // Reset counter
        if (counter == null)
        {
            HopperCounter.resetAll(source.method_9211(), false);
        }
        else
        {
            HopperCounter hCounter = HopperCounter.getCounter(counter);
            if (hCounter != null)
                    hCounter.reset(source.method_9211());
        }


        // tick warp 0
        class_8915 trm = source.method_9211().method_54833();
        // stop warp
        // unnecessary
        // start warp
        trm.method_54677(ticks);
        Messenger.m(source, String.format("gi Started spawn test for %d ticks", ticks));
        return 1;
    }

    private static int toggleMocking(class_2168 source, boolean domock)
    {
        if (domock)
        {
            SpawnReporter.initializeMocking();
            Messenger.m(source, "gi Mob spawns will now be mocked.");
        }
        else
        {
            SpawnReporter.stopMocking();
            Messenger.m(source, "gi Normal mob spawning.");
        }
        return 1;
    }

    private static int generalMobcaps(class_2168 source)
    {
        Messenger.send(source, SpawnReporter.printMobcapsForDimension(source.method_9225(), true));
        return 1;
    }

    private static int resetSpawnRates(class_2168 source)
    {
        for (class_1311 s: SpawnReporter.spawn_tries.keySet())
        {
            SpawnReporter.spawn_tries.put(s,1);
        }
        Messenger.m(source, "gi Spawn rates brought to 1 round per tick for all groups.");

        return 1;
    }

    private static int setSpawnRates(class_2168 source, String mobtype, int rounds) throws CommandSyntaxException
    {
        class_1311 cat = getCategory(mobtype);
        SpawnReporter.spawn_tries.put(cat, rounds);
        Messenger.m(source, "gi "+mobtype+" mobs will now spawn "+rounds+" times per tick");
        return 1;
    }

    private static int setMobcaps(class_2168 source, int hostile_cap)
    {
        double desired_ratio = (double)hostile_cap/ ((SpawnGroupInterface)(Object)class_1311.field_6302).getInitialSpawnCap();
        SpawnReporter.mobcap_exponent = 4.0*Math.log(desired_ratio)/Math.log(2.0);
        Messenger.m(source, String.format("gi Mobcaps for hostile mobs changed to %d, other groups will follow", hostile_cap));
        return 1;
    }

    private static int mobcapsForDimension(class_2168 source, class_3218 world)
    {
        Messenger.send(source, SpawnReporter.printMobcapsForDimension(world, true));
        return 1;
    }

    private static int listEntitiesOfType(class_2168 source, String mobtype, boolean all) throws CommandSyntaxException
    {
        class_1311 cat = getCategory(mobtype);
        Messenger.send(source, SpawnReporter.printEntitiesByType(cat, source.method_9225(), all));
        return 1;
    }
}
