package carpet.commands;

import carpet.CarpetSettings;
import carpet.utils.CommandHelper;
import carpet.utils.DistanceCalculator;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2168;
import net.minecraft.class_2277;
import net.minecraft.class_7157;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class DistanceCommand
{
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 commandBuildContext)
    {
        LiteralArgumentBuilder<class_2168> command = method_9247("distance").
                requires((player) -> CommandHelper.canUseCommand(player, CarpetSettings.commandDistance)).
                then(method_9247("from").
                        executes( (c) -> DistanceCalculator.setStart(c.getSource(), c.getSource().method_9222())).
                        then(method_9244("from", class_2277.method_9737()).
                                executes( (c) -> DistanceCalculator.setStart(
                                        c.getSource(),
                                        class_2277.method_9736(c, "from"))).
                                then(method_9247("to").
                                        executes((c) -> DistanceCalculator.distance(
                                                c.getSource(),
                                                class_2277.method_9736(c, "from"),
                                                c.getSource().method_9222())).
                                        then(method_9244("to", class_2277.method_9737()).
                                                executes( (c) -> DistanceCalculator.distance(
                                                        c.getSource(),
                                                        class_2277.method_9736(c, "from"),
                                                        class_2277.method_9736(c, "to")
                                                )))))).
                then(method_9247("to").
                        executes( (c) -> DistanceCalculator.setEnd(c.getSource(), c.getSource().method_9222()) ).
                        then(method_9244("to", class_2277.method_9737()).
                                executes( (c) -> DistanceCalculator.setEnd(c.getSource(), class_2277.method_9736(c, "to")))));
        dispatcher.register(command);
    }
}
