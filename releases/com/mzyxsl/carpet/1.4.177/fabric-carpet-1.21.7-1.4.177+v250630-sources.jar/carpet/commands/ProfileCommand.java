package carpet.commands;

import carpet.CarpetSettings;
import carpet.utils.CarpetProfiler;
import carpet.utils.CommandHelper;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2168;
import net.minecraft.class_7157;

import static com.mojang.brigadier.arguments.IntegerArgumentType.getInteger;
import static com.mojang.brigadier.arguments.IntegerArgumentType.integer;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

public class ProfileCommand
{
    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 commandBuildContext)
    {
        LiteralArgumentBuilder<class_2168> literalargumentbuilder = method_9247("profile").
                requires((player) -> CommandHelper.canUseCommand(player, CarpetSettings.commandProfile)).
                executes( (c) -> healthReport(c.getSource(), 100)).
                then(method_9247("health").
                        executes( (c) -> healthReport(c.getSource(), 100)).
                        then(method_9244("ticks", integer(20,24000)).
                                executes( (c) -> healthReport(c.getSource(), getInteger(c, "ticks"))))).
                then(method_9247("entities").
                        executes((c) -> healthEntities(c.getSource(), 100)).
                        then(method_9244("ticks", integer(20,24000)).
                                executes((c) -> healthEntities(c.getSource(), getInteger(c, "ticks")))));
        dispatcher.register(literalargumentbuilder);
    }

    public static int healthReport(class_2168 source, int ticks)
    {
        CarpetProfiler.prepare_tick_report(source, ticks);
        return 1;
    }

    public static int healthEntities(class_2168 source, int ticks)
    {
        CarpetProfiler.prepare_entity_report(source, ticks);
        return 1;
    }
}
