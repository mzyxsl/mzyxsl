package carpet.commands;

import carpet.CarpetSettings;
import carpet.utils.CommandHelper;
import carpet.utils.Messenger;
import com.google.common.collect.Lists;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;

import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1263;
import net.minecraft.class_2168;
import net.minecraft.class_2247;
import net.minecraft.class_2248;
import net.minecraft.class_2252;
import net.minecraft.class_2257;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2694;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_7157;
import java.lang.Math;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;
import static net.minecraft.class_2172.method_35510;

public class DrawCommand
{
    public static void register(CommandDispatcher<class_2168> dispatcher, final class_7157 context)
    {
        LiteralArgumentBuilder<class_2168> command = method_9247("draw").
                requires((player) -> CommandHelper.canUseCommand(player, CarpetSettings.commandDraw)).
                then(method_9247("sphere").
                        then(method_9244("center", class_2262.method_9698()).
                                then(method_9244("radius", IntegerArgumentType.integer(1)).
                                        then(drawShape(c -> DrawCommand.drawSphere(c, false), context))))).
                then(method_9247("ball").
                        then(method_9244("center", class_2262.method_9698()).
                                then(method_9244("radius", IntegerArgumentType.integer(1)).
                                        then(drawShape(c -> DrawCommand.drawSphere(c, true), context))))).
                then(method_9247("diamond").
                        then(method_9244("center", class_2262.method_9698()).
                                then(method_9244("radius", IntegerArgumentType.integer(1)).
                                        then(drawShape(c -> DrawCommand.drawDiamond(c, true), context))))).
                then(method_9247("pyramid").
                        then(method_9244("center", class_2262.method_9698()).
                                then(method_9244("radius", IntegerArgumentType.integer(1)).
                                        then(method_9244("height",IntegerArgumentType.integer(1)).
                                                then(method_9244("pointing",StringArgumentType.word()).suggests( (c, b) -> method_9253(new String[]{"up","down"},b)).
                                                        then(method_9244("orientation",StringArgumentType.word()).suggests( (c, b) -> method_9253(new String[]{"y","x","z"},b)).
                                                                then(drawShape(c -> DrawCommand.drawPyramid(c, "square", true), context)))))))).
                then(method_9247("cone").
                        then(method_9244("center", class_2262.method_9698()).
                                then(method_9244("radius", IntegerArgumentType.integer(1)).
                                        then(method_9244("height",IntegerArgumentType.integer(1)).
                                                then(method_9244("pointing",StringArgumentType.word()).suggests( (c, b) -> method_9253(new String[]{"up","down"},b)).
                                                        then(method_9244("orientation",StringArgumentType.word()).suggests( (c, b) -> method_9253(new String[]{"y","x","z"},b))
                                                                .then(drawShape(c -> DrawCommand.drawPyramid(c, "circle", true), context)))))))).
                then(method_9247("cylinder").
                        then(method_9244("center", class_2262.method_9698()).
                                then(method_9244("radius", IntegerArgumentType.integer(1)).
                                        then(method_9244("height",IntegerArgumentType.integer(1)).
                                                        then(method_9244("orientation",StringArgumentType.word()).suggests( (c, b) -> method_9253(new String[]{"y","x","z"},b))
                                                                .then(drawShape(c -> DrawCommand.drawPrism(c, "circle"), context))))))).
                then(method_9247("cuboid").
                        then(method_9244("center", class_2262.method_9698()).
                                then(method_9244("radius", IntegerArgumentType.integer(1)).
                                        then(method_9244("height",IntegerArgumentType.integer(1)).
                                                then(method_9244("orientation",StringArgumentType.word()).suggests( (c, b) -> method_9253(new String[]{"y","x","z"},b))
                                                        .then(drawShape(c -> DrawCommand.drawPrism(c, "square"), context)))))));
        dispatcher.register(command);
    }

    @FunctionalInterface
    private interface ArgumentExtractor<T>
    {
        T apply(final CommandContext<class_2168> ctx, final String argName) throws CommandSyntaxException;
    }

    private static RequiredArgumentBuilder<class_2168, class_2247>
    drawShape(Command<class_2168> drawer, class_7157 commandBuildContext)
    {
        return method_9244("block", class_2257.method_9653(commandBuildContext)).
                executes(drawer)
                .then(method_9247("replace")
                        .then(method_9244("filter", class_2252.method_9645(commandBuildContext))
                                .executes(drawer)));
    }

    private static class ErrorHandled extends RuntimeException {}

    private static <T> T getArg(CommandContext<class_2168> ctx, ArgumentExtractor<T> extract, String hwat) throws CommandSyntaxException
    {
        return getArg(ctx, extract, hwat, false);
    }

    private static <T> T getArg(CommandContext<class_2168> ctx, ArgumentExtractor<T> extract, String hwat, boolean optional) throws CommandSyntaxException
    {
        T arg = null;
        try
        {
            arg = extract.apply(ctx, hwat);
        }
        catch (IllegalArgumentException e)
        {
            if (optional) return null;
            Messenger.m(ctx.getSource(), "rb Missing "+hwat);
            throw new ErrorHandled();
        }
        return arg;
    }

    private static double lengthSq(double x, double y, double z)
    {
        return (x * x) + (y * y) + (z * z);
    }

    private static int setBlock(
            class_3218 world, class_2338.class_2339 mbpos, int x, int y, int z,
            class_2247 block, Predicate<class_2694> replacement,
            List<class_2338> list
    )
    {
        mbpos.method_10103(x, y, z);
        int success=0;
        if (replacement == null || replacement.test(new class_2694(world, mbpos, true)))
        {
            class_2586 tileentity = world.method_8321(mbpos);
            if (tileentity instanceof class_1263)
            {
                ((class_1263) tileentity).method_5448();
            }
            if (block.method_9495(world, mbpos, 2))
            {
                list.add(mbpos.method_10062());
                ++success;
            }
        }

        return success;
    }

    private static int drawSphere(CommandContext<class_2168> ctx, boolean solid) throws CommandSyntaxException
    {
        class_2338 pos;
        int radius;
        class_2247 block;
        Predicate<class_2694> replacement;
        try
        {
            pos = getArg(ctx, class_2262::method_9697, "center");
            radius = getArg(ctx, IntegerArgumentType::getInteger, "radius");
            block = getArg(ctx, class_2257::method_9655, "block");
            replacement = getArg(ctx, class_2252::method_9644, "filter", true);
        }
        catch (ErrorHandled ignored) { return 0; }

        int affected = 0;
        class_3218 world = ctx.getSource().method_9225();

        double radiusX = radius+0.5;
        double radiusY = radius+0.5;
        double radiusZ = radius+0.5;

        final double invRadiusX = 1 / radiusX;
        final double invRadiusY = 1 / radiusY;
        final double invRadiusZ = 1 / radiusZ;

        final int ceilRadiusX = (int) Math.ceil(radiusX);
        final int ceilRadiusY = (int) Math.ceil(radiusY);
        final int ceilRadiusZ = (int) Math.ceil(radiusZ);

        class_2338.class_2339 mbpos = pos.method_25503();
        List<class_2338> list = Lists.newArrayList();

        double nextXn = 0;

        forX: for (int x = 0; x <= ceilRadiusX; ++x)
        {
            final double xn = nextXn;
            nextXn = (x + 1) * invRadiusX;
            double nextYn = 0;
            forY: for (int y = 0; y <= ceilRadiusY; ++y)
            {
                final double yn = nextYn;
                nextYn = (y + 1) * invRadiusY;
                double nextZn = 0;
                forZ: for (int z = 0; z <= ceilRadiusZ; ++z)
                {
                    final double zn = nextZn;
                    nextZn = (z + 1) * invRadiusZ;

                    double distanceSq = lengthSq(xn, yn, zn);
                    if (distanceSq > 1)
                    {
                        if (z == 0)
                        {
                            if (y == 0)
                            {
                                break forX;
                            }
                            break forY;
                        }
                        break forZ;
                    }

                    if (!solid && lengthSq(nextXn, yn, zn) <= 1 && lengthSq(xn, nextYn, zn) <= 1 && lengthSq(xn, yn, nextZn) <= 1)
                    {
                        continue;
                    }

                    CarpetSettings.impendingFillSkipUpdates.set(!CarpetSettings.fillUpdates);
                    for (int xmod = -1; xmod < 2; xmod += 2)
                    {
                        for (int ymod = -1; ymod < 2; ymod += 2)
                        {
                            for (int zmod = -1; zmod < 2; zmod += 2)
                            {
                                affected+= setBlock(world, mbpos,
                                        pos.method_10263() + xmod * x, pos.method_10264() + ymod * y, pos.method_10260() + zmod * z,
                                        block, replacement, list
                                );
                            }
                        }
                    }
                    CarpetSettings.impendingFillSkipUpdates.set(false);
                }
            }
        }
        if (CarpetSettings.fillUpdates)
        {
            list.forEach(blockpos1 -> world.method_8408(blockpos1, world.method_8320(blockpos1).method_26204()));
        }
        Messenger.m(ctx.getSource(), "gi Filled " + affected + " blocks");
        return affected;
    }

    private static int drawDiamond(CommandContext<class_2168> ctx, boolean solid) throws CommandSyntaxException
    {
        class_2338 pos;
        int radius;
        class_2247 block;
        Predicate<class_2694> replacement;
        try
        {
            pos = getArg(ctx, class_2262::method_9697, "center");
            radius = getArg(ctx, IntegerArgumentType::getInteger, "radius");
            block = getArg(ctx, class_2257::method_9655, "block");
            replacement = getArg(ctx, class_2252::method_9644, "filter", true);
        }
        catch (ErrorHandled ignored) { return 0; }

        class_2168 source = ctx.getSource();

        int affected=0;

        class_2338.class_2339 mbpos = pos.method_25503();
        List<class_2338> list = Lists.newArrayList();

        class_3218 world = source.method_9225();

        CarpetSettings.impendingFillSkipUpdates.set(!CarpetSettings.fillUpdates);

        for (int r = 0; r < radius; ++r)
        {
            int y=r-radius+1;
            for (int x = -r; x <= r; ++x)
            {
                int z=r-Math.abs(x);

                affected+= setBlock(world, mbpos, pos.method_10263()+x, pos.method_10264()-y, pos.method_10260()+z, block, replacement, list);
                affected+= setBlock(world, mbpos, pos.method_10263()+x, pos.method_10264()-y, pos.method_10260()-z, block, replacement, list);
                affected+= setBlock(world, mbpos, pos.method_10263()+x, pos.method_10264()+y, pos.method_10260()+z, block, replacement, list);
                affected+= setBlock(world, mbpos, pos.method_10263()+x, pos.method_10264()+y, pos.method_10260()-z, block, replacement, list);
            }
        }

        CarpetSettings.impendingFillSkipUpdates.set(false);

        if (CarpetSettings.fillUpdates)
        {
            list.forEach(p -> world.method_8408(p, world.method_8320(p).method_26204()));
        }

        Messenger.m(source, "gi Filled " + affected + " blocks");

        return affected;
    }

    private static int fillFlat(
            class_3218 world, class_2338 pos, int offset, double dr, boolean rectangle, String orientation,
            class_2247 block, Predicate<class_2694> replacement,
            List<class_2338> list, class_2338.class_2339 mbpos
    )
    {
        int successes=0;
        int r = class_3532.method_15357(dr);
        double drsq = dr*dr;
        if (orientation.equalsIgnoreCase("x"))
        {
            for(int a=-r; a<=r; ++a) for(int b=-r; b<=r; ++b) if(rectangle || a*a + b*b <= drsq)
            {
                successes += setBlock(
                        world, mbpos,pos.method_10263()+offset, pos.method_10264()+a, pos.method_10260()+b,
                        block, replacement, list
                );
            }
            return successes;
        }
        if (orientation.equalsIgnoreCase("y"))
        {
            for(int a=-r; a<=r; ++a) for(int b=-r; b<=r; ++b) if(rectangle || a*a + b*b <= drsq)
            {
                successes += setBlock(
                        world, mbpos,pos.method_10263()+a, pos.method_10264()+offset, pos.method_10260()+b,
                        block, replacement, list
                );
            }
            return successes;
        }
        if (orientation.equalsIgnoreCase("z"))
        {
            for(int a=-r; a<=r; ++a) for(int b=-r; b<=r; ++b) if(rectangle || a*a + b*b <= drsq)
            {
                successes += setBlock(
                        world, mbpos,pos.method_10263()+b, pos.method_10264()+a, pos.method_10260()+offset,
                        block, replacement, list
                );
            }
            return successes;
        }
        return 0;
    }

    private static int drawPyramid(CommandContext<class_2168> ctx, String base, boolean solid) throws CommandSyntaxException
    {
        class_2338 pos;
        double radius;
        int height;
        boolean pointup;
        String orientation;
        class_2247 block;
        Predicate<class_2694> replacement;
        try
        {
            pos = getArg(ctx, class_2262::method_9697, "center");
            radius = getArg(ctx, IntegerArgumentType::getInteger, "radius")+0.5D;
            height = getArg(ctx, IntegerArgumentType::getInteger, "height");
            pointup = getArg(ctx, StringArgumentType::getString, "pointing").equalsIgnoreCase("up");
            orientation = getArg(ctx, StringArgumentType::getString,"orientation");
            block = getArg(ctx, class_2257::method_9655, "block");
            replacement = getArg(ctx, class_2252::method_9644, "filter", true);
        }
        catch (ErrorHandled ignored) { return 0; }

        class_2168 source = ctx.getSource();

        int affected = 0;
        class_2338.class_2339 mbpos = pos.method_25503();

        List<class_2338> list = Lists.newArrayList();

        class_3218 world = source.method_9225();

        CarpetSettings.impendingFillSkipUpdates.set(!CarpetSettings.fillUpdates);

        boolean isSquare = base.equalsIgnoreCase("square");

        for(int i =0; i<height;++i)
        {
            double r = pointup ? radius - radius * i / height - 1 : radius * i / height;
            affected+= fillFlat(world, pos, i, r, isSquare, orientation, block, replacement, list, mbpos);
        }
        
        CarpetSettings.impendingFillSkipUpdates.set(false);

        if (CarpetSettings.fillUpdates) {

            for (class_2338 blockpos1 : list) {
                class_2248 blokc = world.method_8320(blockpos1).method_26204();
                world.method_8408(blockpos1, blokc);
            }
        }

        Messenger.m(source, "gi Filled " + affected + " blocks");

        return affected;
    }

    private static int drawPrism(CommandContext<class_2168> ctx, String base){
        class_2338 pos;
        double radius;
        int height;
        String orientation;
        class_2247 block;
        Predicate<class_2694> replacement;
        try
        {
            pos = getArg(ctx, class_2262::method_9697, "center");
            radius = getArg(ctx, IntegerArgumentType::getInteger, "radius")+0.5D;
            height = getArg(ctx, IntegerArgumentType::getInteger, "height");
            orientation = getArg(ctx, StringArgumentType::getString,"orientation");
            block = getArg(ctx, class_2257::method_9655, "block");
            replacement = getArg(ctx, class_2252::method_9644, "filter", true);
        }
        catch (ErrorHandled | CommandSyntaxException ignored) { return 0; }

        class_2168 source = ctx.getSource();

        int affected = 0;
        class_2338.class_2339 mbpos = pos.method_25503();

        List<class_2338> list = Lists.newArrayList();

        class_3218 world = source.method_9225();

        CarpetSettings.impendingFillSkipUpdates.set(!CarpetSettings.fillUpdates);

        boolean isSquare = base.equalsIgnoreCase("square");

        for(int i =0; i<height;++i)
        {
            affected+= fillFlat(world, pos, i, radius, isSquare, orientation, block, replacement, list, mbpos);
        }

        CarpetSettings.impendingFillSkipUpdates.set(false);

        if (CarpetSettings.fillUpdates) {

            for (class_2338 blockpos1 : list) {
                class_2248 blokc = world.method_8320(blockpos1).method_26204();
                world.method_8408(blockpos1, blokc);
            }
        }

        Messenger.m(source, "gi Filled " + affected + " blocks");

        return affected;
    }
}
