package carpet.script.utils;

import carpet.script.CarpetScriptServer;
import carpet.script.external.Vanilla;
import com.google.common.collect.ImmutableList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.function.Function;

import com.mojang.datafixers.util.Pair;
import javax.annotation.Nullable;
import net.minecraft.class_1923;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2794;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3179;
import net.minecraft.class_3195;
import net.minecraft.class_3215;
import net.minecraft.class_3218;
import net.minecraft.class_3341;
import net.minecraft.class_3449;
import net.minecraft.class_3784;
import net.minecraft.class_3785;
import net.minecraft.class_4643;
import net.minecraft.class_4646;
import net.minecraft.class_4651;
import net.minecraft.class_4659;
import net.minecraft.class_5140;
import net.minecraft.class_5204;
import net.minecraft.class_5207;
import net.minecraft.class_5212;
import net.minecraft.class_5434;
import net.minecraft.class_5455;
import net.minecraft.class_5468;
import net.minecraft.class_5469;
import net.minecraft.class_5497;
import net.minecraft.class_5819;
import net.minecraft.class_5843;
import net.minecraft.class_5847;
import net.minecraft.class_6016;
import net.minecraft.class_6121;
import net.minecraft.class_6796;
import net.minecraft.class_6817;
import net.minecraft.class_6874;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_6908;
import net.minecraft.class_7138;
import net.minecraft.class_7151;
import net.minecraft.class_7869;
import net.minecraft.class_7871;
import net.minecraft.class_7924;

public class FeatureGenerator
{
    @Nullable
    public static synchronized Boolean plop(String featureName, class_3218 world, class_2338 pos)
    {
        Function<class_3218, Thing> custom = featureMap.get(featureName);
        if (custom != null)
        {
            return custom.apply(world).plop(world, pos);
        }
        class_2960 id = class_2960.method_60654(featureName);
        class_3195 structure = world.method_30349().method_30530(class_7924.field_41246).method_63535(id);
        if (structure != null)
        {
            return plopAnywhere(structure, world, pos, world.method_14178().method_12129(), false);
        }

        class_2975<?, ?> configuredFeature = world.method_30349().method_30530(class_7924.field_41239).method_63535(id);
        if (configuredFeature != null)
        {
            ThreadLocal<Boolean> checks = Vanilla.skipGenerationChecks(world);
            checks.set(true);
            try
            {
                return configuredFeature.method_12862(world, world.method_14178().method_12129(), world.field_9229, pos);
            }
            finally
            {
                checks.set(false);
            }
        }
        Optional<class_7151<?>> structureType = world.method_30349().method_30530(class_7924.field_41231).method_17966(id);
        if (structureType.isPresent())
        {
            class_3195 configuredStandard = getDefaultFeature(structureType.get(), world, pos);
            if (configuredStandard != null)
            {
                return plopAnywhere(configuredStandard, world, pos, world.method_14178().method_12129(), false);
            }
        }
        class_3031<?> feature = world.method_30349().method_30530(class_7924.field_41267).method_63535(id);
        if (feature != null)
        {
            class_2975<?, ?> configuredStandard = getDefaultFeature(feature, world, pos, true);
            if (configuredStandard != null)
            {
                ThreadLocal<Boolean> checks = Vanilla.skipGenerationChecks(world);
                checks.set(true);
                try
                {
                    return configuredStandard.method_12862(world, world.method_14178().method_12129(), world.field_9229, pos);
                }
                finally
                {
                    checks.set(false);
                }
            }
        }
        return null;
    }

    @Nullable
    public static class_3195 resolveConfiguredStructure(String name, class_3218 world, class_2338 pos)
    {
        class_2960 id = class_2960.method_60654(name);
        class_3195 configuredStructureFeature = world.method_30349().method_30530(class_7924.field_41246).method_63535(id);
        if (configuredStructureFeature != null)
        {
            return configuredStructureFeature;
        }
        class_7151<?> structureFeature = world.method_30349().method_30530(class_7924.field_41231).method_63535(id);
        if (structureFeature == null)
        {
            return null;
        }
        return getDefaultFeature(structureFeature, world, pos);
    }

    public static synchronized boolean plopGrid(class_3195 structureFeature, class_3218 world, class_2338 pos)
    {
        return plopAnywhere(structureFeature, world, pos, world.method_14178().method_12129(), true);
    }

    @FunctionalInterface
    private interface Thing
    {
        Boolean plop(class_3218 world, class_2338 pos);
    }

    private static Thing simplePlop(class_2975<?, ?> feature)
    {
        return (w, p) -> {
            ThreadLocal<Boolean> checks = Vanilla.skipGenerationChecks(w);
            checks.set(true);
            try
            {
                return feature.method_12862(w, w.method_14178().method_12129(), w.field_9229, p);
            }
            finally
            {
                checks.set(false);
            }
        };
    }

    private static <FC extends class_3037, F extends class_3031<FC>> Thing simplePlop(F feature, FC config)
    {
        return simplePlop(new class_2975<>(feature, config));
    }

    private static Thing simpleTree(class_4643 config)
    {
        //config.ignoreFluidCheck();
        return simplePlop(new class_2975<>(class_3031.field_24134, config));
    }

    private static Thing spawnCustomStructure(class_3195 structure)
    {
        return setupCustomStructure(structure, false);
    }

    private static Thing setupCustomStructure(class_3195 structure, boolean wireOnly)
    {
        return (w, p) -> plopAnywhere(structure, w, p, w.method_14178().method_12129(), wireOnly);
    }

    private static class_3195 getDefaultFeature(class_7151<?> structure, class_3218 world, class_2338 pos)
    {
        // would be nice to have a way to grab structures of this type for position
        // TODO allow old types, like vaillage, or bastion
        class_6880<class_1959> existingBiome = world.method_23753(pos);
        class_3195 result = null;
        for (class_3195 confstr : world.method_30349().method_30530(class_7924.field_41246).method_29722().stream().
                filter(cS -> cS.getValue().method_41618() == structure).map(Map.Entry::getValue).toList())
        {
            result = confstr;
            if (confstr.method_41607().method_40241(existingBiome))
            {
                return result;
            }
        }
        return result;
    }

    private static class_2975<?, ?> getDefaultFeature(class_3031<?> feature, class_3218 world, class_2338 pos, boolean tryHard)
    {
        List<class_6885<class_6796>> configuredStepFeatures = world.method_23753(pos).comp_349().method_30970().method_30983();
        for (class_6885<class_6796> step : configuredStepFeatures)
        {
            for (class_6880<class_6796> provider : step)
            {
                if (provider.comp_349().comp_334().comp_349().comp_332() == feature)
                {
                    return provider.comp_349().comp_334().comp_349();
                }
            }
        }
        if (!tryHard)
        {
            return null;
        }
        return world.method_30349().method_30530(class_7924.field_41239).method_29722().stream().
                filter(cS -> cS.getValue().comp_332() == feature).
                findFirst().map(Map.Entry::getValue).orElse(null);
    }


    public static <T extends class_3037> class_3449 shouldStructureStartAt(class_3218 world, class_2338 pos, class_3195 structure, boolean computeBox)
    {
        class_3215 chunkSource = world.method_14178();
        class_7138 seed = chunkSource.method_41248();
        class_2794 generator = chunkSource.method_12129();
        class_7869 structureState = chunkSource.method_46642();
        List<class_6874> structureConfig = structureState.method_46708(class_6880.method_40223(structure));
        class_1923 chunkPos = new class_1923(pos);
        boolean couldPlace = structureConfig.stream().anyMatch(p -> p.method_41639(structureState, chunkPos.field_9181, chunkPos.field_9180));
        if (!couldPlace)
        {
            return null;
        }

        class_6885<class_1959> structureBiomes = structure.method_41607();

        if (!computeBox)
        {
            //Holder<Biome> genBiome = generator.getBiomeSource().getNoiseBiome(QuartPos.fromBlock(pos.getX()), QuartPos.fromBlock(pos.getY()), QuartPos.fromBlock(pos.getZ()), seed.sampler());
            if (structure.method_47932(new class_3195.class_7149(
                    world.method_30349(), generator, generator.method_12098(),
                    seed, world.method_14183(), world.method_8412(), chunkPos, world, structureBiomes::method_40241
            )).isPresent())
            {
                return class_3449.field_16713;
            }
        }
        else
        {
            class_3449 filledStructure = structure.method_41614(class_6880.method_40223(structure), world.method_27983(),
                    world.method_30349(), generator, generator.method_12098(), seed, world.method_14183(),
                    world.method_8412(), chunkPos, 0, world, structureBiomes::method_40241);
            if (filledStructure != null && filledStructure.method_16657())
            {
                return filledStructure;
            }
        }
        return null;
    }

    private static class_4643.class_4644 createTree(class_2248 block, class_2248 block2, int i, int j, int k, int l)
    {
        return new class_4643.class_4644(class_4651.method_38432(block), new class_5140(i, j, k), class_4651.method_38432(block2), new class_4646(class_6016.method_34998(l), class_6016.method_34998(0), 3), new class_5204(1, 0, 1));
    }

    public static final Map<String, Function<class_3218, Thing>> featureMap = new HashMap<>()
    {{

        put("oak_bees", l -> simpleTree(createTree(class_2246.field_10431, class_2246.field_10503, 4, 2, 0, 2).method_27374().method_27376(List.of(new class_4659(1.00F))).method_23445()));
        put("fancy_oak_bees", l -> simpleTree((new class_4643.class_4644(class_4651.method_38432(class_2246.field_10431), new class_5212(3, 11, 0), class_4651.method_38432(class_2246.field_10503), new class_5207(class_6016.method_34998(2), class_6016.method_34998(4), 4), new class_5204(0, 0, 0, OptionalInt.of(4)))).method_27374().method_27376(List.of(new class_4659(1.00F))).method_23445()));
        put("birch_bees", l -> simpleTree(createTree(class_2246.field_10511, class_2246.field_10539, 5, 2, 0, 2).method_27374().method_27376(List.of(new class_4659(1.00F))).method_23445()));

        put("coral_tree", l -> simplePlop(class_3031.field_13525, class_3037.field_13603));

        put("coral_claw", l -> simplePlop(class_3031.field_13546, class_3037.field_13603));
        put("coral_mushroom", l -> simplePlop(class_3031.field_13585, class_3037.field_13603));
        put("coral", l -> simplePlop(class_3031.field_13555, new class_3179(class_6885.method_40246(
                class_6817.method_40368(class_3031.field_13525, class_3037.field_13603),
                class_6817.method_40368(class_3031.field_13546, class_3037.field_13603),
                class_6817.method_40368(class_3031.field_13585, class_3037.field_13603)
        ))));
        put("bastion_remnant_units", l -> {
            class_5455 regs = l.method_30349();

            class_7871<class_5497> processorLists = regs.method_30530(class_7924.field_41247);
            class_6880<class_5497> bastionGenericDegradation = processorLists.method_46747(class_5469.field_26280);

            class_7871<class_3785> pools = regs.method_30530(class_7924.field_41249);
            class_6880<class_3785> empty = pools.method_46747(class_5468.field_26254);


            return spawnCustomStructure(
                    new class_5434(new class_3195.class_7302(l.method_30349().method_46759(class_7924.field_41236).orElseThrow().method_46735(class_6908.field_36505),
                            Map.of(),
                            class_2893.class_2895.field_13173,
                            class_5847.field_28922
                    ),
                            class_6880.method_40223(new class_3785(
                                    empty,
                                    ImmutableList.of(
                                            Pair.of(class_3784.method_30435("bastion/units/air_base", bastionGenericDegradation), 1)
                                    ),
                                    class_3785.class_3786.field_16687
                            )),
                            6,
                            class_6121.method_35383(class_5843.method_33841(33)),
                            false
                    )
            );
        });
        put("bastion_remnant_hoglin_stable", l -> {
            class_5455 regs = l.method_30349();

            class_7871<class_5497> processorLists = regs.method_30530(class_7924.field_41247);
            class_6880<class_5497> bastionGenericDegradation = processorLists.method_46747(class_5469.field_26280);

            class_7871<class_3785> pools = regs.method_30530(class_7924.field_41249);
            class_6880<class_3785> empty = pools.method_46747(class_5468.field_26254);

            return spawnCustomStructure(
                    new class_5434(new class_3195.class_7302(
                            l.method_30349().method_46759(class_7924.field_41236).orElseThrow().method_46735(class_6908.field_36505),
                            Map.of(),
                            class_2893.class_2895.field_13173,
                            class_5847.field_28922
                    ),
                            class_6880.method_40223(new class_3785(
                                    empty,
                                    ImmutableList.of(
                                            Pair.of(class_3784.method_30435("bastion/hoglin_stable/air_base", bastionGenericDegradation), 1)
                                    ),
                                    class_3785.class_3786.field_16687
                            )),
                            6,
                            class_6121.method_35383(class_5843.method_33841(33)),
                            false
                    )
            );
        });
        put("bastion_remnant_treasure", l -> {
            class_5455 regs = l.method_30349();

            class_7871<class_5497> processorLists = regs.method_30530(class_7924.field_41247);
            class_6880<class_5497> bastionGenericDegradation = processorLists.method_46747(class_5469.field_26280);

            class_7871<class_3785> pools = regs.method_30530(class_7924.field_41249);
            class_6880<class_3785> empty = pools.method_46747(class_5468.field_26254);

            return spawnCustomStructure(
                    new class_5434(new class_3195.class_7302(
                            l.method_30349().method_46759(class_7924.field_41236).orElseThrow().method_46735(class_6908.field_36505),
                            Map.of(),
                            class_2893.class_2895.field_13173,
                            class_5847.field_28922
                    ),
                            class_6880.method_40223(new class_3785(
                                    empty,
                                    ImmutableList.of(
                                            Pair.of(class_3784.method_30435("bastion/treasure/big_air_full", bastionGenericDegradation), 1)
                                    ),
                                    class_3785.class_3786.field_16687
                            )),
                            6,
                            class_6121.method_35383(class_5843.method_33841(33)),
                            false
                    )
            );
        });
        put("bastion_remnant_bridge", l -> {
            class_5455 regs = l.method_30349();

            class_7871<class_5497> processorLists = regs.method_30530(class_7924.field_41247);
            class_6880<class_5497> bastionGenericDegradation = processorLists.method_46747(class_5469.field_26280);

            class_7871<class_3785> pools = regs.method_30530(class_7924.field_41249);
            class_6880<class_3785> empty = pools.method_46747(class_5468.field_26254);

            return spawnCustomStructure(
                    new class_5434(new class_3195.class_7302(
                            l.method_30349().method_46759(class_7924.field_41236).orElseThrow().method_46735(class_6908.field_36505),
                            Map.of(),
                            class_2893.class_2895.field_13173,
                            class_5847.field_28922
                    ),
                            class_6880.method_40223(new class_3785(
                                    empty,
                                    ImmutableList.of(
                                            Pair.of(class_3784.method_30435("bastion/bridge/starting_pieces/entrance_base", bastionGenericDegradation), 1)
                                    ),
                                    class_3785.class_3786.field_16687
                            )),
                            6,
                            class_6121.method_35383(class_5843.method_33841(33)),
                            false
                    )
            );
        });
    }};


    public static boolean plopAnywhere(class_3195 structure, class_3218 world, class_2338 pos, class_2794 generator, boolean wireOnly)
    {
        ThreadLocal<Boolean> checks = Vanilla.skipGenerationChecks(world);
        checks.set(true);
        try
        {
            class_3449 start = structure.method_41614(class_6880.method_40223(structure), world.method_27983(), world.method_30349(), generator, generator.method_12098(), world.method_14178().method_41248(), world.method_14183(), world.method_8412(), new class_1923(pos), 0, world, b -> true);
            if (start == class_3449.field_16713)
            {
                return false;
            }
            class_5819 rand = class_5819.method_43049(world.method_8409().method_43054());
            int j = pos.method_10263() >> 4;
            int k = pos.method_10260() >> 4;
            long chId = class_1923.method_8331(j, k);
            world.method_8497(j, k).method_12184(structure, start);
            world.method_8497(j, k).method_12182(structure, chId);

            class_3341 box = start.method_14969();

            if (!wireOnly)
            {
                class_2378<class_3195> registry3 = world.method_30349().method_30530(class_7924.field_41246);
                world.method_36972(() -> {
                    Objects.requireNonNull(structure);
                    return registry3.method_29113(structure).map(Object::toString).orElseGet(structure::toString);
                });
                start.method_14974(world, world.method_27056(), generator, rand, box, new class_1923(j, k));
            }
            //structurestart.notifyPostProcessAt(new ChunkPos(j, k));
            int i = Math.max(box.method_35414(), box.method_14663()) / 16 + 1;

            //int i = getRadius();
            for (int k1 = j - i; k1 <= j + i; ++k1)
            {
                for (int l1 = k - i; l1 <= k + i; ++l1)
                {
                    if (k1 == j && l1 == k)
                    {
                        continue;
                    }
                    if (box.method_14669(k1 << 4, l1 << 4, (k1 << 4) + 15, (l1 << 4) + 15))
                    {
                        world.method_8497(k1, l1).method_12182(structure, chId);
                    }
                }
            }
        }
        catch (Exception booboo)
        {
            CarpetScriptServer.LOG.error("Unknown Exception while plopping structure: " + booboo, booboo);
            return false;
        }
        finally
        {
            checks.set(false);
        }
        return true;
    }
}
