package carpet.script.utils;

import carpet.script.CarpetScriptServer;
import carpet.script.exception.InternalExpressionException;
import carpet.script.exception.ThrowStatement;
import carpet.script.exception.Throwables;
import carpet.script.external.Carpet;
import carpet.script.external.Vanilla;
import carpet.script.language.Sys;
import carpet.script.utils.shapes.ShapeDirection;
import carpet.script.value.AbstractListValue;
import carpet.script.value.BlockValue;
import carpet.script.value.BooleanValue;
import carpet.script.value.EntityValue;
import carpet.script.value.FormattedTextValue;
import carpet.script.value.ListValue;
import carpet.script.value.MapValue;
import carpet.script.value.NBTSerializableValue;
import carpet.script.value.NumericValue;
import carpet.script.value.StringValue;
import carpet.script.value.Value;
import carpet.script.value.ValueConversions;

import com.google.common.collect.Sets;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_243;
import net.minecraft.class_2481;
import net.minecraft.class_2487;
import net.minecraft.class_2489;
import net.minecraft.class_2494;
import net.minecraft.class_2497;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_2512;
import net.minecraft.class_2514;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5819;
import net.minecraft.class_7924;
import net.minecraft.class_9848;
import net.minecraft.server.MinecraftServer;
import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Supplier;

import static java.util.Map.entry;

public class ShapeDispatcher
{
    public record ShapeWithConfig(ExpiringShape shape, Map<String, Value> config)
    {
    }

    public static ShapeWithConfig fromFunctionArgs(
            MinecraftServer server, class_3218 world,
            List<Value> lv,
            Set<class_3222> playerSet
    )
    {
        if (lv.size() < 3)
        {
            throw new InternalExpressionException("'draw_shape' takes at least three parameters, shape name, duration, and its params");
        }
        String shapeType = lv.get(0).getString();
        Value duration = NumericValue.asNumber(lv.get(1), "duration");
        Map<String, Value> params;
        if (lv.size() == 3)
        {
            Value paramValue = lv.get(2);
            if (paramValue instanceof final MapValue map)
            {
                params = new HashMap<>();
                map.getMap().forEach((key, value) -> params.put(key.getString(), value));
            }
            else if (paramValue instanceof final ListValue list)
            {
                params = parseParams(list.getItems());
            }
            else
            {
                throw new InternalExpressionException("Parameters for 'draw_shape' need to be defined either in a list or a map");
            }
        }
        else
        {
            List<Value> paramList = new ArrayList<>();
            for (int i = 2; i < lv.size(); i++)
            {
                paramList.add(lv.get(i));
            }
            params = ShapeDispatcher.parseParams(paramList);
        }
        params.putIfAbsent("dim", new StringValue(world.method_27983().method_29177().toString()));
        params.putIfAbsent("duration", duration);

        if (params.containsKey("player"))
        {
            Value players = params.get("player");
            List<Value> playerVals;
            if (players instanceof final ListValue list)
            {
                playerVals = list.getItems();
            }
            else
            {
                playerVals = Collections.singletonList(players);
            }
            for (Value pVal : playerVals)
            {
                class_3222 player = EntityValue.getPlayerByValue(server, pVal);
                if (player == null)
                {
                    throw new InternalExpressionException("'player' parameter needs to represent an existing player, not " + pVal.getString());
                }
                playerSet.add(player);
            }
            params.remove("player");
        }
        return new ShapeWithConfig(ShapeDispatcher.create(server, shapeType, params), params);
    }

    public static void sendShape(Collection<class_3222> players, List<ShapeWithConfig> shapes, class_5455 regs)
    {
        List<class_3222> clientPlayers = new ArrayList<>();
        List<class_3222> alternativePlayers = new ArrayList<>();
        for (class_3222 player : players)
        {
            (Carpet.isValidCarpetPlayer(player) ? clientPlayers : alternativePlayers).add(player);
        }
        if (!clientPlayers.isEmpty())
        {
            class_2499 tag = new class_2499();
            int tagcount = 0;
            for (ShapeWithConfig s : shapes)
            {
                tag.add(ExpiringShape.toTag(s.config(), regs));  // 4000 shapes limit boxes
                if (tagcount++ > 1000)
                {
                    tagcount = 0;
                    class_2520 finalTag = tag;
                    clientPlayers.forEach(p -> Vanilla.sendScarpetShapesDataToPlayer(p, finalTag));
                    tag = new class_2499();
                }
            }
            class_2520 finalTag = tag;
            if (!tag.isEmpty())
            {
                clientPlayers.forEach(p -> Vanilla.sendScarpetShapesDataToPlayer(p, finalTag));
            }
        }
        if (!alternativePlayers.isEmpty())
        {
            List<Consumer<class_3222>> alternatives = new ArrayList<>();
            shapes.forEach(s -> alternatives.add(s.shape().alternative()));
            alternativePlayers.forEach(p -> alternatives.forEach(a -> a.accept(p)));
        }
    }

    public static class_2394 getParticleData(String name, class_5455 regs)
    {
        try
        {
            return ParticleParser.getEffect(name, regs);
        }
        catch (IllegalArgumentException e)
        {
            throw new ThrowStatement(name, Throwables.UNKNOWN_PARTICLE);
        }
    }

    public static Map<String, Value> parseParams(List<Value> items)
    {
        // parses params from API function
        if (items.size() % 2 == 1)
        {
            throw new InternalExpressionException("Shape parameters list needs to be of even size");
        }
        Map<String, Value> param = new HashMap<>();
        int i = 0;
        while (i < items.size())
        {
            String name = items.get(i).getString();
            Value val = items.get(i + 1);
            param.put(name, val);
            i += 2;
        }
        return param;
    }

    public static ExpiringShape create(MinecraftServer server, String shapeType, Map<String, Value> userParams)
    {
        userParams.put("shape", new StringValue(shapeType));
        userParams.keySet().forEach(key -> {
            Param param = Param.of.get(key);
            if (param == null)
            {
                throw new InternalExpressionException("Unknown feature for shape: " + key);
            }
            userParams.put(key, param.validate(userParams, server, userParams.get(key)));
        });
        BiFunction<Map<String, Value>, class_5455, ExpiringShape> factory = ExpiringShape.shapeProviders.get(shapeType);
        if (factory == null)
        {
            throw new InternalExpressionException("Unknown shape: " + shapeType);
        }
        return factory.apply(userParams, server.method_30611());
    }

    // client
    @Nullable
    public static ExpiringShape fromTag(class_2487 tag, class_1937 level)
    {
        Map<String, Value> options = new HashMap<>();
        for (String key : tag.method_10541())
        {
            Param decoder = Param.of.get(key);
            if (decoder == null)
            {
                CarpetScriptServer.LOG.info("Unknown parameter for shape: " + key);
                return null;
            }
            Value decodedValue = decoder.decode(tag.method_10580(key), level);
            options.put(key, decodedValue);
        }
        Value shapeValue = options.get("shape");
        if (shapeValue == null)
        {
            CarpetScriptServer.LOG.info("Shape id missing in " + String.join(", ", tag.method_10541()));
            return null;
        }
        BiFunction<Map<String, Value>, class_5455, ExpiringShape> factory = ExpiringShape.shapeProviders.get(shapeValue.getString());
        if (factory == null)
        {
            CarpetScriptServer.LOG.info("Unknown shape: " + shapeValue.getString());
            return null;
        }
        try
        {
            return factory.apply(options, level.method_30349());
        }
        catch (InternalExpressionException exc)
        {
            CarpetScriptServer.LOG.info(exc.getMessage());
        }
        return null;
    }

    public abstract static class ExpiringShape
    {
        public static final Map<String, BiFunction<Map<String, Value>, class_5455, ExpiringShape>> shapeProviders = new HashMap<>()
        {{
            put("line", creator(Line::new));
            put("box", creator(Box::new));
            put("sphere", creator(Sphere::new));
            put("cylinder", creator(Cylinder::new));
            put("label", creator(DisplayedText::new));
            put("polygon", creator(Polyface::new));
            put("block", creator(() -> new DisplayedSprite(false)));
            put("item", creator(() -> new DisplayedSprite(true)));
        }};

        private static BiFunction<Map<String, Value>, class_5455, ExpiringShape> creator(Supplier<ExpiringShape> shapeFactory)
        {
            return (o, regs) -> {
                ExpiringShape shape = shapeFactory.get();
                shape.fromOptions(o, regs);
                return shape;
            };
        }

        float lineWidth;
        protected float r, g, b, a;
        protected int color;
        protected float fr, fg, fb, fa;
        protected int fillColor;
        protected int duration = 0;
        private long key;
        protected int followEntity;
        protected String snapTo;
        protected boolean snapX, snapY, snapZ;
        protected boolean discreteX, discreteY, discreteZ;
        protected class_5321<class_1937> shapeDimension;
        protected boolean debug;


        protected ExpiringShape()
        {
        }

        public static class_2487 toTag(Map<String, Value> params, class_5455 regs)
        {
            class_2487 tag = new class_2487();
            params.forEach((k, v) -> {
                class_2520 valTag = Param.of.get(k).toTag(v, regs);
                if (valTag != null)
                {
                    tag.method_10566(k, valTag);
                }
            });
            return tag;
        }

        private void fromOptions(Map<String, Value> options, class_5455 regs)
        {
            Set<String> optionalParams = optionalParams();
            Set<String> requiredParams = requiredParams();
            Set<String> all = Sets.union(optionalParams, requiredParams);
            if (!all.containsAll(options.keySet()))
            {
                throw new InternalExpressionException("Received unexpected parameters for shape: " + Sets.difference(options.keySet(), all));
            }
            if (!options.keySet().containsAll(requiredParams))
            {
                throw new InternalExpressionException("Missing required parameters for shape: " + Sets.difference(requiredParams, options.keySet()));
            }
            options.keySet().forEach(k -> {
                if (!this.canTake(k))
                {
                    throw new InternalExpressionException("Parameter " + k + " doesn't apply for shape " + options.get("shape").getString());
                }
            });
            init(options, regs);
        }


        protected void init(Map<String, Value> options, class_5455 regs)
        {

            duration = NumericValue.asNumber(options.get("duration")).getInt();

            lineWidth = NumericValue.asNumber(options.getOrDefault("line", optional.get("line"))).getFloat();

            fillColor = NumericValue.asNumber(options.getOrDefault("fill", optional.get("fill"))).getInt();
            this.fr = (fillColor >> 24 & 0xFF) / 255.0F;
            this.fg = (fillColor >> 16 & 0xFF) / 255.0F;
            this.fb = (fillColor >> 8 & 0xFF) / 255.0F;
            this.fa = (fillColor & 0xFF) / 255.0F;

            color = NumericValue.asNumber(options.getOrDefault("color", optional.get("color"))).getInt();
            this.r = (color >> 24 & 0xFF) / 255.0F;
            this.g = (color >> 16 & 0xFF) / 255.0F;
            this.b = (color >> 8 & 0xFF) / 255.0F;
            this.a = (color & 0xFF) / 255.0F;

            debug = false;
            if (options.containsKey("debug"))
            {
                debug = options.get("debug").getBoolean();
            }

            key = 0;
            followEntity = -1;
            shapeDimension = class_5321.method_29179(class_7924.field_41223, class_2960.method_60654(options.get("dim").getString()));
            if (options.containsKey("follow"))
            {
                followEntity = NumericValue.asNumber(options.getOrDefault("follow", optional.get("follow"))).getInt();
                snapTo = options.getOrDefault("snap", optional.get("snap")).getString().toLowerCase(Locale.ROOT);
                snapX = snapTo.contains("x");
                snapY = snapTo.contains("y");
                snapZ = snapTo.contains("z");
                discreteX = snapTo.contains("dx");
                discreteY = snapTo.contains("dy");
                discreteZ = snapTo.contains("dz");
            }
        }

        public int getExpiry()
        {
            return duration;
        }

        public class_243 toAbsolute(class_1297 e, class_243 vec, float partialTick)
        {
            return vec.method_1031(
                    snapX ? (discreteX ? class_3532.method_15357(e.method_23317()) : class_3532.method_16436(partialTick, e.field_6014, e.method_23317())) : 0.0,
                    snapY ? (discreteY ? class_3532.method_15357(e.method_23318()) : class_3532.method_16436(partialTick, e.field_6036, e.method_23318())) : 0.0,
                    snapZ ? (discreteZ ? class_3532.method_15357(e.method_23321()) : class_3532.method_16436(partialTick, e.field_5969, e.method_23321())) : 0.0
            );
        }

        public class_243 relativiseRender(class_1937 world, class_243 vec, float partialTick)
        {
            if (followEntity < 0)
            {
                return vec;
            }
            class_1297 e = world.method_8469(followEntity);
            if (e == null)
            {
                return vec;
            }
            return toAbsolute(e, vec, partialTick);
        }

        public class_243 vecFromValue(Value value)
        {
            if (!(value instanceof final ListValue list))
            {
                throw new InternalExpressionException("decoded value of " + value.getPrettyString() + " is not a triple");
            }
            List<Value> elements = list.getItems();
            return new class_243(
                    NumericValue.asNumber(elements.get(0)).getDouble(),
                    NumericValue.asNumber(elements.get(1)).getDouble(),
                    NumericValue.asNumber(elements.get(2)).getDouble()
            );
        }

        protected class_2394 replacementParticle(class_5455 regs)
        {
            boolean bg = fa == 0;
            return new class_2390(class_9848.method_61318(1.0f, (bg ?r:fr), (bg ?r:fr), (bg ?r:fr)), 1);
        }


        public abstract Consumer<class_3222> alternative();

        public long key(class_5455 regs)
        {
            if (key != 0)
            {
                return key;
            }
            key = calcKey(regs);
            return key;
        }

        protected long calcKey(class_5455 regs)
        { // using FNV-1a algorithm
            long hash = -3750763034362895579L;
            hash ^= shapeDimension.hashCode();
            hash *= 1099511628211L;
            hash ^= color;
            hash *= 1099511628211L;
            hash ^= followEntity;
            hash *= 1099511628211L;
            hash ^= Boolean.hashCode(debug);
            hash *= 1099511628211L;
            if (followEntity >= 0)
            {
                hash ^= snapTo.hashCode();
                hash *= 1099511628211L;
            }
            hash ^= Float.hashCode(lineWidth);
            hash *= 1099511628211L;
            if (fa != 0.0)
            {
                hash = 31 * hash + fillColor;
                hash *= 1099511628211L;
            }
            return hash;
        }

        private static final double xdif = new Random('x').nextDouble();
        private static final double ydif = new Random('y').nextDouble();
        private static final double zdif = new Random('z').nextDouble();

        int vec3dhash(class_243 vec)
        {
            return vec.method_1031(xdif, ydif, zdif).hashCode();
        }

        // list of params that need to be there
        private final Set<String> required = Set.of("duration", "shape", "dim");
        private final Map<String, Value> optional = Map.of(
                "color", new NumericValue(-1),
                "follow", new NumericValue(-1),
                "line", new NumericValue(2.0),
                "debug", Value.FALSE,
                "fill", new NumericValue(0xffffff00),
                "snap", new StringValue("xyz")
        );

        protected Set<String> requiredParams()
        {
            return required;
        }

        // list of params that can be there, with defaults
        protected Set<String> optionalParams()
        {
            return optional.keySet();
        }

        private boolean canTake(String param)
        {
            return requiredParams().contains(param) || optionalParams().contains(param);
        }
    }

    public static class DisplayedText extends ExpiringShape
    {
        private final Set<String> required = Set.of("pos", "text");
        private final Map<String, Value> optional = Map.ofEntries(
                entry("facing", new StringValue("player")),
                entry("raise", new NumericValue(0)),
                entry("tilt", new NumericValue(0)),
                entry("lean", new NumericValue(0)),
                entry("turn", new NumericValue(0)),
                entry("indent", new NumericValue(0)),
                entry("height", new NumericValue(0)),
                entry("align", new StringValue("center")),
                entry("size", new NumericValue(10)),
                entry("value", Value.NULL),
                entry("doublesided", new NumericValue(0)));

        @Override
        protected Set<String> requiredParams()
        {
            return Sets.union(super.requiredParams(), required);
        }

        @Override
        protected Set<String> optionalParams()
        {
            return Sets.union(super.optionalParams(), optional.keySet());
        }

        public DisplayedText()
        {
        }

        class_243 pos;
        String text;
        int textcolor;
        int textbck;

        ShapeDirection facing;
        float raise;
        float tilt;
        float lean;
        float turn;
        float size;
        float indent;
        int align;
        float height;
        class_2561 value;
        boolean doublesided;

        @Override
        protected void init(Map<String, Value> options, class_5455 regs)
        {
            super.init(options, regs);
            pos = vecFromValue(options.get("pos"));
            value = ((FormattedTextValue) options.get("text")).getText();
            text = value.getString();
            if (options.containsKey("value"))
            {
                value = ((FormattedTextValue) options.get("value")).getText();
            }
            textcolor = rgba2argb(color);
            textbck = rgba2argb(fillColor);
            String dir = options.getOrDefault("facing", optional.get("facing")).getString();
            facing = ShapeDirection.fromString(dir);
            align = 0;
            if (options.containsKey("align"))
            {
                String alignStr = options.get("align").getString();
                if ("right".equalsIgnoreCase(alignStr))
                {
                    align = 1;
                }
                else if ("left".equalsIgnoreCase(alignStr))
                {
                    align = -1;
                }
            }
            doublesided = false;
            if (options.containsKey("doublesided"))
            {
                doublesided = options.get("doublesided").getBoolean();
            }

            raise = NumericValue.asNumber(options.getOrDefault("raise", optional.get("raise"))).getFloat();
            tilt = NumericValue.asNumber(options.getOrDefault("tilt", optional.get("tilt"))).getFloat();
            lean = NumericValue.asNumber(options.getOrDefault("lean", optional.get("lean"))).getFloat();
            turn = NumericValue.asNumber(options.getOrDefault("turn", optional.get("turn"))).getFloat();
            indent = NumericValue.asNumber(options.getOrDefault("indent", optional.get("indent"))).getFloat();
            height = NumericValue.asNumber(options.getOrDefault("height", optional.get("height"))).getFloat();

            size = NumericValue.asNumber(options.getOrDefault("size", optional.get("size"))).getFloat();
        }

        private int rgba2argb(int color)
        {
            int r = Math.max(1, color >> 24 & 0xFF);
            int g = Math.max(1, color >> 16 & 0xFF);
            int b = Math.max(1, color >> 8 & 0xFF);
            int a = color & 0xFF;
            return (a << 24) + (r << 16) + (g << 8) + b;
        }

        @Override
        public Consumer<class_3222> alternative()
        {
            return s -> {
            };
        }

        @Override
        public long calcKey(class_5455 regs)
        {
            long hash = super.calcKey(regs);
            hash ^= 5;
            hash *= 1099511628211L;
            hash ^= vec3dhash(pos);
            hash *= 1099511628211L;
            hash ^= text.hashCode();
            hash *= 1099511628211L;
            if (facing != null)
            {
                hash ^= facing.hashCode();
            }
            hash *= 1099511628211L;
            hash ^= Float.hashCode(raise);
            hash *= 1099511628211L;
            hash ^= Float.hashCode(tilt);
            hash *= 1099511628211L;
            hash ^= Float.hashCode(lean);
            hash *= 1099511628211L;
            hash ^= Float.hashCode(turn);
            hash *= 1099511628211L;
            hash ^= Float.hashCode(indent);
            hash *= 1099511628211L;
            hash ^= Float.hashCode(height);
            hash *= 1099511628211L;
            hash ^= Float.hashCode(size);
            hash *= 1099511628211L;
            hash ^= Integer.hashCode(align);
            hash *= 1099511628211L;
            hash ^= Boolean.hashCode(doublesided);
            hash *= 1099511628211L;

            return hash;
        }
    }

    public static class DisplayedSprite extends ExpiringShape
    {
        private final Set<String> required = Set.of("pos");
        private final Map<String, Value> optional = Map.ofEntries(
                entry("facing", new StringValue("north")),
                entry("tilt", new NumericValue(0)),
                entry("lean", new NumericValue(0)),
                entry("turn", new NumericValue(0)),
                entry("scale", ListValue.fromTriple(1, 1, 1)),
                entry("blocklight", new NumericValue(-1)),
                entry("skylight", new NumericValue(-1)));
        private final boolean isitem;

        @Override
        protected Set<String> requiredParams()
        {
            return Sets.union(Sets.union(super.requiredParams(), required), Set.of(isitem ? "item" : "block"));
        }

        @Override
        protected Set<String> optionalParams()
        {
            return Sets.union(Sets.union(super.optionalParams(), optional.keySet()), isitem ? Set.of("variant") : Set.of());
        }

        public DisplayedSprite(boolean i)
        {
            isitem = i;
        }

        class_243 pos;

        ShapeDirection facing;

        float tilt;
        float lean;
        float turn;

        int blockLight;
        int skyLight;

        float scaleX = 1.0f;
        float scaleY = 1.0f;
        float scaleZ = 1.0f;
        class_2487 blockEntity;
        class_2680 blockState;
        class_1799 item = null;
        String itemTransformType;

        @Override
        protected void init(Map<String, Value> options, class_5455 regs)
        {
            super.init(options, regs);
            pos = vecFromValue(options.get("pos"));
            if (!this.isitem)
            {
                BlockValue block = (BlockValue) options.get("block");
                blockState = block.getBlockState();
                blockEntity = block.getData();
            }
            else
            {
                this.item = class_1799.field_24671.parse(regs.method_57093(class_2509.field_11560), ((NBTSerializableValue) options.get("item")).getCompoundTag() ).getOrThrow(s -> new InternalExpressionException("Failed to parse item stack data: " + s));
            }
            blockLight = NumericValue.asNumber(options.getOrDefault("blocklight", optional.get("blocklight"))).getInt();
            if (blockLight > 15)
            {
                blockLight = 15;
            }
            skyLight = NumericValue.asNumber(options.getOrDefault("skylight", optional.get("skylight"))).getInt();
            if (skyLight > 15)
            {
                skyLight = 15;
            }

            itemTransformType = "none";
            if (options.containsKey("variant"))
            {
                itemTransformType = options.get("variant").getString().toLowerCase(Locale.ROOT);
            }

            String dir = options.getOrDefault("facing", optional.get("facing")).getString();
            facing = ShapeDirection.fromString(dir);

            tilt = NumericValue.asNumber(options.getOrDefault("tilt", optional.get("tilt"))).getFloat();
            lean = NumericValue.asNumber(options.getOrDefault("lean", optional.get("lean"))).getFloat();
            turn = NumericValue.asNumber(options.getOrDefault("turn", optional.get("turn"))).getFloat();
            List<Value> scale = ((ListValue) options.getOrDefault("scale", optional.get("scale"))).unpack();
            scaleY = NumericValue.asNumber(scale.get(1)).getFloat();
            scaleX = NumericValue.asNumber(scale.get(0)).getFloat();
            scaleZ = NumericValue.asNumber(scale.get(2)).getFloat();
        }

        @Override
        public Consumer<class_3222> alternative()
        {
            return p -> {
                class_2394 particle;
                class_2378<class_2248> blocks = p.method_5682().method_30611().method_30530(class_7924.field_41254);
                if (this.isitem)
                {
                    if (class_2248.method_9503(this.item.method_7909()).method_9564().method_26215())
                    {
                        return;
                    }
                    particle = getParticleData("block_marker " + blocks.method_10221(class_2248.method_9503(this.item.method_7909())), p.method_51469().method_30349());
                }
                else
                {
                    particle = getParticleData("block_marker " + blocks.method_10221(this.blockState.method_26204()), p.method_51469().method_30349());
                }

                class_243 v = relativiseRender(p.method_51469(), this.pos, 0);
                p.method_51469().method_14166(p, particle, true, true, v.field_1352, v.field_1351, v.field_1350, 1, 0.0, 0.0, 0.0, 0.0);
            };
        }

        @Override
        public long calcKey(class_5455 regs)
        {
            long hash = super.calcKey(regs);
            hash ^= 7;
            hash *= 1099511628211L;
            hash ^= Boolean.hashCode(isitem);
            hash *= 1099511628211L;
            hash ^= vec3dhash(pos);
            hash *= 1099511628211L;
            if (facing != null)
            {
                hash ^= facing.hashCode();
            }
            hash *= 1099511628211L;
            hash ^= Float.hashCode(tilt);
            hash *= 1099511628211L;
            hash ^= Float.hashCode(lean);
            hash *= 1099511628211L;
            hash ^= Float.hashCode(turn);
            hash *= 1099511628211L;
            hash ^= Float.hashCode(scaleY);
            hash *= 1099511628211L;
            hash ^= Float.hashCode(scaleZ);
            hash *= 1099511628211L;
            hash ^= Float.hashCode(scaleX);
            hash *= 1099511628211L;
            hash ^= Float.hashCode(skyLight);
            hash *= 1099511628211L;
            hash ^= Float.hashCode(blockLight);
            hash *= 1099511628211L;
            if (blockEntity != null)
            {
                hash ^= blockEntity.toString().hashCode();
            }
            hash *= 1099511628211L;
            if (blockState != null)
            {
                hash ^= blockState.hashCode();
            }
            hash *= 1099511628211L;
            hash ^= ValueConversions.of(item, regs).getString().hashCode();
            hash *= 1099511628211L;
            hash ^= itemTransformType.hashCode();
            hash *= 1099511628211L;

            return hash;
        }
    }


    public static class Box extends ExpiringShape
    {
        private final Set<String> required = Set.of("from", "to");
        private final Map<String, Value> optional = Map.of();

        @Override
        protected Set<String> requiredParams()
        {
            return Sets.union(super.requiredParams(), required);
        }

        @Override
        protected Set<String> optionalParams()
        {
            return Sets.union(super.optionalParams(), optional.keySet());
        }

        public Box()
        {
        }

        class_243 from;
        class_243 to;

        @Override
        protected void init(Map<String, Value> options, class_5455 regs)
        {
            super.init(options, regs);
            from = vecFromValue(options.get("from"));
            to = vecFromValue(options.get("to"));
        }

        @Override
        public Consumer<class_3222> alternative()
        {
            double density = Math.max(2.0, from.method_1022(to) / 50 / (a + 0.1));
            return p ->
            {
                if (p.method_51469().method_27983() == shapeDimension)
                {
                    particleMesh(
                            Collections.singletonList(p),
                            replacementParticle(p.method_51469().method_30349()),
                            density,
                            relativiseRender(p.method_51469(), from, 0),
                            relativiseRender(p.method_51469(), to, 0)
                    );
                }
            };
        }

        @Override
        public long calcKey(class_5455 regs)
        {
            long hash = super.calcKey(regs);
            hash ^= 1;
            hash *= 1099511628211L;
            hash ^= vec3dhash(from);
            hash *= 1099511628211L;
            hash ^= vec3dhash(to);
            hash *= 1099511628211L;
            return hash;
        }

        public static int particleMesh(List<class_3222> playerList, class_2394 particle, double density,
                                       class_243 from, class_243 to)
        {
            double x1 = from.field_1352;
            double y1 = from.field_1351;
            double z1 = from.field_1350;
            double x2 = to.field_1352;
            double y2 = to.field_1351;
            double z2 = to.field_1350;
            return
                    drawParticleLine(playerList, particle, new class_243(x1, y1, z1), new class_243(x1, y2, z1), density) +
                            drawParticleLine(playerList, particle, new class_243(x1, y2, z1), new class_243(x2, y2, z1), density) +
                            drawParticleLine(playerList, particle, new class_243(x2, y2, z1), new class_243(x2, y1, z1), density) +
                            drawParticleLine(playerList, particle, new class_243(x2, y1, z1), new class_243(x1, y1, z1), density) +

                            drawParticleLine(playerList, particle, new class_243(x1, y1, z2), new class_243(x1, y2, z2), density) +
                            drawParticleLine(playerList, particle, new class_243(x1, y2, z2), new class_243(x2, y2, z2), density) +
                            drawParticleLine(playerList, particle, new class_243(x2, y2, z2), new class_243(x2, y1, z2), density) +
                            drawParticleLine(playerList, particle, new class_243(x2, y1, z2), new class_243(x1, y1, z2), density) +

                            drawParticleLine(playerList, particle, new class_243(x1, y1, z1), new class_243(x1, y1, z2), density) +
                            drawParticleLine(playerList, particle, new class_243(x1, y2, z1), new class_243(x1, y2, z2), density) +
                            drawParticleLine(playerList, particle, new class_243(x2, y2, z1), new class_243(x2, y2, z2), density) +
                            drawParticleLine(playerList, particle, new class_243(x2, y1, z1), new class_243(x2, y1, z2), density);
        }
    }

    public static class Polyface extends ExpiringShape
    {
        @Override
        public long calcKey(class_5455 regs)
        {
            long hash = super.calcKey(regs);
            hash ^= 6;
            hash *= 1099511628211L;
            hash ^= mode;
            hash *= 1099511628211L;
            hash ^= relative.hashCode();
            hash *= 1099511628211L;
            for (class_243 i : vertexList)
            {
                hash ^= vec3dhash(i);
                hash *= 1099511628211L;
            }
            hash ^= Boolean.hashCode(doublesided);
            hash *= 1099511628211L;
            hash ^= Integer.hashCode(vertexList.size());
            hash *= 1099511628211L;
            hash ^= Boolean.hashCode(inneredges);
            hash *= 1099511628211L;
            return hash;
        }

        ArrayList<class_243> alterPoint = null;
        final Random random = new Random();
        boolean doublesided;

        ArrayList<class_243> getAlterPoint(class_3222 p)
        {
            if (alterPoint != null)
            {
                return alterPoint;
            }
            alterPoint = new ArrayList<>();
            switch (mode)
            {
                case 4:
                    for (int i = 0; i < vertexList.size(); i++)
                    {
                        class_243 vecA = vertexList.get(i);
                        if (relative.get(i))
                        {
                            vecA = relativiseRender(p.method_51469(), vecA, 0);
                        }
                        i++;
                        class_243 vecB = vertexList.get(i);
                        if (relative.get(i))
                        {
                            vecB = relativiseRender(p.method_51469(), vecB, 0);
                        }
                        i++;
                        class_243 vecC = vertexList.get(i);
                        if (relative.get(i))
                        {
                            vecC = relativiseRender(p.method_51469(), vecC, 0);
                        }
                        alterDrawTriangles(vecA, vecB, vecC);
                    }
                    break;
                case 6:
                    class_243 vec0 = vertexList.get(0);
                    if (relative.get(0))
                    {
                        vec0 = relativiseRender(p.method_51469(), vec0, 0);
                    }
                    class_243 vec1 = vertexList.get(1);
                    if (relative.get(1))
                    {
                        vec1 = relativiseRender(p.method_51469(), vec1, 0);
                    }
                    for (int i = 2; i < vertexList.size(); i++)
                    {
                        class_243 vec = vertexList.get(i);
                        if (relative.get(i))
                        {
                            vec = relativiseRender(p.method_51469(), vec, 0);
                        }
                        alterDrawTriangles(vec0, vec1, vec);
                        vec1 = vec;
                    }
                    break;
                case 5:
                    class_243 vecA = vertexList.get(0);
                    if (relative.get(0))
                    {
                        vecA = relativiseRender(p.method_51469(), vecA, 0);
                    }
                    class_243 vecB = vertexList.get(1);
                    if (relative.get(1))
                    {
                        vecB = relativiseRender(p.method_51469(), vecB, 0);
                    }
                    for (int i = 2; i < vertexList.size(); i++)
                    {
                        class_243 vec = vertexList.get(i);
                        if (relative.get(i))
                        {
                            vec = relativiseRender(p.method_51469(), vec, 0);
                        }
                        alterDrawTriangles(vecA, vecB, vec);
                        vecA = vecB;
                        vecB = vec;
                    }
                    break;
                default:
                    break;
            }

            return alterPoint;
        }

        void alterDrawTriangles(class_243 a, class_243 b, class_243 c)
        {
            class_243 bb = b.method_1020(a);
            class_243 cc = c.method_1020(a);
            for (int i = 0; i / 8 < bb.method_1036(cc).method_1033(); i++)
            {
                double x = random.nextDouble();
                double y = random.nextDouble();
                alterPoint.add(a.method_1019(bb.method_1021(x / 2)).method_1019(cc.method_1021(y / 2)));
                if (x + y < 1)
                {
                    alterPoint.add(a.method_1019(bb.method_1021((x + 1) / 2)).method_1019(cc.method_1021(y / 2)));
                }
                else
                {
                    x = 1 - x;
                    y = 1 - y;
                    alterPoint.add(a.method_1019(bb.method_1021(x / 2)).method_1019(cc.method_1021((y + 1) / 2)));
                }
            }
        }

        @Override
        public Consumer<class_3222> alternative()
        {
            return p -> {
                if (p.method_51469().method_27983() != this.shapeDimension)
                {
                    return;
                }
                if (fa > 0.0f)
                {
                    class_2394 locparticledata = new class_2390(class_9848.method_61318(1.0f, fr, fg, fb), 1);
                    for (class_243 v : getAlterPoint(p))
                    {
                        p.method_51469().method_14166(p, locparticledata, true, true,
                                v.field_1352, v.field_1351, v.field_1350, 1,
                                0.0, 0.0, 0.0, 0.0);
                    }
                }
            };
        }

        private final Set<String> required = Set.of("points");
        private final Map<String, Value> optional = Map.ofEntries(
                entry("relative", Value.NULL),
                entry("mode", new StringValue("polygon")),
                entry("inner", Value.TRUE),
                entry("doublesided", Value.TRUE)
        );

        @Override
        protected Set<String> requiredParams()
        {
            return Sets.union(super.requiredParams(), required);
        }

        @Override
        protected Set<String> optionalParams()
        {
            return Sets.union(super.optionalParams(), optional.keySet());
        }

        ArrayList<class_243> vertexList = new ArrayList<>();
        int mode;
        ArrayList<Boolean> relative = new ArrayList<>();
        boolean inneredges;

        @Override
        protected void init(Map<String, Value> options, class_5455 regs)
        {
            super.init(options, regs);

            doublesided = options.getOrDefault("doublesided", optional.get("doublesided")).getBoolean();

            if (options.get("points") instanceof final AbstractListValue abl)
            {
                abl.forEach(x -> vertexList.add(vecFromValue(x)));
            }
            String modeOption = options.getOrDefault("mode", optional.get("mode")).getString();
            inneredges = options.getOrDefault("inner", optional.get("inner")).getBoolean();
            if (vertexList.size() < 3)
            {
                throw new IllegalArgumentException("Unexpected vertex list size: " + vertexList.size());
            }
            else if (vertexList.size() < 4)
            {
                inneredges = false;
            }
            if ("polygon".equals(modeOption))
            {
                this.mode = 6;
            }
            else if ("strip".equals(modeOption))
            {
                this.mode = 5;
            }
            else if ("triangles".equals(modeOption))
            {
                this.mode = 4;
                if (vertexList.size() % 3 != 0)
                {
                    throw new IllegalArgumentException("Unexpected vertex list size: " + vertexList.size());
                }
            }
            if (options.getOrDefault("relative", optional.get("relative")) instanceof final AbstractListValue abl)
            {
                Iterator<Value> it = abl.iterator();
                for (long i = 0L; i < vertexList.size(); i++)
                {
                    relative.add(it.hasNext() && it.next().getBoolean());//if part of it got defined.
                }
            }
            else if (options.getOrDefault("relative", optional.get("relative")) instanceof final BooleanValue boolv)
            {
                for (long i = 0L; i < vertexList.size(); i++)
                {
                    relative.add(boolv.getBoolean());//if it is a boolean.
                }
            }
            else
            {
                for (long i = 0L; i < vertexList.size(); i++)
                {
                    relative.add(true);//if there is nothing defined at all.
                }
            }

        }
    }

    public static class Line extends ExpiringShape
    {
        private final Set<String> required = Set.of("from", "to");
        private final Map<String, Value> optional = Map.of();

        @Override
        protected Set<String> requiredParams()
        {
            return Sets.union(super.requiredParams(), required);
        }

        @Override
        protected Set<String> optionalParams()
        {
            return Sets.union(super.optionalParams(), optional.keySet());
        }

        private Line()
        {
            super();
        }

        class_243 from;
        class_243 to;

        @Override
        protected void init(Map<String, Value> options, class_5455 regs)
        {
            super.init(options, regs);
            from = vecFromValue(options.get("from"));
            to = vecFromValue(options.get("to"));
        }

        @Override
        public Consumer<class_3222> alternative()
        {
            double density = Math.max(2.0, from.method_1022(to) / 50) / (a + 0.1);
            return p ->
            {
                if (p.method_51469().method_27983() == shapeDimension)
                {
                    drawParticleLine(
                            Collections.singletonList(p),
                            replacementParticle(p.method_51469().method_30349()),
                            relativiseRender(p.method_51469(), from, 0),
                            relativiseRender(p.method_51469(), to, 0),
                            density
                    );
                }
            };
        }

        @Override
        public long calcKey(class_5455 regs)
        {
            long hash = super.calcKey(regs);
            hash ^= 2;
            hash *= 1099511628211L;
            hash ^= vec3dhash(from);
            hash *= 1099511628211L;
            hash ^= vec3dhash(to);
            hash *= 1099511628211L;
            return hash;
        }
    }

    public static class Sphere extends ExpiringShape
    {
        private final Set<String> required = Set.of("center", "radius");
        private final Map<String, Value> optional = Map.of("level", Value.ZERO);

        @Override
        protected Set<String> requiredParams()
        {
            return Sets.union(super.requiredParams(), required);
        }

        @Override
        protected Set<String> optionalParams()
        {
            return Sets.union(super.optionalParams(), optional.keySet());
        }

        private Sphere()
        {
            super();
        }

        class_243 center;
        float radius;
        int level;
        int subdivisions;

        @Override
        protected void init(Map<String, Value> options, class_5455 regs)
        {
            super.init(options, regs);
            center = vecFromValue(options.get("center"));
            radius = NumericValue.asNumber(options.get("radius")).getFloat();
            level = NumericValue.asNumber(options.getOrDefault("level", optional.get("level"))).getInt();
            subdivisions = level;
            if (subdivisions <= 0)
            {
                subdivisions = Math.max(10, (int) (10 * Math.sqrt(radius)));
            }
        }

        @Override
        public Consumer<class_3222> alternative()
        {
            return p ->
            {
                int partno = Math.min(1000, 20 * subdivisions);
                class_5819 rand = p.method_51469().method_8409();
                class_3218 world = p.method_51469();
                class_2394 particle = replacementParticle(world.method_30349());

                class_243 ccenter = relativiseRender(world, center, 0);

                double ccx = ccenter.field_1352;
                double ccy = ccenter.field_1351;
                double ccz = ccenter.field_1350;

                for (int i = 0; i < partno; i++)
                {
                    float theta = (float) Math.asin(rand.method_43058() * 2.0 - 1.0);
                    float phi = (float) (2 * Math.PI * rand.method_43058());

                    double x = radius * class_3532.method_15362(theta) * class_3532.method_15362(phi);
                    double y = radius * class_3532.method_15362(theta) * class_3532.method_15374(phi);
                    double z = radius * class_3532.method_15374(theta);
                    world.method_14166(p, particle, true, true,
                            x + ccx, y + ccy, z + ccz, 1,
                            0.0, 0.0, 0.0, 0.0);
                }
            };
        }

        @Override
        public long calcKey(class_5455 regs)
        {
            long hash = super.calcKey(regs);
            hash ^= 3;
            hash *= 1099511628211L;
            hash ^= vec3dhash(center);
            hash *= 1099511628211L;
            hash ^= Double.hashCode(radius);
            hash *= 1099511628211L;
            hash ^= level;
            hash *= 1099511628211L;
            return hash;
        }
    }

    public static class Cylinder extends ExpiringShape
    {
        private final Set<String> required = Set.of("center", "radius");
        private final Map<String, Value> optional = Map.of(
                "level", Value.ZERO,
                "height", Value.ZERO,
                "axis", new StringValue("y")
        );

        @Override
        protected Set<String> requiredParams()
        {
            return Sets.union(super.requiredParams(), required);
        }

        @Override
        protected Set<String> optionalParams()
        {
            return Sets.union(super.optionalParams(), optional.keySet());
        }

        class_243 center;
        float height;
        float radius;
        int level;
        int subdivisions;
        class_2350.class_2351 axis;

        private Cylinder()
        {
            super();
        }

        @Override
        protected void init(Map<String, Value> options, class_5455 regs)
        {
            super.init(options, regs);
            center = vecFromValue(options.get("center"));
            radius = NumericValue.asNumber(options.get("radius")).getFloat();
            level = NumericValue.asNumber(options.getOrDefault("level", optional.get("level"))).getInt();
            subdivisions = level;
            if (subdivisions <= 0)
            {
                subdivisions = Math.max(10, (int) (10 * Math.sqrt(radius)));
            }
            height = NumericValue.asNumber(options.getOrDefault("height", optional.get("height"))).getFloat();
            axis = class_2350.class_2351.method_10177(options.getOrDefault("axis", optional.get("axis")).getString());
        }


        @Override
        public Consumer<class_3222> alternative()
        {
            return p ->
            {
                int partno = (int) Math.min(1000, Math.sqrt(20 * subdivisions * (1 + height)));
                class_5819 rand = p.method_51469().method_8409();
                class_3218 world = p.method_51469();
                class_2394 particle = replacementParticle(world.method_30349());

                class_243 ccenter = relativiseRender(world, center, 0);

                double ccx = ccenter.field_1352;
                double ccy = ccenter.field_1351;
                double ccz = ccenter.field_1350;

                if (axis == class_2350.class_2351.field_11052)
                {
                    for (int i = 0; i < partno; i++)
                    {
                        float d = rand.method_43057() * height;
                        float phi = (float) (2 * Math.PI * rand.method_43058());
                        double x = radius * class_3532.method_15362(phi);
                        double y = d;
                        double z = radius * class_3532.method_15374(phi);
                        world.method_14166(p, particle, true, true,x + ccx, y + ccy, z + ccz, 1, 0.0, 0.0, 0.0, 0.0);
                    }
                }
                else if (axis == class_2350.class_2351.field_11048)
                {
                    for (int i = 0; i < partno; i++)
                    {
                        float d = rand.method_43057() * height;
                        float phi = (float) (2 * Math.PI * rand.method_43058());
                        double x = d;
                        double y = radius * class_3532.method_15362(phi);
                        double z = radius * class_3532.method_15374(phi);
                        world.method_14166(p, particle, true, true, x + ccx, y + ccy, z + ccz, 1, 0.0, 0.0, 0.0, 0.0);
                    }
                }
                else  // Z
                {
                    for (int i = 0; i < partno; i++)
                    {
                        float d = rand.method_43057() * height;
                        float phi = (float) (2 * Math.PI * rand.method_43058());
                        double x = radius * class_3532.method_15374(phi);
                        double y = radius * class_3532.method_15362(phi);
                        double z = d;
                        world.method_14166(p, particle, true, true, x + ccx, y + ccy, z + ccz, 1, 0.0, 0.0, 0.0, 0.0);
                    }
                }
            };
        }

        @Override
        public long calcKey(class_5455 regs)
        {
            long hash = super.calcKey(regs);
            hash ^= 4;
            hash *= 1099511628211L;
            hash ^= vec3dhash(center);
            hash *= 1099511628211L;
            hash ^= Double.hashCode(radius);
            hash *= 1099511628211L;
            hash ^= Double.hashCode(height);
            hash *= 1099511628211L;
            hash ^= level;
            hash *= 1099511628211L;
            return hash;
        }
    }


    public abstract static class Param
    {
        public static final Map<String, Param> of = new HashMap<>()
        {{
            put("mode", new StringChoiceParam("mode", "polygon", "strip", "triangles"));
            put("relative", new OptionalBoolListParam("relative"));
            put("inner", new BoolParam("inner"));
            put("shape", new ShapeParam());
            put("dim", new DimensionParam());
            put("duration", new NonNegativeIntParam("duration"));
            put("color", new ColorParam("color"));
            put("follow", new EntityParam("follow"));
            put("variant", new StringChoiceParam("variant",
                    "NONE",
                    "THIRD_PERSON_LEFT_HAND",
                    "THIRD_PERSON_RIGHT_HAND",
                    "FIRST_PERSON_LEFT_HAND",
                    "FIRST_PERSON_RIGHT_HAND",
                    "HEAD",
                    "GUI",
                    "GROUND",
                    "FIXED")
            {
                @Override
                public Value validate(Map<String, Value> o, MinecraftServer s, Value v)
                {
                    return super.validate(o, s, new StringValue(v.getString().toUpperCase(Locale.ROOT)));
                }
            });
            put("snap", new StringChoiceParam("snap",
                    "xyz", "xz", "yz", "xy", "x", "y", "z",
                    "dxdydz", "dxdz", "dydz", "dxdy", "dx", "dy", "dz",
                    "xdz", "dxz", "ydz", "dyz", "xdy", "dxy",
                    "xydz", "xdyz", "xdydz", "dxyz", "dxydz", "dxdyz"
            ));
            put("line", new PositiveFloatParam("line"));
            put("fill", new ColorParam("fill"));

            put("from", new Vec3Param("from", false));
            put("to", new Vec3Param("to", true));
            put("center", new Vec3Param("center", false));
            put("pos", new Vec3Param("pos", false));
            put("radius", new PositiveFloatParam("radius"));
            put("level", new PositiveIntParam("level"));
            put("height", new FloatParam("height"));
            put("width", new FloatParam("width"));
            put("scale", new Vec3Param("scale", false)
            {
                @Override
                public Value validate(java.util.Map<String, Value> options, MinecraftServer server, Value value)
                {
                    if (value instanceof final NumericValue vn)
                    {
                        value = ListValue.of(vn, vn, vn);
                    }
                    return super.validate(options, server, value);
                }

            });
            put("axis", new StringChoiceParam("axis", "x", "y", "z"));
            put("points", new PointsParam("points"));
            put("text", new FormattedTextParam("text"));
            put("value", new FormattedTextParam("value"));
            put("size", new PositiveIntParam("size"));
            put("align", new StringChoiceParam("align", "center", "left", "right"));

            put("block", new BlockParam("block"));
            put("item", new ItemParam("item"));
            put("blocklight", new NonNegativeIntParam("blocklight"));
            put("skylight", new NonNegativeIntParam("skylight"));
            put("indent", new FloatParam("indent"));
            put("raise", new FloatParam("raise"));
            put("tilt", new FloatParam("tilt"));
            put("lean", new FloatParam("lean"));
            put("turn", new FloatParam("turn"));
            put("facing", new StringChoiceParam("facing", "player", "camera", "north", "south", "east", "west", "up", "down"));
            put("doublesided", new BoolParam("doublesided"));
            put("debug", new BoolParam("debug"));

        }};
        protected String id;

        protected Param(String id)
        {
            this.id = id;
        }

        @Nullable
        public abstract class_2520 toTag(Value value, final class_5455 regs); //validates value, returning null if not necessary to keep it and serialize

        public abstract Value validate(Map<String, Value> options, MinecraftServer server, Value value); // makes sure the value is proper

        public abstract Value decode(class_2520 tag, class_1937 level);
    }

    public static class OptionalBoolListParam extends Param
    {
        public OptionalBoolListParam(String id)
        {
            super(id);
        }

        @Override
        public class_2520 toTag(Value value, final class_5455 regs)
        {
            return value.toTag(true, regs);
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            if (tag instanceof final class_2499 list)
            {
                return ListValue.wrap(list.stream().map(x -> BooleanValue.of(((class_2514) x).method_10697() != 0)));
            }
            if (tag instanceof final class_2481 booltag)
            {
                return BooleanValue.of(booltag.method_10698() != 0);
            }
            return Value.NULL;
        }

        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            if (value instanceof final AbstractListValue lv)
            {
                return ListValue.wrap(lv.unpack().stream().map(Value::getBoolean).map(BooleanValue::of));
            }
            if (value instanceof BooleanValue || value.isNull())
            {
                return value;
            }
            return BooleanValue.of(value.getBoolean());
        }
    }

    public abstract static class StringParam extends Param
    {
        protected StringParam(String id)
        {
            super(id);
        }

        @Override
        public class_2520 toTag(Value value, final class_5455 regs)
        {
            return class_2519.method_23256(value.getString());
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            return new StringValue(tag.method_68658().get());
        }
    }

    public static class BlockParam extends Param
    {

        protected BlockParam(String id)
        {
            super(id);
        }

        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            if (value instanceof BlockValue)
            {
                return value;
            }
            return BlockValue.fromString(value.getString(), server.method_30002());
        }

        @Nullable
        @Override
        public class_2520 toTag(Value value, final class_5455 regs)
        {
            if (value instanceof final BlockValue blv)
            {
                class_2487 com = class_2512.method_10686(blv.getBlockState());
                class_2487 dataTag = blv.getData();
                if (dataTag != null)
                {
                    com.method_10566("TileEntityData", dataTag);
                }
                return com;
            }
            return null;
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            class_2680 bs = class_2512.method_10681(level.method_45448(class_7924.field_41254), (class_2487) tag);
            class_2487 compoundTag2 = null;
            if (((class_2487) tag).method_10545("TileEntityData"))
            {
                compoundTag2 = ((class_2487) tag).method_10562("TileEntityData").get();
            }
            return new BlockValue(bs, compoundTag2);
        }
    }

    public static class ItemParam extends Param
    {

        protected ItemParam(String id)
        {
            super(id);
        }

        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            class_1799 item = ValueConversions.getItemStackFromValue(value, true, server.method_30611());
            return new NBTSerializableValue(class_1799.field_24671.encodeStart(server.method_30611().method_57093(class_2509.field_11560), item).getOrThrow(s -> new InternalExpressionException("Failed to parse item stack data: " + s)));
        }

        @Override
        public class_2520 toTag(Value value, final class_5455 regs)
        {
            return ((NBTSerializableValue) value).getTag();
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            return new NBTSerializableValue(tag);
        }
    }

    public static class TextParam extends StringParam
    {
        protected TextParam(String id)
        {
            super(id);
        }

        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            return value;
        }
    }

    public static class FormattedTextParam extends StringParam
    {

        protected FormattedTextParam(String id)
        {
            super(id);
        }

        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            if (!(value instanceof FormattedTextValue))
            {
                value = new FormattedTextValue(class_2561.method_43470(value.getString()));
            }
            return value;
        }

        @Override
        public class_2520 toTag(Value value, final class_5455 regs)
        {
            if (!(value instanceof FormattedTextValue))
            {
                value = new FormattedTextValue(class_2561.method_43470(value.getString()));
            }
            return ((FormattedTextValue) value).serialize(regs);
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            return FormattedTextValue.deserialize(tag, level.method_30349());
        }
    }


    public static class StringChoiceParam extends StringParam
    {
        private final Set<String> options;

        public StringChoiceParam(String id, String... options)
        {
            super(id);
            this.options = Sets.newHashSet(options);
        }

        @Nullable
        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            if (this.options.contains(value.getString()))
            {
                return value;
            }
            return null;
        }
    }

    public static class DimensionParam extends StringParam
    {
        protected DimensionParam()
        {
            super("dim");
        }

        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            return value;
        }
    }

    public static class ShapeParam extends StringParam
    {
        protected ShapeParam()
        {
            super("shape");
        }

        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            String shape = value.getString();
            if (!ExpiringShape.shapeProviders.containsKey(shape))
            {
                throw new InternalExpressionException("Unknown shape: " + shape);
            }
            return value;
        }
    }

    public abstract static class NumericParam extends Param
    {
        protected NumericParam(String id)
        {
            super(id);
        }

        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            if (!(value instanceof NumericValue))
            {
                throw new InternalExpressionException("'" + id + "' needs to be a number");
            }
            return value;
        }
    }

    public static class BoolParam extends NumericParam
    {
        protected BoolParam(String id)
        {
            super(id);
        }

        @Override
        public class_2520 toTag(Value value, final class_5455 regs)
        {
            return class_2481.method_23234(value.getBoolean());
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            return BooleanValue.of(((class_2481) tag).method_10698() > 0);
        }
    }

    public static class FloatParam extends NumericParam
    {
        protected FloatParam(String id)
        {
            super(id);
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            return new NumericValue(((class_2494) tag).method_10700());
        }

        @Override
        public class_2520 toTag(Value value, final class_5455 regs)
        {
            return class_2494.method_23244(NumericValue.asNumber(value, id).getFloat());
        }
    }

    public abstract static class PositiveParam extends NumericParam
    {
        protected PositiveParam(String id)
        {
            super(id);
        }

        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            Value ret = super.validate(options, server, value);
            if (((NumericValue) ret).getDouble() <= 0)
            {
                throw new InternalExpressionException("'" + id + "' should be positive");
            }
            return ret;
        }
    }

    public static class PositiveFloatParam extends PositiveParam
    {
        protected PositiveFloatParam(String id)
        {
            super(id);
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            return new NumericValue(((class_2494) tag).method_10700());
        }

        @Override
        public class_2520 toTag(Value value, final class_5455 regs)
        {
            return class_2494.method_23244(NumericValue.asNumber(value, id).getFloat());
        }

    }

    public static class PositiveIntParam extends PositiveParam
    {
        protected PositiveIntParam(String id)
        {
            super(id);
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            return new NumericValue(((class_2497) tag).method_10701());
        }

        @Override
        public class_2520 toTag(Value value, final class_5455 regs)
        {
            return class_2497.method_23247(NumericValue.asNumber(value, id).getInt());
        }

    }

    public static class NonNegativeIntParam extends NumericParam
    {
        protected NonNegativeIntParam(String id)
        {
            super(id);
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            return new NumericValue(((class_2497) tag).method_10701());
        }

        @Override
        public class_2520 toTag(Value value, final class_5455 regs)
        {
            return class_2497.method_23247(NumericValue.asNumber(value, id).getInt());
        }

        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            Value ret = super.validate(options, server, value);
            if (((NumericValue) ret).getDouble() < 0)
            {
                throw new InternalExpressionException("'" + id + "' should be non-negative");
            }
            return ret;
        }
    }

    public static class NonNegativeFloatParam extends NumericParam
    {
        protected NonNegativeFloatParam(String id)
        {
            super(id);
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            return new NumericValue(((class_2494) tag).method_10700());
        }

        @Override
        public class_2520 toTag(Value value, final class_5455 regs)
        {
            return class_2494.method_23244(NumericValue.asNumber(value, id).getFloat());
        }

        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            Value ret = super.validate(options, server, value);
            if (((NumericValue) ret).getDouble() < 0)
            {
                throw new InternalExpressionException("'" + id + "' should be non-negative");
            }
            return ret;
        }
    }


    public static class Vec3Param extends Param
    {
        private final boolean roundsUpForBlocks;

        protected Vec3Param(String id, boolean doesRoundUpForBlocks)
        {
            super(id);
            roundsUpForBlocks = doesRoundUpForBlocks;
        }

        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            return validate(this, options, value, roundsUpForBlocks);
        }

        public static Value validate(Param p, Map<String, Value> options, Value value, boolean roundsUp)
        {
            if (value instanceof final BlockValue bv)
            {
                if (options.containsKey("follow"))
                {
                    throw new InternalExpressionException(p.id + " parameter cannot use blocks as positions for relative positioning due to 'follow' attribute being present");
                }
                class_2338 pos = bv.getPos();
                int offset = roundsUp ? 1 : 0;
                return ListValue.of(
                        new NumericValue(pos.method_10263() + offset),
                        new NumericValue(pos.method_10264() + offset),
                        new NumericValue(pos.method_10260() + offset)
                );
            }
            if (value instanceof final ListValue list)
            {
                List<Value> values = list.getItems();
                if (values.size() != 3)
                {
                    throw new InternalExpressionException("'" + p.id + "' requires 3 numerical values");
                }
                for (Value component : values)
                {
                    if (!(component instanceof NumericValue))
                    {
                        throw new InternalExpressionException("'" + p.id + "' requires 3 numerical values");
                    }
                }
                return value;
            }
            if (value instanceof final EntityValue ev)
            {
                if (options.containsKey("follow"))
                {
                    throw new InternalExpressionException(p.id + " parameter cannot use entity as positions for relative positioning due to 'follow' attribute being present");
                }
                class_1297 e = ev.getEntity();
                return ListValue.of(
                        new NumericValue(e.method_23317()),
                        new NumericValue(e.method_23318()),
                        new NumericValue(e.method_23321())
                );
            }
            CarpetScriptServer.LOG.error("Value: " + value.getString());
            throw new InternalExpressionException("'" + p.id + "' requires a triple, block or entity to indicate position");
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            class_2499 ctag = (class_2499) tag;
            return ListValue.of(
                    new NumericValue(ctag.method_10611(0).orElseThrow()),
                    new NumericValue(ctag.method_10611(1).orElseThrow()),
                    new NumericValue(ctag.method_10611(2).orElseThrow())
            );
        }

        @Override
        public class_2520 toTag(Value value, final class_5455 regs)
        {
            List<Value> lv = ((ListValue) value).getItems();
            class_2499 tag = new class_2499();
            tag.add(class_2489.method_23241(NumericValue.asNumber(lv.get(0), "x").getDouble()));
            tag.add(class_2489.method_23241(NumericValue.asNumber(lv.get(1), "y").getDouble()));
            tag.add(class_2489.method_23241(NumericValue.asNumber(lv.get(2), "z").getDouble()));
            return tag;
        }
    }

    public static class PointsParam extends Param
    {
        public PointsParam(String id)
        {
            super(id);
        }

        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            if (!(value instanceof final ListValue list))
            {
                throw new InternalExpressionException(id + " parameter should be a list");
            }
            List<Value> points = new ArrayList<>();
            for (Value point : list.getItems())
            {
                points.add(Vec3Param.validate(this, options, point, false));
            }
            return ListValue.wrap(points);
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            class_2499 ltag = (class_2499) tag;
            List<Value> points = new ArrayList<>();
            for (int i = 0, ll = ltag.size(); i < ll; i++)
            {
                class_2499 ptag = ltag.method_10603(i).orElseThrow();
                points.add(ListValue.of(
                        new NumericValue(ptag.method_10611(0).orElseThrow()),
                        new NumericValue(ptag.method_10611(1).orElseThrow()),
                        new NumericValue(ptag.method_10611(2).orElseThrow())
                ));
            }
            return ListValue.wrap(points);
        }

        @Override
        public class_2520 toTag(Value pointsValue, final class_5455 regs)
        {
            List<Value> lv = ((ListValue) pointsValue).getItems();
            class_2499 ltag = new class_2499();
            for (Value value : lv)
            {
                List<Value> coords = ((ListValue) value).getItems();
                class_2499 tag = new class_2499();
                tag.add(class_2489.method_23241(NumericValue.asNumber(coords.get(0), "x").getDouble()));
                tag.add(class_2489.method_23241(NumericValue.asNumber(coords.get(1), "y").getDouble()));
                tag.add(class_2489.method_23241(NumericValue.asNumber(coords.get(2), "z").getDouble()));
                ltag.add(tag);
            }
            return ltag;
        }
    }


    public static class ColorParam extends NumericParam
    {
        protected ColorParam(String id)
        {
            super(id);
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            return new NumericValue(((class_2497) tag).method_10701());
        }

        @Override
        public class_2520 toTag(Value value, final class_5455 regs)
        {
            return class_2497.method_23247(NumericValue.asNumber(value, id).getInt());
        }
    }

    public static class EntityParam extends Param
    {

        protected EntityParam(String id)
        {
            super(id);
        }

        @Override
        public class_2520 toTag(Value value, final class_5455 regs)
        {
            return class_2497.method_23247(NumericValue.asNumber(value, id).getInt());
        }

        @Override
        public Value validate(Map<String, Value> options, MinecraftServer server, Value value)
        {
            if (value instanceof final EntityValue ev)
            {
                return new NumericValue(ev.getEntity().method_5628());
            }
            class_3222 player = EntityValue.getPlayerByValue(server, value);
            if (player == null)
            {
                throw new InternalExpressionException(id + " parameter needs to represent an entity or player");
            }
            return new NumericValue(player.method_5628());
        }

        @Override
        public Value decode(class_2520 tag, class_1937 level)
        {
            return new NumericValue(((class_2497) tag).method_10701());
        }
    }

    private static boolean isStraight(class_243 from, class_243 to, double density)
    {
        if ((from.field_1352 == to.field_1352 && from.field_1351 == to.field_1351) || (from.field_1352 == to.field_1352 && from.field_1350 == to.field_1350) || (from.field_1351 == to.field_1351 && from.field_1350 == to.field_1350))
        {
            return from.method_1022(to) / density > 20;
        }
        return false;
    }

    private static int drawOptimizedParticleLine(List<class_3222> playerList, class_2394 particle, class_243 from, class_243 to, double density)
    {
        double distance = from.method_1022(to);
        int particles = (int) (distance / density);
        class_243 towards = to.method_1020(from);
        int parts = 0;
        for (class_3222 player : playerList)
        {
            class_3218 world = player.method_51469();
            world.method_14166(player, particle, true, true,
                    (towards.field_1352) / 2 + from.field_1352, (towards.field_1351) / 2 + from.field_1351, (towards.field_1350) / 2 + from.field_1350, particles / 3,
                    towards.field_1352 / 6, towards.field_1351 / 6, towards.field_1350 / 6, 0.0);
            world.method_14166(player, particle, true, true,
                    from.field_1352, from.field_1351, from.field_1350, 1, 0.0, 0.0, 0.0, 0.0);
            world.method_14166(player, particle, true, true,
                    to.field_1352, to.field_1351, to.field_1350, 1, 0.0, 0.0, 0.0, 0.0);
            parts += particles / 3 + 2;
        }
        int divider = 6;
        while (particles / divider > 1)
        {
            int center = (divider * 2) / 3;
            int dev = 2 * divider;
            for (class_3222 player : playerList)
            {
                class_3218 world = player.method_51469();
                world.method_14166(player, particle, true, true,
                        (towards.field_1352) / center + from.field_1352, (towards.field_1351) / center + from.field_1351, (towards.field_1350) / center + from.field_1350, particles / divider,
                        towards.field_1352 / dev, towards.field_1351 / dev, towards.field_1350 / dev, 0.0);
                world.method_14166(player, particle, true, true,
                        (towards.field_1352) * (1.0 - 1.0 / center) + from.field_1352, (towards.field_1351) * (1.0 - 1.0 / center) + from.field_1351, (towards.field_1350) * (1.0 - 1.0 / center) + from.field_1350, particles / divider,
                        towards.field_1352 / dev, towards.field_1351 / dev, towards.field_1350 / dev, 0.0);
            }
            parts += 2 * particles / divider;
            divider = 2 * divider;
        }
        return parts;
    }

    public static int drawParticleLine(List<class_3222> players, class_2394 particle, class_243 from, class_243 to, double density)
    {
        double distance = from.method_1025(to);
        if (distance == 0)
        {
            return 0;
        }
        int pcount = 0;
        if (distance < 100)
        {
            class_5819 rand = players.get(0).method_51469().field_9229;
            int particles = (int) (distance / density) + 1;
            class_243 towards = to.method_1020(from);
            for (int i = 0; i < particles; i++)
            {
                class_243 at = from.method_1019(towards.method_1021(rand.method_43058()));
                for (class_3222 player : players)
                {
                    player.method_51469().method_14166(player, particle, true, true,
                            at.field_1352, at.field_1351, at.field_1350, 1,
                            0.0, 0.0, 0.0, 0.0);
                    pcount++;
                }
            }
            return pcount;
        }

        if (isStraight(from, to, density))
        {
            return drawOptimizedParticleLine(players, particle, from, to, density);
        }
        class_243 incvec = to.method_1020(from).method_1021(2 * density / Math.sqrt(distance));

        for (class_243 delta = new class_243(0.0, 0.0, 0.0);
             delta.method_1027() < distance;
             delta = delta.method_1019(incvec.method_1021(Sys.randomizer.nextFloat())))
        {
            for (class_3222 player : players)
            {
                player.method_51469().method_14166(player, particle, true, true,
                        delta.field_1352 + from.field_1352, delta.field_1351 + from.field_1351, delta.field_1350 + from.field_1350, 1,
                        0.0, 0.0, 0.0, 0.0);
                pcount++;
            }
        }
        return pcount;
    }
}
