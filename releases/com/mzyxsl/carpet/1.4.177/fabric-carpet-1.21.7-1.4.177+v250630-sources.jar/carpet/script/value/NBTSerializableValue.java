package carpet.script.value;

import carpet.script.CarpetContext;
import carpet.script.exception.InternalExpressionException;
import carpet.script.exception.ThrowStatement;
import carpet.script.exception.Throwables;
import carpet.script.external.Vanilla;
import carpet.script.utils.EquipmentInventory;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.Nullable;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1301;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2203;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2290;
import net.minecraft.class_2291;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2483;
import net.minecraft.class_2487;
import net.minecraft.class_2491;
import net.minecraft.class_2497;
import net.minecraft.class_2499;
import net.minecraft.class_2503;
import net.minecraft.class_2509;
import net.minecraft.class_2514;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2522;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3954;
import net.minecraft.class_5455;
import net.minecraft.class_6067;

public class NBTSerializableValue extends Value implements ContainerValueInterface
{
    private String nbtString = null;
    private class_2520 nbtTag = null;
    private Supplier<class_2520> nbtSupplier = null;
    private boolean owned = false;
    private static class_2522<class_2520> tagParser = class_2522.method_68662(class_2509.field_11560);

    private NBTSerializableValue()
    {
    }

    public NBTSerializableValue(String nbtString)
    {
        nbtSupplier = () ->
        {
            try
            {
                return tagParser.method_67319( new StringReader(nbtString));
            }
            catch (CommandSyntaxException e)
            {
                throw new InternalExpressionException("Incorrect NBT data: " + nbtString);
            }
        };
        owned = true;
    }

    public NBTSerializableValue(class_2520 tag)
    {
        nbtTag = tag;
        owned = true;
    }

    public static Value of(class_2520 tag)
    {
        if (tag == null)
        {
            return Value.NULL;
        }
        return new NBTSerializableValue(tag);
    }

    public NBTSerializableValue(Supplier<class_2520> tagSupplier)
    {
        nbtSupplier = tagSupplier;
    }

    public static Value fromStack(class_1799 stack, class_5455 regs)
    {
        NBTSerializableValue value = new NBTSerializableValue();
        value.nbtSupplier = () -> class_1799.field_24671.encodeStart(regs.method_57093(class_2509.field_11560), stack).getOrThrow(s -> new InternalExpressionException("Failed to parse item stack data: " + s));
        return value;
    }

    public static Value nameFromRegistryId(@Nullable class_2960 id)
    {
        return StringValue.of(nameFromResource(id));
    }

    @Nullable
    public static String nameFromResource(@Nullable class_2960 id)
    {
        return id == null ? null : id.method_12836().equals("minecraft") ? id.method_12832() : id.toString();
    }

    @Nullable
    public static NBTSerializableValue parseString(String nbtString)
    {
        try
        {
            class_2520 tag = tagParser.method_67319(new StringReader(nbtString));
            NBTSerializableValue value = new NBTSerializableValue(tag);
            value.nbtString = null;
            return value;
        }
        catch (CommandSyntaxException e)
        {
            return null;
        }
    }

    public static NBTSerializableValue parseStringOrFail(String nbtString)
    {
        NBTSerializableValue result = parseString(nbtString);
        if (result == null)
        {
            throw new InternalExpressionException("Incorrect NBT tag: " + nbtString);
        }
        return result;
    }


    @Override
    public Value clone()
    {
        // sets only nbttag, even if emtpy;
        NBTSerializableValue copy = new NBTSerializableValue(nbtTag);
        copy.nbtSupplier = this.nbtSupplier;
        copy.nbtString = this.nbtString;
        copy.owned = this.owned;
        return copy;
    }

    @Override
    public Value deepcopy()
    {
        NBTSerializableValue copy = (NBTSerializableValue) clone();
        copy.owned = false;
        ensureOwnership();
        return copy;
    }

    @Override
    public Value fromConstant()
    {
        return deepcopy();
    }

    // stolen from HopperBlockEntity, adjusted for threaded operation
    public static class_1263 getInventoryAt(class_3218 world, class_2338 blockPos)
    {
        class_1263 inventory = null;
        class_2680 blockState = world.method_8320(blockPos);
        class_2248 block = blockState.method_26204();
        if (block instanceof final class_3954 containerHolder)
        {
            inventory = containerHolder.method_17680(blockState, world, blockPos);
        }
        else if (blockState.method_31709())
        {
            class_2586 blockEntity = BlockValue.getBlockEntity(world, blockPos);
            if (blockEntity instanceof final class_1263 inventoryHolder)
            {
                inventory = inventoryHolder;
                if (inventory instanceof class_2595 && block instanceof final class_2281 chestBlock)
                {
                    inventory = class_2281.method_17458(chestBlock, blockState, world, blockPos, true);
                }
            }
        }

        if (inventory == null)
        {
            List<class_1297> list = world.method_8333(
                    (class_1297) null, //TODO check this matches the correct method
                    new class_238(
                            blockPos.method_10263() - 0.5D, blockPos.method_10264() - 0.5D, blockPos.method_10260() - 0.5D,
                            blockPos.method_10263() + 0.5D, blockPos.method_10264() + 0.5D, blockPos.method_10260() + 0.5D),
                    class_1301.field_6152
            );
            if (!list.isEmpty())
            {
                inventory = (class_1263) list.get(world.field_9229.method_43048(list.size()));
            }
        }

        return inventory;
    }

    public static InventoryLocator locateInventory(CarpetContext c, List<Value> params, int offset)
    {
        try
        {
            Value v1 = params.get(offset);
            if (v1.isNull())
            {
                offset++;
                v1 = params.get(offset);
            }
            else if (v1 instanceof StringValue)
            {
                String strVal = v1.getString().toLowerCase(Locale.ROOT);
                if (strVal.equals("enderchest"))
                {
                    Value v2 = params.get(1 + offset);
                    class_3222 player = EntityValue.getPlayerByValue(c.server(), v2);
                    if (player == null)
                    {
                        throw new InternalExpressionException("enderchest inventory requires player argument");
                    }
                    return new InventoryLocator(player, player.method_24515(), player.method_7274(), offset + 2, true);
                }
                if (strVal.equals("equipment"))
                {
                    Value v2 = params.get(1 + offset);
                    if (!(v2 instanceof final EntityValue ev))
                    {
                        throw new InternalExpressionException("Equipment inventory requires a living entity argument");
                    }
                    class_1297 e = ev.getEntity();
                    if (!(e instanceof final class_1309 le))
                    {
                        throw new InternalExpressionException("Equipment inventory requires a living entity argument");
                    }
                    return new InventoryLocator(e, e.method_24515(), new EquipmentInventory(le), offset + 2);
                }
                boolean isEnder = strVal.startsWith("enderchest_");
                if (isEnder)
                {
                    strVal = strVal.substring(11); // len("enderchest_")
                }
                class_3222 player = c.server().method_3760().method_14566(strVal);
                if (player == null)
                {
                    throw new InternalExpressionException("String description of an inventory should either denote a player or player's enderchest");
                }
                return new InventoryLocator(
                        player,
                        player.method_24515(),
                        isEnder ? player.method_7274() : player.method_31548(),
                        offset + 1,
                        isEnder
                );
            }
            if (v1 instanceof final EntityValue ev)
            {
                class_1263 inv = null;
                class_1297 e = ev.getEntity();
                if (e instanceof final class_1657 pe)
                {
                    inv = pe.method_31548();
                }
                else if (e instanceof final class_1263 container)
                {
                    inv = container;
                }
                else if (e instanceof final class_6067 io)
                {
                    inv = io.method_35199();
                }
                else if (e instanceof final class_1496 ibi)
                {
                    inv = Vanilla.AbstractHorse_getInventory(ibi); // horse only
                }
                else if (e instanceof final class_1309 le)
                {
                    return new InventoryLocator(e, e.method_24515(), new EquipmentInventory(le), offset + 1);
                }
                return inv == null ? null : new InventoryLocator(e, e.method_24515(), inv, offset + 1);

            }
            if (v1 instanceof final BlockValue bv)
            {
                class_2338 pos = bv.getPos();
                if (pos == null)
                {
                    throw new InternalExpressionException("Block to access inventory needs to be positioned in the world");
                }
                class_1263 inv = getInventoryAt(c.level(), pos);
                return inv == null ? null : new InventoryLocator(pos, pos, inv, offset + 1);
            }
            if (v1 instanceof final ListValue lv)
            {
                List<Value> args = lv.getItems();
                class_2338 pos = class_2338.method_49637(
                        NumericValue.asNumber(args.get(0)).getDouble(),
                        NumericValue.asNumber(args.get(1)).getDouble(),
                        NumericValue.asNumber(args.get(2)).getDouble());
                class_1263 inv = getInventoryAt(c.level(), pos);
                return inv == null ? null : new InventoryLocator(pos, pos, inv, offset + 1);
            }
            if (v1 instanceof final ScreenValue screenValue)
            {
                return !screenValue.isOpen() ? null : new InventoryLocator(screenValue.getPlayer(), screenValue.getPlayer().method_24515(), screenValue.getInventory(), offset + 1);
            }
            class_2338 pos = class_2338.method_49637(
                    NumericValue.asNumber(v1).getDouble(),
                    NumericValue.asNumber(params.get(1 + offset)).getDouble(),
                    NumericValue.asNumber(params.get(2 + offset)).getDouble());
            class_1263 inv = getInventoryAt(c.level(), pos);
            return inv == null ? null : new InventoryLocator(pos, pos, inv, offset + 3);
        }
        catch (IndexOutOfBoundsException e)
        {
            throw new InternalExpressionException("Inventory should be defined either by three coordinates, a block value, an entity, or a screen");
        }
    }

    private static final Map<String, class_2290> itemCache = new HashMap<>();

    public static class_1799 parseItem(String itemString, class_5455 regs)
    {
        return parseItem(itemString, null, regs);
    }

    public static class_1799 parseItem(String itemString, @Nullable class_2487 customTag, class_5455 regs)
    {
        if (customTag != null) {
            return class_1799.field_24671.parse(regs.method_57093(class_2509.field_11560), customTag).getOrThrow(s -> new InternalExpressionException("Failed to parse item stack data: " + s));
        }
        try
        {
            class_2290 res = itemCache.get(itemString);  // [SCARY SHIT] persistent caches over server reloads
            if (res != null)
            {
                return res.method_9781(1, false);
            }
            class_2291.class_7215 parser = (new class_2291(regs)).method_9789(new StringReader(itemString));
            res = new class_2290(parser.comp_628(), parser.comp_2439());

            itemCache.put(itemString, res);
            if (itemCache.size() > 64000)
            {
                itemCache.clear();
            }
            return res.method_9781(1, false);
        }
        catch (CommandSyntaxException e)
        {
            throw new ThrowStatement(itemString, Throwables.UNKNOWN_ITEM);
        }
    }

    public static int validateSlot(int slot, class_1263 inv)
    {
        int invSize = inv.method_5439();
        if (slot < 0)
        {
            slot = invSize + slot;
        }
        return slot < 0 || slot >= invSize ? inv.method_5439() : slot; // outside of inventory
    }

    private static Value decodeSimpleTag(class_2520 t)
    {
        if (t instanceof final class_2514 number)
        {
            // short and byte will never exceed float's precision, even int won't
            return t instanceof class_2503 || t instanceof class_2497 ? NumericValue.of(number.method_10699()) : NumericValue.of(number.method_68599().orElseThrow());
        }
        if (t instanceof class_2519 stringTag)
        {
            return StringValue.of(stringTag.comp_3831());
        }
        if (t instanceof class_2491)
        {
            return Value.NULL;
        }
        throw new InternalExpressionException("How did we get here: Unknown nbt element class: " + t.method_23258().method_23259());
    }

    private static Value decodeTag(class_2520 t)
    {
        return t instanceof class_2487 || t instanceof class_2483 ? new NBTSerializableValue(() -> t) : decodeSimpleTag(t);
    }

    private static Value decodeTagDeep(class_2520 t)
    {
        if (t instanceof final class_2487 ctag)
        {
            Map<Value, Value> pairs = new HashMap<>();
            for (String key : ctag.method_10541())
            {
                pairs.put(new StringValue(key), decodeTagDeep(ctag.method_10580(key)));
            }
            return MapValue.wrap(pairs);
        }
        if (t instanceof final class_2483 ltag)
        {
            List<Value> elems = new ArrayList<>();
            for (class_2520 elem : ltag)
            {
                elems.add(decodeTagDeep(elem));
            }
            return ListValue.wrap(elems);
        }
        return decodeSimpleTag(t);
    }

    public Value toValue()
    {
        return decodeTagDeep(this.getTag());
    }

    public static Value fromValue(Value v)
    {
        if (v instanceof NBTSerializableValue)
        {
            return v;
        }
        if (v.isNull())
        {
            return Value.NULL;
        }
        return NBTSerializableValue.parseStringOrFail(v.getString());
    }

    public class_2520 getTag()
    {
        if (nbtTag == null)
        {
            nbtTag = nbtSupplier.get();
        }
        return nbtTag;
    }

    @Override
    public boolean equals(Object o)
    {
        return o instanceof final NBTSerializableValue nbtsv ? getTag().equals(nbtsv.getTag()) : super.equals(o);
    }

    @Override
    public String getString()
    {
        if (nbtString == null)
        {
            nbtString = getTag().toString();
        }
        return nbtString;
    }

    @Override
    public boolean getBoolean()
    {
        class_2520 tag = getTag();
        if (tag instanceof final class_2487 ctag)
        {
            return !(ctag).method_33133();
        }
        if (tag instanceof final class_2483 ltag)
        {
            return !(ltag).isEmpty();
        }
        if (tag instanceof final class_2514 number)
        {
            return number.method_10697() != 0.0;
        }
        if (tag instanceof class_2519 st)
        {
            return !st.comp_3831().isEmpty();
        }
        return true;
    }

    public class_2487 getCompoundTag()
    {
        try
        {
            ensureOwnership();
            return (class_2487) getTag();
        }
        catch (ClassCastException e)
        {
            throw new InternalExpressionException(getString() + " is not a valid compound tag");
        }
    }

    @Override
    public boolean put(Value where, Value value)
    {
        return put(where, value, new StringValue("replace"));
    }

    @Override
    public boolean put(Value where, Value value, Value conditions)
    {
        /// WIP
        ensureOwnership();
        class_2203.class_2209 path = cachePath(where.getString());
        class_2520 tagToInsert = value instanceof final NBTSerializableValue nbtsv
                ? nbtsv.getTag()
                : new NBTSerializableValue(value.getString()).getTag();
        boolean modifiedTag;
        if (conditions instanceof final NumericValue number)
        {
            modifiedTag = modifyInsert((int) number.getLong(), path, tagToInsert);
        }
        else
        {
            String ops = conditions.getString();
            if (ops.equalsIgnoreCase("merge"))
            {
                modifiedTag = modifyMerge(path, tagToInsert);
            }
            else if (ops.equalsIgnoreCase("replace"))
            {
                modifiedTag = modifyReplace(path, tagToInsert);
            }
            else
            {
                return false;
            }
        }
        if (modifiedTag)
        {
            dirty();
        }
        return modifiedTag;
    }


    private boolean modifyInsert(int index, class_2203.class_2209 nbtPath, class_2520 newElement)
    {
        return modifyInsert(index, nbtPath, newElement, this.getTag());
    }

    private boolean modifyInsert(int index, class_2203.class_2209 nbtPath, class_2520 newElement, class_2520 currentTag)
    {
        Collection<class_2520> targets;
        try
        {
            targets = nbtPath.method_9367(currentTag, class_2499::new);
        }
        catch (CommandSyntaxException e)
        {
            return false;
        }

        boolean modified = false;
        for (class_2520 target : targets)
        {
            if (!(target instanceof final class_2483 targetList))
            {
                continue;
            }
            try
            {
                if (!targetList.method_10533(index < 0 ? targetList.size() + index + 1 : index, newElement.method_10707()))
                {
                    return false;
                }
                modified = true;
            }
            catch (IndexOutOfBoundsException ignored)
            {
            }
        }
        return modified;
    }


    private boolean modifyMerge(class_2203.class_2209 nbtPath, class_2520 replacement) //nbtPathArgumentType$NbtPath_1, list_1)
    {
        if (!(replacement instanceof final class_2487 replacementCompound))
        {
            return false;
        }
        class_2520 ownTag = getTag();
        try
        {
            for (class_2520 target : nbtPath.method_9367(ownTag, class_2487::new))
            {
                if (!(target instanceof final class_2487 targetCompound))
                {
                    continue;
                }
                targetCompound.method_10543(replacementCompound);
            }
        }
        catch (CommandSyntaxException ignored)
        {
            return false;
        }
        return true;
    }

    private boolean modifyReplace(class_2203.class_2209 nbtPath, class_2520 replacement) //nbtPathArgumentType$NbtPath_1, list_1)
    {
        class_2520 tag = getTag();
        String pathText = nbtPath.toString();
        if (pathText.endsWith("]")) // workaround for array replacement or item in the array replacement
        {
            if (nbtPath.method_9372(tag) == 0)
            {
                return false;
            }
            Pattern pattern = Pattern.compile("\\[[^\\[]*]$");
            Matcher matcher = pattern.matcher(pathText);
            if (!matcher.find()) // malformed path
            {
                return false;
            }
            String arrAccess = matcher.group();
            int pos;
            if (arrAccess.length() == 2) // we just removed entire array
            {
                pos = 0;
            }
            else
            {
                try
                {
                    pos = Integer.parseInt(arrAccess.substring(1, arrAccess.length() - 1));
                }
                catch (NumberFormatException e)
                {
                    return false;
                }
            }
            class_2203.class_2209 newPath = cachePath(pathText.substring(0, pathText.length() - arrAccess.length()));
            return modifyInsert(pos, newPath, replacement, tag);
        }
        try
        {
            nbtPath.method_35722(tag, replacement);
        }
        catch (CommandSyntaxException e)
        {
            return false;
        }
        return true;
    }

    @Override
    public Value get(Value value)
    {
        String valString = value.getString();
        class_2203.class_2209 path = cachePath(valString);
        try
        {
            List<class_2520> tags = path.method_9366(getTag());
            if (tags.isEmpty())
            {
                return Value.NULL;
            }
            if (tags.size() == 1 && !valString.endsWith("[]"))
            {
                return NBTSerializableValue.decodeTag(tags.get(0));
            }
            return ListValue.wrap(tags.stream().map(NBTSerializableValue::decodeTag));
        }
        catch (CommandSyntaxException ignored)
        {
        }
        return Value.NULL;
    }

    @Override
    public boolean has(Value where)
    {
        return cachePath(where.getString()).method_9374(getTag()) > 0;
    }

    private void ensureOwnership()
    {
        if (!owned)
        {
            nbtTag = getTag().method_10707();
            nbtString = null;
            nbtSupplier = null;  // just to be sure
            owned = true;
        }
    }

    private void dirty()
    {
        nbtString = null;
    }

    @Override
    public boolean delete(Value where)
    {
        class_2203.class_2209 path = cachePath(where.getString());
        ensureOwnership();
        int removed = path.method_9372(getTag());
        if (removed > 0)
        {
            dirty();
            return true;
        }
        return false;
    }

    public record InventoryLocator(Object owner, class_2338 position, class_1263 inventory, int offset,
                                   boolean isEnder)
    {
        InventoryLocator(Object owner, class_2338 pos, class_1263 i, int o)
        {
            this(owner, pos, i, o, false);
        }
    }

    private static final Map<String, class_2203.class_2209> pathCache = new HashMap<>();

    private static class_2203.class_2209 cachePath(String arg)
    {
        class_2203.class_2209 res = pathCache.get(arg);
        if (res != null)
        {
            return res;
        }
        try
        {
            res = class_2203.method_9360().method_9362(new StringReader(arg));
        }
        catch (CommandSyntaxException exc)
        {
            throw new InternalExpressionException("Incorrect nbt path: " + arg);
        }
        if (pathCache.size() > 1024)
        {
            pathCache.clear();
        }
        pathCache.put(arg, res);
        return res;
    }

    @Override
    public String getTypeString()
    {
        return "nbt";
    }


    @Override
    public class_2520 toTag(boolean force, class_5455 regs)
    {
        if (!force)
        {
            throw new NBTSerializableValue.IncompatibleTypeException(this);
        }
        ensureOwnership();
        return getTag();
    }

    public static class IncompatibleTypeException extends RuntimeException
    {
        public final Value val;

        public IncompatibleTypeException(Value val)
        {
            this.val = val;
        }
    }

}
