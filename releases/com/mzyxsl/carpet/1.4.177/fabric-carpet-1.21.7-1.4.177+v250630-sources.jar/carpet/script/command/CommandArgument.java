package carpet.script.command;

import carpet.script.CarpetScriptHost;
import carpet.script.CarpetScriptServer;
import carpet.script.argument.FunctionArgument;
import carpet.script.external.Carpet;
import carpet.script.external.Vanilla;
import carpet.script.value.BlockValue;
import carpet.script.value.BooleanValue;
import carpet.script.value.EntityValue;
import carpet.script.value.FormattedTextValue;
import carpet.script.value.ListValue;
import carpet.script.value.MapValue;
import carpet.script.value.NBTSerializableValue;
import carpet.script.value.NumericValue;
import carpet.script.value.StringValue;
import carpet.script.value.Value;
import carpet.script.value.ValueConversions;
import com.mojang.datafixers.util.Either;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.ints.IntSet;

import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.context.ParsedCommandNode;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import com.mojang.brigadier.tree.ArgumentCommandNode;
import com.mojang.brigadier.tree.CommandNode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1959;
import net.minecraft.class_2096;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2177;
import net.minecraft.class_2179;
import net.minecraft.class_2181;
import net.minecraft.class_2183;
import net.minecraft.class_2191;
import net.minecraft.class_2196;
import net.minecraft.class_2203;
import net.minecraft.class_2212;
import net.minecraft.class_2214;
import net.minecraft.class_2216;
import net.minecraft.class_2223;
import net.minecraft.class_2224;
import net.minecraft.class_2232;
import net.minecraft.class_2233;
import net.minecraft.class_2239;
import net.minecraft.class_2243;
import net.minecraft.class_2245;
import net.minecraft.class_2247;
import net.minecraft.class_2252;
import net.minecraft.class_2257;
import net.minecraft.class_2264;
import net.minecraft.class_2270;
import net.minecraft.class_2273;
import net.minecraft.class_2274;
import net.minecraft.class_2277;
import net.minecraft.class_2287;
import net.minecraft.class_2321;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_241;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3019;
import net.minecraft.class_5242;
import net.minecraft.class_5321;
import net.minecraft.class_5473;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7157;
import net.minecraft.class_7733;
import net.minecraft.class_7737;
import net.minecraft.class_7924;
import net.minecraft.class_9015;
import net.minecraft.server.MinecraftServer;
import javax.annotation.Nullable;

import static net.minecraft.class_2170.method_9244;

public abstract class CommandArgument
{
    public static CommandSyntaxException error(String text)
    {
        return new SimpleCommandExceptionType(class_2561.method_43470(text)).create();
    }

    private static final List<? extends CommandArgument> baseTypes = Lists.newArrayList(
            // default
            new StringArgument(),
            // vanilla arguments as per https://minecraft.wiki/w/Argument_types
            new VanillaUnconfigurableArgument("bool", BoolArgumentType::bool,
                    (c, p) -> BooleanValue.of(BoolArgumentType.getBool(c, p)), false
            ),
            new FloatArgument(),
            new IntArgument(),
            new WordArgument(), new GreedyStringArgument(),
            new VanillaUnconfigurableArgument("yaw", class_5473::method_30658,  // angle
                    (c, p) -> new NumericValue(class_5473.method_30660(c, p)), true
            ),
            new BlockPosArgument(),
            new VanillaUnconfigurableArgument("block", class_2257::method_9653,
                    (c, p) -> {
                        class_2247 result = class_2257.method_9655(c, p);
                        return new BlockValue(result.method_9494(), c.getSource().method_9225(), Vanilla.BlockInput_getTag(result));
                    },
                    param -> (ctx, builder) -> ctx.getArgument(param, class_2257.class).listSuggestions(ctx, builder)
            ),
            new VanillaUnconfigurableArgument("blockpredicate", class_2252::method_9645,
                    (c, p) -> ValueConversions.ofBlockPredicate(c.getSource().method_9211().method_30611(), class_2252.method_9644(c, p)),
                    param -> (ctx, builder) -> ctx.getArgument(param, class_2252.class).listSuggestions(ctx, builder)
            ),
            new VanillaUnconfigurableArgument("teamcolor", class_2177::method_9276,
                    (c, p) -> {
                        class_124 format = class_2177.method_9277(c, p);
                        return ListValue.of(StringValue.of(format.method_537()), ValueConversions.ofRGB(format.method_532()));
                    },
                    false
            ),
            new VanillaUnconfigurableArgument("columnpos", class_2264::method_9701,
                    (c, p) -> ValueConversions.of(class_2264.method_9702(c, p)), false
            ),
            // component  // raw json
            new VanillaUnconfigurableArgument("dimension", class_2181::method_9288,
                    (c, p) -> ValueConversions.of(class_2181.method_9289(c, p)), false
            ),
            new EntityArgument(),
            new VanillaUnconfigurableArgument("anchor", class_2183::method_9295,
                    (c, p) -> StringValue.of(class_2183.method_9294(c, p).name()), false
            ),
            new VanillaUnconfigurableArgument("entitytype", c -> class_7733.method_45603(c, class_7924.field_41266),
                    (c, p) -> ValueConversions.of(class_7733.method_45610(c, p).method_40237()), class_2321.method_71942(class_2321.field_10935)
            ),
            new VanillaUnconfigurableArgument("floatrange", class_2224::method_30918,
                    (c, p) -> ValueConversions.of(c.getArgument(p, class_2096.class_2099.class)), true
            ),
            // function??

            new PlayerProfileArgument(),
            new VanillaUnconfigurableArgument("intrange", class_2224::method_9422,
                    (c, p) -> ValueConversions.of(class_2224.class_2227.method_9425(c, p)), true
            ),
            new VanillaUnconfigurableArgument("enchantment", class_7924.field_41265),

            // item_predicate  ?? //same as item but accepts tags, not sure right now
            new SlotArgument(),
            new VanillaUnconfigurableArgument("item", class_2287::method_9776,
                    (c, p) -> ValueConversions.of(class_2287.method_9777(c, p).method_9781(1, false), c.getSource().method_30497()),
                    param -> (ctx, builder) -> ctx.getArgument(param, class_2287.class).listSuggestions(ctx, builder)
            ),
            new VanillaUnconfigurableArgument("message", class_2196::method_9340,
                    (c, p) -> new FormattedTextValue(class_2196.method_9339(c, p)), true
            ),
            new VanillaUnconfigurableArgument("effect", class_7924.field_41208),

            new TagArgument(), // for nbt_compound_tag and nbt_tag
            new VanillaUnconfigurableArgument("path", class_2203::method_9360,
                    (c, p) -> StringValue.of(class_2203.method_9358(c, p).toString()), true
            ),
            new VanillaUnconfigurableArgument("objective", class_2214::method_9391,
                    (c, p) -> ValueConversions.of(class_2214.method_9395(c, p)), false
            ),
            new VanillaUnconfigurableArgument("criterion", class_2216::method_9399,
                    (c, p) -> StringValue.of(class_2216.method_9402(c, p).method_1225()), false
            ),
            // operation // not sure if we need it, you have scarpet for that
            new VanillaUnconfigurableArgument("particle", class_2223::method_9417,
                    (c, p) -> ValueConversions.of(class_2223.method_9421(c, p), c.getSource().method_30497()), (c, b) -> class_2172.method_9270(c.getSource().method_9211().method_30611().method_30530(class_7924.field_41210).method_10235(), b)
            ),

            // resource / identifier section

            new VanillaUnconfigurableArgument("recipe", class_7924.field_52178),
            new VanillaUnconfigurableArgument("advancement", class_7924.field_52177),
            new VanillaUnconfigurableArgument("lootcondition", class_7924.field_41198),
            new VanillaUnconfigurableArgument("loottable", class_7924.field_50079),
            new VanillaUnconfigurableArgument("attribute", class_7924.field_41251),

            new VanillaUnconfigurableArgument("boss", class_2232::method_9441,
                    (c, p) -> ValueConversions.of(class_2232.method_9443(c, p)), class_3019.field_13482
            ),

            new VanillaUnconfigurableArgument("biome", c -> class_7737.method_45637(c, class_7924.field_41236),
                    (c, p) -> {
                        class_7737.class_7741<class_1959> result = class_7737.method_45636(c, "biome", class_7924.field_41236);
                        Either<class_6880.class_6883<class_1959>, class_6885.class_6888<class_1959>> res = result.method_45647();
                        if (res.left().isPresent())
                        {
                            return ValueConversions.of(res.left().get().method_40237());
                        }
                        if (res.right().isPresent())
                        {
                            return ValueConversions.of(res.right().get().method_40251());
                        }
                        return Value.NULL;
                    }, (ctx, builder) -> class_2172.method_9270(ctx.getSource().method_9211().method_30611().method_30530(class_7924.field_41236).method_10235(), builder)
            ),
            new VanillaUnconfigurableArgument("sound", class_2232::method_9441,
                    (c, p) -> ValueConversions.of(class_2232.method_9443(c, p)), class_2321.method_71942(class_2321.field_10934)
            ),
            new VanillaUnconfigurableArgument("storekey", class_2232::method_9441,
                    (c, p) -> ValueConversions.of(class_2232.method_9443(c, p)), (ctx, builder) -> class_2172.method_9257(ctx.getSource().method_9211().method_22827().method_22542(), builder)
            ),

            // default
            new CustomIdentifierArgument(),

            // end resource / identifier // I would be great if you guys have suggestions for that.

            new VanillaUnconfigurableArgument("rotation",
                    class_2270::method_9717,
                    (c, p) -> {
                        class_241 rot = class_2270.method_9716(c, p).method_9709(c.getSource());
                        return ListValue.of(new NumericValue(rot.field_1343), new NumericValue(rot.field_1342));
                    },
                    true
            ),
            new ScoreholderArgument(),
            new VanillaUnconfigurableArgument("scoreboardslot", class_2239::method_9468,
                    (c, p) -> StringValue.of(class_2239.method_9465(c, p).method_15434()), false
            ),
            new VanillaUnconfigurableArgument("swizzle", class_2273::method_9721,
                    (c, p) -> StringValue.of(class_2273.method_9720(c, p).stream().map(class_2350.class_2351::method_15434).collect(Collectors.joining())), true
            ),
            new VanillaUnconfigurableArgument("team", class_2243::method_9482,
                    (c, p) -> StringValue.of(class_2243.method_9480(c, p).method_1197()), false
            ),
            new VanillaUnconfigurableArgument("time", class_2245::method_9489,
                    (c, p) -> new NumericValue(IntegerArgumentType.getInteger(c, p)), false
            ),
            new VanillaUnconfigurableArgument("uuid", class_5242::method_27643,
                    (c, p) -> StringValue.of(class_5242.method_27645(c, p).toString()), false
            ),
            new VanillaUnconfigurableArgument("surfacelocation", class_2274::method_9723,
                    (c, p) -> {
                        class_241 res = class_2274.method_9724(c, p);
                        return ListValue.of(NumericValue.of(res.field_1343), NumericValue.of(res.field_1342));
                    },
                    false
            ),
            new LocationArgument()
    );

    public static final Map<String, CommandArgument> builtIns = baseTypes.stream().collect(Collectors.toMap(CommandArgument::getTypeSuffix, a -> a));

    public static final CommandArgument DEFAULT = baseTypes.get(0);

    public static CommandArgument getTypeForArgument(String argument, CarpetScriptHost host)
    {
        String[] components = argument.split("_");
        CommandArgument arg;
        for (int i = 0; i < components.length; i++)
        {
            String candidate = String.join("_", Arrays.asList(components).subList(i, components.length));
            arg = host.appArgTypes.get(candidate);
            if (arg != null)
            {
                return arg;
            }
            arg = builtIns.get(candidate);
            if (arg != null)
            {
                return arg;
            }
        }
        return DEFAULT;
    }

    public static RequiredArgumentBuilder<class_2168, ?> argumentNode(String param, CarpetScriptHost host) throws CommandSyntaxException
    {
        CommandArgument arg = getTypeForArgument(param, host);
        if (arg.suggestionProvider != null)
        {
            return method_9244(param, arg.getArgumentType(host)).suggests(arg.suggestionProvider.apply(param));
        }
        if (!arg.needsMatching)
        {
            return method_9244(param, arg.getArgumentType(host));
        }
        String hostName = host.getName();
        CarpetScriptServer scriptServer = host.scriptServer();
        return method_9244(param, arg.getArgumentType(host)).suggests((ctx, b) -> {
            CarpetScriptHost cHost = scriptServer.modules.get(hostName).retrieveOwnForExecution(ctx.getSource());
            return arg.suggest(ctx, b, cHost);
        });
    }

    protected String suffix;
    @Nullable
    protected Collection<String> examples;
    protected boolean needsMatching;
    protected boolean caseSensitive = true;
    protected Function<String, SuggestionProvider<class_2168>> suggestionProvider;
    protected FunctionArgument customSuggester;


    protected CommandArgument(
            String suffix,
            @Nullable Collection<String> examples,
            boolean suggestFromExamples)
    {
        this.suffix = suffix;
        this.examples = examples;
        this.needsMatching = suggestFromExamples;
    }

    protected abstract ArgumentType<?> getArgumentType(CarpetScriptHost host) throws CommandSyntaxException;


    public static Value getValue(CommandContext<class_2168> context, String param, CarpetScriptHost host) throws CommandSyntaxException
    {
        return getTypeForArgument(param, host).getValueFromContext(context, param);
    }

    protected abstract Value getValueFromContext(CommandContext<class_2168> context, String param) throws CommandSyntaxException;

    public String getTypeSuffix()
    {
        return suffix;
    }

    public static CommandArgument buildFromConfig(String suffix, Map<String, Value> config, CarpetScriptHost host) throws CommandSyntaxException
    {
        if (!config.containsKey("type"))
        {
            throw CommandArgument.error("Custom type " + suffix + " should at least specify the type");
        }
        String baseType = config.get("type").getString();
        if (!builtIns.containsKey(baseType))
        {
            throw CommandArgument.error("Unknown base type " + baseType + " for custom type " + suffix);
        }
        CommandArgument variant = builtIns.get(baseType).factory(host.scriptServer().server).get();
        variant.suffix = suffix;
        variant.configure(config, host);
        return variant;
    }

    protected void configure(Map<String, Value> config, CarpetScriptHost host) throws CommandSyntaxException
    {
        caseSensitive = config.getOrDefault("case_sensitive", Value.TRUE).getBoolean();
        if (config.containsKey("suggester"))
        {
            customSuggester = FunctionArgument.fromCommandSpec(host, config.get("suggester"));
        }
        if (config.containsKey("suggest"))
        {
            if (config.containsKey("suggester"))
            {
                throw error("Attempted to provide 'suggest' list while 'suggester' is present" + " for custom type " + suffix);
            }
            Value suggestionValue = config.get("suggest");
            if (!(suggestionValue instanceof ListValue))
            {
                throw error("Argument suggestions needs to be a list" + " for custom type " + suffix);
            }
            examples = ((ListValue) suggestionValue).getItems().stream()
                    .map(Value::getString)
                    .collect(Collectors.toSet());
            if (!examples.isEmpty())
            {
                needsMatching = true;
            }
        }
    }

    public CompletableFuture<Suggestions> suggest(
            CommandContext<class_2168> context,
            SuggestionsBuilder suggestionsBuilder,
            CarpetScriptHost host
    ) throws CommandSyntaxException
    {
        String prefix = suggestionsBuilder.getRemaining();
        if (!caseSensitive)
        {
            prefix = prefix.toLowerCase(Locale.ROOT);
        }
        suggestFor(context, prefix, host).forEach(suggestionsBuilder::suggest);
        return suggestionsBuilder.buildFuture();
    }

    protected List<String> suggestFor(CommandContext<class_2168> context, String prefix, CarpetScriptHost host) throws CommandSyntaxException
    {
        return getOptions(context, host).stream().filter(s -> optionMatchesPrefix(prefix, s)).collect(Collectors.toList());
    }

    protected Collection<String> getOptions(CommandContext<class_2168> context, CarpetScriptHost host) throws CommandSyntaxException
    {
        if (customSuggester != null)
        {
            Runnable currentSection = Carpet.startProfilerSection("Scarpet command");
            Map<Value, Value> params = new HashMap<>();
            for (ParsedCommandNode<class_2168> pnode : context.getNodes())
            {
                CommandNode<class_2168> node = pnode.getNode();
                if (node instanceof ArgumentCommandNode)
                {
                    params.put(StringValue.of(node.getName()), CommandArgument.getValue(context, node.getName(), host));
                }
            }
            List<Value> args = new ArrayList<>(customSuggester.args.size() + 1);
            args.add(MapValue.wrap(params));
            args.addAll(customSuggester.args);
            Value response = host.handleCommand(context.getSource(), customSuggester.function, args);
            if (!(response instanceof ListValue))
            {
                throw error("Custom suggester should return a list of options" + " for custom type " + suffix);
            }
            Collection<String> res = ((ListValue) response).getItems().stream().map(Value::getString).collect(Collectors.toList());
            currentSection.run();
            return res;
        }
        return needsMatching ? examples : Collections.singletonList("... " + getTypeSuffix());
    }

    protected boolean optionMatchesPrefix(String prefix, String option)
    {
        if (!caseSensitive)
        {
            option = option.toLowerCase(Locale.ROOT);
        }
        for (int i = 0; !option.startsWith(prefix, i); ++i)
        {
            i = option.indexOf('_', i);
            if (i < 0)
            {
                return false;
            }
        }
        return true;
    }

    protected abstract Supplier<CommandArgument> factory(MinecraftServer server);

    private static class StringArgument extends CommandArgument
    {
        Set<String> validOptions = Collections.emptySet();

        private StringArgument()
        {
            super("string", StringArgumentType.StringType.QUOTABLE_PHRASE.getExamples(), true);
        }

        @Override
        public ArgumentType<?> getArgumentType(CarpetScriptHost host)
        {
            return StringArgumentType.string();
        }

        @Override
        public Value getValueFromContext(CommandContext<class_2168> context, String param) throws CommandSyntaxException
        {
            String choseValue = StringArgumentType.getString(context, param);
            if (!caseSensitive)
            {
                choseValue = choseValue.toLowerCase(Locale.ROOT);
            }
            if (!validOptions.isEmpty() && !validOptions.contains(choseValue))
            {
                throw new SimpleCommandExceptionType(class_2561.method_43470("Incorrect value for " + param + ": " + choseValue + " for custom type " + suffix)).create();
            }
            return StringValue.of(choseValue);
        }

        @Override
        protected void configure(Map<String, Value> config, CarpetScriptHost host) throws CommandSyntaxException
        {
            super.configure(config, host);
            if (config.containsKey("options"))
            {
                Value optionsValue = config.get("options");
                if (!(optionsValue instanceof ListValue))
                {
                    throw error("Custom string type requires options passed as a list" + " for custom type " + suffix);
                }
                validOptions = ((ListValue) optionsValue).getItems().stream()
                        .map(v -> caseSensitive ? v.getString() : (v.getString().toLowerCase(Locale.ROOT)))
                        .collect(Collectors.toSet());
            }
        }

        @Override
        protected Collection<String> getOptions(CommandContext<class_2168> context, CarpetScriptHost host) throws CommandSyntaxException
        {
            return validOptions.isEmpty() ? super.getOptions(context, host) : validOptions;
        }

        @Override
        protected Supplier<CommandArgument> factory(MinecraftServer server)
        {
            return StringArgument::new;
        }
    }

    private static class WordArgument extends StringArgument
    {
        private WordArgument()
        {
            super();
            suffix = "term";
            examples = StringArgumentType.StringType.SINGLE_WORD.getExamples();
        }

        @Override
        public ArgumentType<?> getArgumentType(CarpetScriptHost host)
        {
            return StringArgumentType.word();
        }

        @Override
        protected Supplier<CommandArgument> factory(MinecraftServer server)
        {
            return WordArgument::new;
        }
    }

    private static class GreedyStringArgument extends StringArgument
    {
        private GreedyStringArgument()
        {
            super();
            suffix = "text";
            examples = StringArgumentType.StringType.GREEDY_PHRASE.getExamples();
        }

        @Override
        public ArgumentType<?> getArgumentType(CarpetScriptHost host)
        {
            return StringArgumentType.greedyString();
        }

        @Override
        protected Supplier<CommandArgument> factory(MinecraftServer server)
        {
            return GreedyStringArgument::new;
        }
    }

    private static class BlockPosArgument extends CommandArgument
    {
        private boolean mustBeLoaded = false;

        private BlockPosArgument()
        {
            super("pos", net.minecraft.class_2262.method_9698().getExamples(), false);
        }

        @Override
        public ArgumentType<?> getArgumentType(CarpetScriptHost host)
        {
            return net.minecraft.class_2262.method_9698();
        }

        @Override
        public Value getValueFromContext(CommandContext<class_2168> context, String param) throws CommandSyntaxException
        {
            class_2338 pos = mustBeLoaded
                    ? net.minecraft.class_2262.method_9696(context, param)
                    : net.minecraft.class_2262.method_9697(context, param);
            return ValueConversions.of(pos);
        }

        @Override
        protected void configure(Map<String, Value> config, CarpetScriptHost host) throws CommandSyntaxException
        {
            super.configure(config, host);
            mustBeLoaded = config.getOrDefault("loaded", Value.FALSE).getBoolean();
        }

        @Override
        protected Supplier<CommandArgument> factory(MinecraftServer server)
        {
            return BlockPosArgument::new;
        }
    }

    private static class LocationArgument extends CommandArgument
    {
        boolean blockCentered;

        private LocationArgument()
        {
            super("location", class_2277.method_9737().getExamples(), false);
            blockCentered = true;
        }

        @Override
        protected ArgumentType<?> getArgumentType(CarpetScriptHost host)
        {
            return class_2277.method_9735(blockCentered);
        }

        @Override
        protected Value getValueFromContext(CommandContext<class_2168> context, String param)
        {
            return ValueConversions.of(class_2277.method_9736(context, param));
        }

        @Override
        protected void configure(Map<String, Value> config, CarpetScriptHost host) throws CommandSyntaxException
        {
            super.configure(config, host);
            blockCentered = config.getOrDefault("block_centered", Value.TRUE).getBoolean();
        }

        @Override
        protected Supplier<CommandArgument> factory(MinecraftServer server)
        {
            return LocationArgument::new;
        }
    }

    private static class EntityArgument extends CommandArgument
    {
        boolean onlyFans;
        boolean single;

        private EntityArgument()
        {
            super("entities", net.minecraft.class_2186.method_9306().getExamples(), false);
            onlyFans = false;
            single = false;
        }

        @Override
        protected ArgumentType<?> getArgumentType(CarpetScriptHost host)
        {
            if (onlyFans)
            {
                return single ? net.minecraft.class_2186.method_9305() : net.minecraft.class_2186.method_9308();
            }
            return single ? net.minecraft.class_2186.method_9309() : net.minecraft.class_2186.method_9306();
        }

        @Override
        protected Value getValueFromContext(CommandContext<class_2168> context, String param) throws CommandSyntaxException
        {
            Collection<? extends class_1297> founds = net.minecraft.class_2186.method_9307(context, param);
            if (!single)
            {
                return ListValue.wrap(founds.stream().map(EntityValue::new));
            }
            if (founds.isEmpty())
            {
                return Value.NULL;
            }
            if (founds.size() == 1)
            {
                return new EntityValue(founds.iterator().next());
            }
            throw new SimpleCommandExceptionType(class_2561.method_43470("Multiple entities returned while only one was requested" + " for custom type " + suffix)).create();
        }

        @Override
        protected void configure(Map<String, Value> config, CarpetScriptHost host) throws CommandSyntaxException
        {
            super.configure(config, host);
            onlyFans = config.getOrDefault("players", Value.FALSE).getBoolean();
            single = config.getOrDefault("single", Value.FALSE).getBoolean();
        }

        @Override
        protected Supplier<CommandArgument> factory(MinecraftServer server)
        {
            return EntityArgument::new;
        }
    }

    private static class PlayerProfileArgument extends CommandArgument
    {
        boolean single;

        private PlayerProfileArgument()
        {
            super("players", class_2191.method_9329().getExamples(), false);
            single = false;
        }

        @Override
        protected ArgumentType<?> getArgumentType(CarpetScriptHost host)
        {
            return class_2191.method_9329();
        }

        @Override
        protected Value getValueFromContext(CommandContext<class_2168> context, String param) throws CommandSyntaxException
        {
            Collection<GameProfile> profiles = class_2191.method_9330(context, param);
            if (!single)
            {
                return ListValue.wrap(profiles.stream().map(p -> StringValue.of(p.getName())));
            }
            int size = profiles.size();
            if (size == 0)
            {
                return Value.NULL;
            }
            if (size == 1)
            {
                return StringValue.of(profiles.iterator().next().getName());
            }
            throw new SimpleCommandExceptionType(class_2561.method_43470("Multiple game profiles returned while only one was requested" + " for custom type " + suffix)).create();
        }

        @Override
        protected void configure(Map<String, Value> config, CarpetScriptHost host) throws CommandSyntaxException
        {
            super.configure(config, host);
            single = config.getOrDefault("single", Value.FALSE).getBoolean();
        }

        @Override
        protected Supplier<CommandArgument> factory(MinecraftServer server)
        {
            return PlayerProfileArgument::new;
        }
    }

    private static class ScoreholderArgument extends CommandArgument
    {
        boolean single;

        private ScoreholderArgument()
        {
            super("scoreholder", class_2233.method_9447().getExamples(), false);
            single = false;
            suggestionProvider = param -> class_2233.field_9951;
        }

        @Override
        protected ArgumentType<?> getArgumentType(CarpetScriptHost host)
        {
            return single ? class_2233.method_9447() : class_2233.method_9451();
        }

        @Override
        protected Value getValueFromContext(CommandContext<class_2168> context, String param) throws CommandSyntaxException
        {
            Collection<class_9015> holders = class_2233.method_9458(context, param);
            if (!single)
            {
                return ListValue.wrap(holders.stream().map(ValueConversions::of));
            }
            int size = holders.size();
            if (size == 0)
            {
                return Value.NULL;
            }
            if (size == 1)
            {
                return ValueConversions.of(holders.iterator().next());
            }
            throw new SimpleCommandExceptionType(class_2561.method_43470("Multiple score holders returned while only one was requested" + " for custom type " + suffix)).create();
        }

        @Override
        protected void configure(Map<String, Value> config, CarpetScriptHost host) throws CommandSyntaxException
        {
            super.configure(config, host);
            single = config.getOrDefault("single", Value.FALSE).getBoolean();
        }

        @Override
        protected Supplier<CommandArgument> factory(MinecraftServer server)
        {
            return PlayerProfileArgument::new;
        }
    }

    private static class TagArgument extends CommandArgument
    {
        boolean mapRequired;

        private TagArgument()
        {
            super("tag", class_2179.method_9284().getExamples(), false);
            mapRequired = true;
        }

        @Override
        protected ArgumentType<?> getArgumentType(CarpetScriptHost host)
        {
            return mapRequired ? class_2179.method_9284() : class_2212.method_9389();
        }

        @Override
        protected Value getValueFromContext(CommandContext<class_2168> context, String param)
        {
            return mapRequired
                    ? new NBTSerializableValue(class_2179.method_9285(context, param))
                    : new NBTSerializableValue(class_2212.method_9390(context, param));
        }

        @Override
        protected void configure(Map<String, Value> config, CarpetScriptHost host) throws CommandSyntaxException
        {
            super.configure(config, host);
            mapRequired = !config.getOrDefault("allow_element", Value.FALSE).getBoolean();
        }

        @Override
        protected Supplier<CommandArgument> factory(MinecraftServer server)
        {
            return TagArgument::new;
        }
    }

    private static class CustomIdentifierArgument extends CommandArgument
    {
        Set<class_2960> validOptions = Collections.emptySet();

        protected CustomIdentifierArgument()
        {
            super("identifier", Collections.emptyList(), true);
        }

        @Override
        protected ArgumentType<?> getArgumentType(CarpetScriptHost host)
        {
            return class_2232.method_9441();
        }

        @Override
        protected Value getValueFromContext(CommandContext<class_2168> context, String param) throws CommandSyntaxException
        {
            class_2960 choseValue = class_2232.method_9443(context, param);
            if (!validOptions.isEmpty() && !validOptions.contains(choseValue))
            {
                throw new SimpleCommandExceptionType(class_2561.method_43470("Incorrect value for " + param + ": " + choseValue + " for custom type " + suffix)).create();
            }
            return ValueConversions.of(choseValue);
        }

        @Override
        protected Supplier<CommandArgument> factory(MinecraftServer server)
        {
            return CustomIdentifierArgument::new;
        }

        @Override
        protected void configure(Map<String, Value> config, CarpetScriptHost host) throws CommandSyntaxException
        {
            super.configure(config, host);
            if (config.containsKey("options"))
            {
                Value optionsValue = config.get("options");
                if (!(optionsValue instanceof ListValue))
                {
                    throw error("Custom sting type requires options passed as a list" + " for custom type " + suffix);
                }
                validOptions = ((ListValue) optionsValue).getItems().stream().map(v -> class_2960.method_60654(v.getString())).collect(Collectors.toSet());
            }
        }
    }

    private static class FloatArgument extends CommandArgument
    {
        private Double min = null;
        private Double max = null;

        private FloatArgument()
        {
            super("float", DoubleArgumentType.doubleArg().getExamples(), true);
        }

        @Override
        public ArgumentType<?> getArgumentType(CarpetScriptHost host)
        {
            if (min != null)
            {
                if (max != null)
                {
                    return DoubleArgumentType.doubleArg(min, max);
                }
                return DoubleArgumentType.doubleArg(min);
            }
            return DoubleArgumentType.doubleArg();
        }

        @Override
        public Value getValueFromContext(CommandContext<class_2168> context, String param)
        {
            return new NumericValue(DoubleArgumentType.getDouble(context, param));
        }

        @Override
        protected void configure(Map<String, Value> config, CarpetScriptHost host) throws CommandSyntaxException
        {
            super.configure(config, host);
            if (config.containsKey("min"))
            {
                min = NumericValue.asNumber(config.get("min"), "min").getDouble();
            }
            if (config.containsKey("max"))
            {
                max = NumericValue.asNumber(config.get("max"), "max").getDouble();
            }
            if (max != null && min == null)
            {
                throw error("Double types cannot be only upper-bounded" + " for custom type " + suffix);
            }
        }

        @Override
        protected Supplier<CommandArgument> factory(MinecraftServer server)
        {
            return FloatArgument::new;
        }
    }

    private static class IntArgument extends CommandArgument
    {
        private Long min = null;
        private Long max = null;

        private IntArgument()
        {
            super("int", LongArgumentType.longArg().getExamples(), true);
        }

        @Override
        public ArgumentType<?> getArgumentType(CarpetScriptHost host)
        {
            if (min != null)
            {
                if (max != null)
                {
                    return LongArgumentType.longArg(min, max);
                }
                return LongArgumentType.longArg(min);
            }
            return LongArgumentType.longArg();
        }

        @Override
        public Value getValueFromContext(CommandContext<class_2168> context, String param)
        {
            return new NumericValue(LongArgumentType.getLong(context, param));
        }

        @Override
        protected void configure(Map<String, Value> config, CarpetScriptHost host) throws CommandSyntaxException
        {
            super.configure(config, host);
            if (config.containsKey("min"))
            {
                min = NumericValue.asNumber(config.get("min"), "min").getLong();
            }
            if (config.containsKey("max"))
            {
                max = NumericValue.asNumber(config.get("max"), "max").getLong();
            }
            if (max != null && min == null)
            {
                throw error("Double types cannot be only upper-bounded" + " for custom type " + suffix);
            }
        }

        @Override
        protected Supplier<CommandArgument> factory(MinecraftServer server)
        {
            return IntArgument::new;
        }
    }

    private static class SlotArgument extends CommandArgument
    {
        private record ContainerIds(IntSet numericalIds, Set<String> commandIds)
        {
        }

        private String restrict;
        private static final Map<String, ContainerIds> RESTRICTED_CONTAINERS = new HashMap<>()
        {{
            int i;
            for (String source : Arrays.asList("player", "enderchest", "equipment", "armor", "weapon", "container", "villager", "horse"))
            {
                put(source, new ContainerIds(new IntOpenHashSet(), new HashSet<>()));
            }
            for (i = 0; i < 41; i++)
            {
                get("player").numericalIds().add(i);
            }
            for (i = 0; i < 41; i++)
            {
                get("player").commandIds().add("container." + i);
            }
            for (i = 0; i < 9; i++)
            {
                get("player").commandIds().add("hotbar." + i);
            }
            for (i = 0; i < 27; i++)
            {
                get("player").commandIds().add("inventory." + i);
            }
            for (String place : Arrays.asList("weapon", "weapon.mainhand", "weapon.offhand"))
            {
                get("player").commandIds().add(place);
                get("equipment").commandIds().add(place);
                get("weapon").commandIds().add(place);
            }
            for (String place : Arrays.asList("armor.feet", "armor.legs", "armor.chest", "armor.head"))
            {
                get("player").commandIds().add(place);
                get("equipment").commandIds().add(place);
                get("armor").commandIds().add(place);
            }

            for (i = 0; i < 27; i++)
            {
                get("enderchest").numericalIds().add(200 + i);
            }
            for (i = 0; i < 27; i++)
            {
                get("enderchest").commandIds().add("enderchest." + i);
            }

            for (i = 0; i < 6; i++)
            {
                get("equipment").numericalIds().add(98 + i);
            }

            for (i = 0; i < 4; i++)
            {
                get("armor").numericalIds().add(100 + i);
            }

            for (i = 0; i < 2; i++)
            {
                get("weapon").numericalIds().add(98 + i);
            }

            for (i = 0; i < 54; i++)
            {
                get("container").numericalIds().add(i);
            }
            for (i = 0; i < 41; i++)
            {
                get("container").commandIds().add("container." + i);
            }

            for (i = 0; i < 8; i++)
            {
                get("villager").numericalIds().add(i);
            }
            for (i = 0; i < 8; i++)
            {
                get("villager").commandIds().add("villager." + i);
            }

            for (i = 0; i < 15; i++)
            {
                get("horse").numericalIds().add(500 + i);
            }
            for (i = 0; i < 15; i++)
            {
                get("horse").commandIds().add("horse." + i);
            }
            get("horse").numericalIds().add(400);
            get("horse").commandIds().add("horse.saddle");
            get("horse").numericalIds().add(401);
            get("horse").commandIds().add("horse.armor");
        }};

        protected SlotArgument()
        {
            super("slot", net.minecraft.class_2240.method_9473().getExamples(), false);
        }

        @Override
        protected ArgumentType<?> getArgumentType(CarpetScriptHost host)
        {
            return net.minecraft.class_2240.method_9473();
        }

        @Override
        protected Value getValueFromContext(CommandContext<class_2168> context, String param) throws CommandSyntaxException
        {
            int slot = net.minecraft.class_2240.method_9469(context, param);
            if (restrict != null && !RESTRICTED_CONTAINERS.get(restrict).numericalIds().contains(slot))
            {
                throw new SimpleCommandExceptionType(class_2561.method_43470("Incorrect slot restricted to " + restrict + " for custom type " + suffix)).create();
            }
            return ValueConversions.ofVanillaSlotResult(slot);
        }

        @Override
        protected void configure(Map<String, Value> config, CarpetScriptHost host) throws CommandSyntaxException
        {
            super.configure(config, host);
            if (config.containsKey("restrict"))
            {
                restrict = config.get("restrict").getString().toLowerCase(Locale.ROOT);
                needsMatching = true;
                if (!RESTRICTED_CONTAINERS.containsKey(restrict))
                {
                    throw error("Incorrect slot restriction " + restrict + " for custom type " + suffix);
                }
            }
        }

        @Override
        protected Collection<String> getOptions(CommandContext<class_2168> context, CarpetScriptHost host) throws CommandSyntaxException
        {
            return restrict == null ? super.getOptions(context, host) : RESTRICTED_CONTAINERS.get(restrict).commandIds();
        }

        @Override
        protected Supplier<CommandArgument> factory(MinecraftServer server)
        {
            return SlotArgument::new;
        }
    }

    @FunctionalInterface
    private interface ValueExtractor
    {
        Value apply(CommandContext<class_2168> ctx, String param) throws CommandSyntaxException;
    }

    @FunctionalInterface
    private interface ArgumentProvider
    {
        ArgumentType<?> get() throws CommandSyntaxException;
    }

    @FunctionalInterface
    private interface ArgumentProviderEx
    {
        ArgumentType<?> get(class_7157 regAccess) throws CommandSyntaxException;
    }

    public static class VanillaUnconfigurableArgument extends CommandArgument
    {
        private final ArgumentProvider argumentTypeSupplier;
        private final ArgumentProviderEx argumentTypeSupplierEx;
        private final ValueExtractor valueExtractor;
        private final boolean providesExamples;

        public VanillaUnconfigurableArgument(
                String suffix,
                ArgumentProvider argumentTypeSupplier,
                ValueExtractor valueExtractor,
                boolean suggestFromExamples
        )
        {
            super(suffix, null, suggestFromExamples);
            try
            {
                this.examples = argumentTypeSupplier.get().getExamples();
            }
            catch (CommandSyntaxException e)
            {
                this.examples = Collections.emptyList();
            }
            this.providesExamples = suggestFromExamples;
            this.argumentTypeSupplier = argumentTypeSupplier;
            this.valueExtractor = valueExtractor;
            this.argumentTypeSupplierEx = null;
        }

        public VanillaUnconfigurableArgument(
                String suffix,
                ArgumentProvider argumentTypeSupplier,
                ValueExtractor valueExtractor,
                SuggestionProvider<class_2168> suggester
        )
        {
            super(suffix, Collections.emptyList(), false);
            this.suggestionProvider = param -> suggester;
            this.providesExamples = false;
            this.argumentTypeSupplier = argumentTypeSupplier;
            this.valueExtractor = valueExtractor;
            this.argumentTypeSupplierEx = null;
        }

        public VanillaUnconfigurableArgument(
                String suffix,
                ArgumentProviderEx argumentTypeSupplier,
                ValueExtractor valueExtractor,
                boolean suggestFromExamples,
                MinecraftServer server)
        {
            super(suffix, null, suggestFromExamples);
            try
            {
                class_7157 context = class_7157.method_46722(server.method_30611(), server.method_27728().method_45560());
                this.examples = argumentTypeSupplier.get(context).getExamples();
            }
            catch (CommandSyntaxException e)
            {
                this.examples = Collections.emptyList();
            }
            this.providesExamples = suggestFromExamples;
            this.argumentTypeSupplierEx = argumentTypeSupplier;
            this.valueExtractor = valueExtractor;
            this.argumentTypeSupplier = null;
        }

        public VanillaUnconfigurableArgument(
                String suffix,
                ArgumentProviderEx argumentTypeSupplier,
                ValueExtractor valueExtractor,
                SuggestionProvider<class_2168> suggester
        )
        {
            super(suffix, Collections.emptyList(), false);
            this.suggestionProvider = param -> suggester;
            this.providesExamples = false;
            this.argumentTypeSupplierEx = argumentTypeSupplier;
            this.valueExtractor = valueExtractor;
            this.argumentTypeSupplier = null;
        }

        public VanillaUnconfigurableArgument(
                String suffix,
                ArgumentProviderEx argumentTypeSupplier,
                ValueExtractor valueExtractor,
                Function<String, SuggestionProvider<class_2168>> suggesterGen
        )
        {
            super(suffix, Collections.emptyList(), false);
            this.suggestionProvider = suggesterGen;
            this.providesExamples = false;
            this.argumentTypeSupplierEx = argumentTypeSupplier;
            this.valueExtractor = valueExtractor;
            this.argumentTypeSupplier = null;
        }

        public <T> VanillaUnconfigurableArgument(
                String suffix,
                class_5321<class_2378<T>> registry
        )
        {
            this(
                    suffix,
                    c -> class_7733.method_45603(c, registry),
                    (c, p) -> ValueConversions.of(class_7733.method_45602(c, p, registry).method_40237()),
                    (c, b) -> class_2172.method_9270(c.getSource().method_9211().method_30611().method_30530(registry).method_10235(), b)
            );
        }

        @Override
        protected ArgumentType<?> getArgumentType(CarpetScriptHost host) throws CommandSyntaxException
        {
            return argumentTypeSupplier != null
                    ? argumentTypeSupplier.get()
                    : argumentTypeSupplierEx.get(class_7157.method_46722(host.scriptServer().server.method_30611(), host.scriptServer().server.method_27728().method_45560()));
        }

        @Override
        protected Value getValueFromContext(CommandContext<class_2168> context, String param) throws CommandSyntaxException
        {
            return valueExtractor.apply(context, param);
        }

        @Override
        protected Supplier<CommandArgument> factory(MinecraftServer server)
        {
            return argumentTypeSupplier != null
                    ? (() -> new VanillaUnconfigurableArgument(getTypeSuffix(), argumentTypeSupplier, valueExtractor, providesExamples))
                    : (() -> new VanillaUnconfigurableArgument(getTypeSuffix(), argumentTypeSupplierEx, valueExtractor, providesExamples, server));
        }
    }
}
