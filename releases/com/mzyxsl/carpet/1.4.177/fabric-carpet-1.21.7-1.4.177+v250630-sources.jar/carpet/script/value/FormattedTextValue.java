package carpet.script.value;

import carpet.script.exception.InternalExpressionException;
import com.mojang.serialization.DynamicOps;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_5455;
import net.minecraft.class_8824;

public class FormattedTextValue extends StringValue
{
    class_2561 text;

    public FormattedTextValue(class_2561 text)
    {
        super(null);
        this.text = text;
    }

    public static Value combine(Value left, Value right)
    {
        class_5250 text;
        if (left instanceof FormattedTextValue ftv)
        {
            text = ftv.getText().method_27661();
        }
        else
        {
            if (left.isNull())
            {
                return right;
            }
            text = class_2561.method_43470(left.getString());
        }

        if (right instanceof FormattedTextValue ftv)
        {
            text.method_10852(ftv.getText().method_27661());
            return new FormattedTextValue(text);
        }
        if (right.isNull())
        {
            return left;
        }
        text.method_27693(right.getString());
        return new FormattedTextValue(text);
    }

    public static Value of(class_2561 text)
    {
        return text == null ? Value.NULL : new FormattedTextValue(text);
    }

    @Override
    public String getString()
    {
        return text.getString();
    }

    @Override
    public boolean getBoolean()
    {
        return !text.getString().isEmpty();
    }

    @Override
    public Value clone()
    {
        return new FormattedTextValue(text);
    }

    @Override
    public String getTypeString()
    {
        return "text";
    }

    public class_2561 getText()
    {
        return text;
    }

    @Override
    public class_2520 toTag(boolean force, class_5455 regs)
    {
        if (!force)
        {
            throw new NBTSerializableValue.IncompatibleTypeException(this);
        }
        return serialize(regs);
    }

    @Override
    public Value add(Value o)
    {
        return combine(this, o);
    }

    public class_2520 serialize(class_5455 regs)
    {
        return class_8824.field_46597.encodeStart(regs.method_57093(class_2509.field_11560), text).getOrThrow(InternalExpressionException::new);// text.getContents() Component.Serializer.toJson(text, regs);
    }

    public static FormattedTextValue deserialize(class_2520 tag, class_5455 regs)
    {
        return new FormattedTextValue(class_8824.field_46597.decode(regs.method_57093(class_2509.field_11560), tag).getOrThrow(InternalExpressionException::new).getFirst());
    }

    public static class_2561 getTextByValue(Value value)
    {
        return (value instanceof FormattedTextValue ftv) ? ftv.getText() : class_2561.method_43470(value.getString());
    }

}
