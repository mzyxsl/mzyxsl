package carpet.script.value;

import carpet.script.exception.InternalExpressionException;
import carpet.script.exception.ThrowStatement;
import carpet.script.exception.Throwables;
import carpet.script.external.Vanilla;
import carpet.script.utils.Colors;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.minecraft.class_11;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2096;
import net.minecraft.class_2248;
import net.minecraft.class_2265;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_266;
import net.minecraft.class_2680;
import net.minecraft.class_2694;
import net.minecraft.class_274;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3341;
import net.minecraft.class_3443;
import net.minecraft.class_3449;
import net.minecraft.class_3542;
import net.minecraft.class_3620;
import net.minecraft.class_4115;
import net.minecraft.class_4142;
import net.minecraft.class_4208;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6670;
import net.minecraft.class_6862;
import net.minecraft.class_6885;
import net.minecraft.class_7924;
import net.minecraft.class_9;
import net.minecraft.class_9015;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.StreamSupport;

import javax.annotation.Nullable;

public class ValueConversions
{
    public static Value of(class_2338 pos)
    {
        return ListValue.of(new NumericValue(pos.method_10263()), new NumericValue(pos.method_10264()), new NumericValue(pos.method_10260()));
    }

    public static Value of(class_243 vec)
    {
        return ListValue.of(new NumericValue(vec.field_1352), new NumericValue(vec.field_1351), new NumericValue(vec.field_1350));
    }

    public static Value of(class_2265 cpos)
    {
        return ListValue.of(new NumericValue(cpos.comp_638()), new NumericValue(cpos.comp_639()));
    }

    public static Value of(class_3218 world)
    {
        return of(world.method_27983().method_29177());
    }

    public static Value of(class_3620 color)
    {
        return ListValue.of(StringValue.of(Colors.mapColourName.get(color)), ofRGB(color.field_16011));
    }

    public static <T extends Number> Value of(class_2096<T> range)
    {
        return ListValue.of(
                range.comp_1805().map(NumericValue::of).orElse(Value.NULL),
                range.comp_1806().map(NumericValue::of).orElse(Value.NULL)
        );
    }

    public static Value of(class_1799 stack, class_5455 regs)
    {
        return stack == null || stack.method_7960() ? Value.NULL : ListValue.of(
                of(stack.method_7909(), regs),
                new NumericValue(stack.method_7947()),
                NBTSerializableValue.fromStack(stack, regs)
        );
    }

    public static Value of(class_1792 item, class_5455 regs)
    {
        return of(regs.method_30530(class_7924.field_41197).method_10221(item));
    }

    public static Value of(class_266 objective)
    {
        return ListValue.of(
                StringValue.of(objective.method_1113()),
                StringValue.of(objective.method_1116().method_1225())
        );
    }


    public static Value of(class_274 criteria)
    {
        return ListValue.of(
                StringValue.of(criteria.method_1225()),
                BooleanValue.of(criteria.method_1226())
        );
    }


    public static Value of(class_2394 particle, class_5455 regs)
    {
        String repr = class_2398.field_25125.encodeStart(regs.method_57093(class_2509.field_11560), particle).toString();
        return StringValue.of(repr.startsWith("minecraft:") ? repr.substring(10) : repr);
    }

    public static Value ofRGB(int value)
    {
        return new NumericValue(value * 256 + 255);
    }

    public static class_1937 dimFromValue(Value dimensionValue, MinecraftServer server)
    {
        if (dimensionValue instanceof EntityValue)
        {
            return ((EntityValue) dimensionValue).getEntity().method_37908();
        }
        else if (dimensionValue instanceof BlockValue bv)
        {
            if (bv.getWorld() != null)
            {
                return bv.getWorld();
            }
            else
            {
                throw new InternalExpressionException("dimension argument accepts only world-localized block arguments");
            }
        }
        else
        {
            String dimString = dimensionValue.getString().toLowerCase(Locale.ROOT);
            return switch (dimString) {
                case "nether", "the_nether" -> server.method_3847(class_1937.field_25180);
                case "end", "the_end" -> server.method_3847(class_1937.field_25181);
                case "overworld", "over_world" -> server.method_3847(class_1937.field_25179);
                default -> {
                    class_5321<class_1937> dim = null;
                    class_2960 id = class_2960.method_60654(dimString);
                    // not using RegistryKey.of since that one creates on check
                    for (class_5321<class_1937> world : (server.method_29435()))
                    {
                        if (id.equals(world.method_29177()))
                        {
                            dim = world;
                            break;
                        }
                    }
                    if (dim == null)
                    {
                        throw new ThrowStatement(dimString, Throwables.UNKNOWN_DIMENSION);
                    }
                    yield server.method_3847(dim);
                }
            };
        }
    }

    public static Value of(class_5321<?> dim)
    {
        return of(dim.method_29177());
    }

    public static Value of(class_6862<?> tagKey)
    {
        return of(tagKey.comp_327());
    }

    public static Value of(class_6885.class_6888<?> tagKey)
    {
        return of(tagKey.method_40251().comp_327());
    }

    public static Value of(@Nullable class_2960 id)
    {
        if (id == null) // should be Value.NULL
        {
            return Value.NULL;
        }
        return new StringValue(simplify(id));
    }

    public static String simplify(class_2960 id)
    {
        if (id == null) // should be Value.NULL
        {
            return "";
        }
        if (id.method_12836().equals("minecraft"))
        {
            return id.method_12832();
        }
        return id.toString();
    }

    public static Value of(class_4208 pos)
    {
        return ListValue.of(
                ValueConversions.of(pos.comp_2207()),
                ValueConversions.of(pos.comp_2208())
        );
    }

    public static Value fromPath(class_3218 world, class_11 path)
    {
        List<Value> nodes = new ArrayList<>();
        for (int i = 0, len = path.method_38(); i < len; i++)
        {
            class_9 node = path.method_40(i);
            nodes.add(ListValue.of(
                    new BlockValue(null, world, node.method_22879()),
                    new StringValue(node.field_41.name().toLowerCase(Locale.ROOT)),
                    new NumericValue(node.field_43),
                    BooleanValue.of(node.field_42)
            ));
        }
        return ListValue.wrap(nodes);
    }

    public static Value fromTimedMemory(class_1297 e, long expiry, Object v)
    {
        Value ret = fromEntityMemory(e, v);
        return ret.isNull() || expiry == Long.MAX_VALUE ? ret : ListValue.of(ret, new NumericValue(expiry));
    }

    private static Value fromEntityMemory(class_1297 e, Object v)
    {
        if (v instanceof class_4208 pos)
        {
            return of(pos);
        }
        if (v instanceof final class_1297 entity)
        {
            return new EntityValue(entity);
        }
        if (v instanceof final class_2338 pos)
        {
            return new BlockValue(null, (class_3218) e.method_37908(), pos);
        }
        if (v instanceof final Number number)
        {
            return new NumericValue(number.doubleValue());
        }
        if (v instanceof final Boolean bool)
        {
            return BooleanValue.of(bool);
        }
        if (v instanceof final UUID uuid)
        {
            return ofUUID((class_3218) e.method_37908(), uuid);
        }
        if (v instanceof final class_1282 source)
        {
            return ListValue.of(
                    new StringValue(source.method_5525()),
                    source.method_5529() == null ? Value.NULL : new EntityValue(source.method_5529())
            );
        }
        if (v instanceof final class_11 path)
        {
            return fromPath((class_3218) e.method_37908(), path);
        }
        if (v instanceof final class_4115 tracker)
        {
            return new BlockValue(null, (class_3218) e.method_37908(), tracker.method_18989());
        }
        if (v instanceof final class_4142 target)
        {
            return ListValue.of(
                    new BlockValue(null, (class_3218) e.method_37908(), target.method_19094().method_18989()),
                    new NumericValue(target.method_19095()),
                    new NumericValue(target.method_19096())
            );
        }
        if (v instanceof final class_6670 nvle)
        {
            v = StreamSupport.stream(nvle.method_38978(entity -> true).spliterator(), false).toList();
        }
        if (v instanceof final Set<?> set)
        {
            v = new ArrayList<>(set);
        }
        if (v instanceof final List<?> l)
        {
            if (l.isEmpty())
            {
                return ListValue.of();
            }
            Object el = l.get(0);
            if (el instanceof final class_1297 entity)
            {
                return ListValue.wrap(l.stream().map(o -> new EntityValue(entity)));
            }
            if (el instanceof final class_4208 pos)
            {
                return ListValue.wrap(l.stream().map(o -> of(pos)));
            }
        }
        return Value.NULL;
    }

    private static Value ofUUID(class_3218 entityWorld, UUID uuid)
    {
        class_1297 current = entityWorld.method_66347(uuid);
        return ListValue.of(
                current == null ? Value.NULL : new EntityValue(current),
                new StringValue(uuid.toString())
        );
    }

    public static Value of(class_238 box)
    {
        return ListValue.of(
                ListValue.fromTriple(box.field_1323, box.field_1322, box.field_1321),
                ListValue.fromTriple(box.field_1320, box.field_1325, box.field_1324)
        );
    }

    public static Value of(class_3341 box)
    {
        return ListValue.of(
                ListValue.fromTriple(box.method_35415(), box.method_35416(), box.method_35417()),
                ListValue.fromTriple(box.method_35418(), box.method_35419(), box.method_35420())
        );
    }

    public static Value of(class_3449 structure, class_5455 regs)
    {
        if (structure == null || structure == class_3449.field_16713)
        {
            return Value.NULL;
        }
        class_3341 boundingBox = structure.method_14969();
        if (boundingBox.method_35418() < boundingBox.method_35415() || boundingBox.method_35419() < boundingBox.method_35416() || boundingBox.method_35420() < boundingBox.method_35417())
        {
            return Value.NULL;
        }
        Map<Value, Value> ret = new HashMap<>();
        ret.put(new StringValue("box"), of(boundingBox));
        List<Value> pieces = new ArrayList<>();
        for (class_3443 piece : structure.method_14963())
        {
            class_3341 box = piece.method_14935();
            if (box.method_35418() >= box.method_35415() && box.method_35419() >= box.method_35416() && box.method_35420() >= box.method_35417())
            {
                pieces.add(ListValue.of(
                        NBTSerializableValue.nameFromRegistryId(regs.method_30530(class_7924.field_41227).method_10221(piece.method_16653())),
                        (piece.method_14934() == null) ? Value.NULL : new StringValue(piece.method_14934().method_10151()),
                        ListValue.fromTriple(box.method_35415(), box.method_35416(), box.method_35417()),
                        ListValue.fromTriple(box.method_35418(), box.method_35419(), box.method_35420())
                ));
            }
        }
        ret.put(new StringValue("pieces"), ListValue.wrap(pieces));
        return MapValue.wrap(ret);
    }

    public static Value of(final class_9015 scoreHolder)
    {
        return FormattedTextValue.of(scoreHolder.method_55423());
    }

    public static Value fromProperty(class_2680 state, class_2769<?> p)
    {
        Comparable<?> object = state.method_11654(p);
        if (object instanceof Boolean || object instanceof Number)
        {
            return StringValue.of(object.toString());
        }
        if (object instanceof final class_3542 stringRepresentable)
        {
            return StringValue.of(stringRepresentable.method_15434());
        }
        throw new InternalExpressionException("Unknown property type: " + p.method_11899());
    }

    record SlotParam(/* Nullable */ String type, int id)
    {
        public ListValue build()
        {
            return ListValue.of(StringValue.of(type), new NumericValue(id));
        }
    }

    private static final Int2ObjectMap<SlotParam> slotIdsToSlotParams = new Int2ObjectOpenHashMap<>()
    {{
        int n;
        //covers blocks, player hotbar and inventory, and all default inventories
        for (n = 0; n < 54; ++n)
        {
            put(n, new SlotParam(null, n));
        }
        for (n = 0; n < 27; ++n)
        {
            put(200 + n, new SlotParam("enderchest", n));
        }

        // villager
        for (n = 0; n < 8; ++n)
        {
            put(300 + n, new SlotParam(null, n));
        }

        // horse, llamas, donkeys, etc.
        // two first slots are for saddle and armour
        for (n = 0; n < 15; ++n)
        {
            put(500 + n, new SlotParam(null, n + 2));
        }
        // weapon main hand
        put(98, new SlotParam("equipment", 0));
        // offhand
        put(99, new SlotParam("equipment", 5));
        // feet, legs, chest, head
        for (n = 0; n < 4; ++n)
        {
            put(100 + n, new SlotParam("equipment", n + 1));
        }
        //horse defaults saddle
        put(400, new SlotParam(null, 0));
        // armor
        put(401, new SlotParam(null, 1));
        // chest itself on the donkey is wierd - use NBT to alter that.
        //hashMap.put("horse.chest", 499);
    }};

    public static Value ofVanillaSlotResult(int itemSlot)
    {
        SlotParam ret = slotIdsToSlotParams.get(itemSlot);
        return ret == null ? ListValue.of(Value.NULL, new NumericValue(itemSlot)) : ret.build();
    }

    public static Value ofBlockPredicate(class_5455 registryAccess, Predicate<class_2694> blockPredicate)
    {
        Vanilla.BlockPredicatePayload payload = Vanilla.BlockPredicatePayload.of(blockPredicate);
        class_2378<class_2248> blocks = registryAccess.method_30530(class_7924.field_41254);
        return ListValue.of(
                payload.state() == null ? Value.NULL : of(blocks.method_10221(payload.state().method_26204())),
                payload.tagKey() == null ? Value.NULL : of(blocks.method_46733(payload.tagKey()).get().method_40251()),
                MapValue.wrap(payload.properties()),
                payload.tag() == null ? Value.NULL : new NBTSerializableValue(payload.tag())
        );
    }

    public static class_1799 getItemStackFromValue(Value value, boolean withCount, class_5455 regs)
    {
        if (value.isNull())
        {
            return class_1799.field_8037;
        }
        String name;
        int count = 1;
        class_2487 nbtTag = null;
        if (value instanceof ListValue list)
        {
            if (list.length() != 3)
            {
                throw new ThrowStatement("item definition from list of size " + list.length(), Throwables.UNKNOWN_ITEM);
            }
            List<Value> items = list.getItems();
            name = items.get(0).getString();
            if (withCount)
            {
                count = NumericValue.asNumber(items.get(1)).getInt();
            }
            Value nbtValue = items.get(2);
            if (!nbtValue.isNull())
            {
                nbtTag = ((NBTSerializableValue) NBTSerializableValue.fromValue(nbtValue)).getCompoundTag();
            }
        }
        else
        {
            name = value.getString();
        }
        class_1799 itemInput = NBTSerializableValue.parseItem(name, nbtTag, regs);
        itemInput.method_7939(count);
        return itemInput;
    }

    public static Value guess(class_3218 serverWorld, Object o)
    {
        if (o == null)
        {
            return Value.NULL;
        }
        if (o instanceof final List<?> list)
        {
            return ListValue.wrap(list.stream().map(oo -> guess(serverWorld, oo)));
        }
        if (o instanceof final class_2338 pos)
        {
            return new BlockValue(null, serverWorld, pos);
        }
        if (o instanceof final class_1297 e)
        {
            return EntityValue.of(e);
        }
        if (o instanceof final class_243 vec3)
        {
            return of(vec3);
        }
        if (o instanceof final class_2382 vec3i)
        {
            return of(new class_2338(vec3i));
        }
        if (o instanceof final class_238 aabb)
        {
            return of(aabb);
        }
        if (o instanceof final class_3341 bb)
        {
            return of(bb);
        }
        if (o instanceof final class_1799 itemStack)
        {
            return of(itemStack, serverWorld.method_30349());
        }
        if (o instanceof final Boolean bool)
        {
            return BooleanValue.of(bool);
        }
        if (o instanceof final Number number)
        {
            return NumericValue.of(number);
        }
        if (o instanceof final class_2960 resourceLocation)
        {
            return of(resourceLocation);
        }
        return StringValue.of(o.toString());
    }
}
