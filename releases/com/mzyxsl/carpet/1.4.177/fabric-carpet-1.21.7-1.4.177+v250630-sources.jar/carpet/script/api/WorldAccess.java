package carpet.script.api;

import carpet.script.CarpetContext;
import carpet.script.CarpetScriptServer;
import carpet.script.Context;
import carpet.script.Expression;
import carpet.script.Fluff;
import carpet.script.external.Carpet;
import carpet.script.external.Vanilla;
import carpet.script.utils.Colors;
import carpet.script.utils.FeatureGenerator;
import carpet.script.argument.BlockArgument;
import carpet.script.argument.Vector3Argument;
import carpet.script.exception.InternalExpressionException;
import carpet.script.exception.ThrowStatement;
import carpet.script.exception.Throwables;
import carpet.script.utils.BiomeInfo;
import carpet.script.utils.InputValidator;
import carpet.script.utils.WorldTools;
import carpet.script.value.BlockValue;
import carpet.script.value.BooleanValue;
import carpet.script.value.EntityValue;
import carpet.script.value.ListValue;
import carpet.script.value.MapValue;
import carpet.script.value.NBTSerializableValue;
import carpet.script.value.NumericValue;
import carpet.script.value.StringValue;
import carpet.script.value.Value;
import carpet.script.value.ValueConversions;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongSet;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.apache.commons.lang3.tuple.Pair;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import net.minecraft.class_10;
import net.minecraft.class_11352;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1540;
import net.minecraft.class_156;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1820;
import net.minecraft.class_1835;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1923;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_1948;
import net.minecraft.class_1959;
import net.minecraft.class_1966;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2498;
import net.minecraft.class_2509;
import net.minecraft.class_2586;
import net.minecraft.class_2664;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2769;
import net.minecraft.class_2791;
import net.minecraft.class_2794;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_2841;
import net.minecraft.class_2902;
import net.minecraft.class_2919;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3204;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3228;
import net.minecraft.class_3230;
import net.minecraft.class_3341;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3449;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_3754;
import net.minecraft.class_4153;
import net.minecraft.class_4156;
import net.minecraft.class_4158;
import net.minecraft.class_4766;
import net.minecraft.class_5268;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5742;
import net.minecraft.class_6544;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_6910;
import net.minecraft.class_6916;
import net.minecraft.class_6953;
import net.minecraft.class_7138;
import net.minecraft.class_7151;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8942;
import net.minecraft.class_9892;

import static carpet.script.utils.WorldTools.canHasChunk;

public class WorldAccess
{
    private static final Map<String, class_2350> DIRECTION_MAP = Arrays.stream(class_2350.values()).collect(Collectors.toMap(class_2350::method_10151, Function.identity()));

    static
    {
        DIRECTION_MAP.put("y", class_2350.field_11036);
        DIRECTION_MAP.put("z", class_2350.field_11035);
        DIRECTION_MAP.put("x", class_2350.field_11034);
    }

    private static final Map<String, class_3230> ticketTypes = Map.of(
            "portal", class_3230.field_19280,
            "teleport", class_3230.field_54211,
            "unknown", class_3230.field_14032
    );
    // dummy entity for dummy requirements in the loot tables (see snowball)
    private static class_1540 DUMMY_ENTITY = null;

    private static Value booleanStateTest(
            Context c,
            String name,
            List<Value> params,
            BiPredicate<class_2680, class_2338> test
    )
    {
        CarpetContext cc = (CarpetContext) c;
        if (params.isEmpty())
        {
            throw new InternalExpressionException("'" + name + "' requires at least one parameter");
        }
        if (params.get(0) instanceof final BlockValue bv)
        {
            return BooleanValue.of(test.test(bv.getBlockState(), bv.getPos()));
        }
        BlockValue block = BlockArgument.findIn(cc, params, 0).block;
        return BooleanValue.of(test.test(block.getBlockState(), block.getPos()));
    }

    private static Value stateStringQuery(
            Context c,
            String name,
            List<Value> params,
            BiFunction<class_2680, class_2338, String> test
    )
    {
        CarpetContext cc = (CarpetContext) c;
        if (params.isEmpty())
        {
            throw new InternalExpressionException("'" + name + "' requires at least one parameter");
        }
        if (params.get(0) instanceof final BlockValue bv)
        {
            return StringValue.of(test.apply(bv.getBlockState(), bv.getPos()));
        }
        BlockValue block = BlockArgument.findIn(cc, params, 0).block;
        return StringValue.of(test.apply(block.getBlockState(), block.getPos()));
    }

    private static Value genericStateTest(
            Context c,
            String name,
            List<Value> params,
            Fluff.TriFunction<class_2680, class_2338, class_1937, Value> test
    )
    {
        CarpetContext cc = (CarpetContext) c;
        if (params.isEmpty())
        {
            throw new InternalExpressionException("'" + name + "' requires at least one parameter");
        }
        if (params.get(0) instanceof final BlockValue bv)
        {
            try
            {
                return test.apply(bv.getBlockState(), bv.getPos(), cc.level());
            }
            catch (NullPointerException ignored)
            {
                throw new InternalExpressionException("'" + name + "' function requires a block that is positioned in the world");
            }
        }
        BlockValue block = BlockArgument.findIn(cc, params, 0).block;
        return test.apply(block.getBlockState(), block.getPos(), cc.level());
    }

    private static <T extends Comparable<T>> class_2680 setProperty(class_2769<T> property, String name, String value,
                                                                    class_2680 bs)
    {
        Optional<T> optional = property.method_11900(value);
        if (optional.isEmpty())
        {
            throw new InternalExpressionException(value + " is not a valid value for property " + name);
        }
        return bs.method_11657(property, optional.get());
    }

    private static void nullCheck(Value v, String name)
    {
        if (v.isNull())
        {
            throw new IllegalArgumentException(name + " cannot be null");
        }
    }

    private static float numberGetOrThrow(Value v)
    {
        double num = v.readDoubleNumber();
        if (Double.isNaN(num))
        {
            throw new IllegalArgumentException(v.getString() + " needs to be a numeric value");
        }
        return (float) num;
    }

    private static void theBooYah(class_3218 level)
    {
        synchronized (level)
        {
            level.method_14178().method_46642().method_46712();
        }
    }

    public static void apply(Expression expression)
    {
        expression.addContextFunction("block", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            if (lv.isEmpty())
            {
                throw new InternalExpressionException("Block requires at least one parameter");
            }
            BlockValue retval = BlockArgument.findIn(cc, lv, 0, true).block;
            // fixing block state and data
            retval.getBlockState();
            retval.getData();
            return retval;
        });

        expression.addContextFunction("block_data", -1, (c, t, lv) ->
        {
            if (lv.isEmpty())
            {
                throw new InternalExpressionException("Block requires at least one parameter");
            }
            return NBTSerializableValue.of(BlockArgument.findIn((CarpetContext) c, lv, 0, true).block.getData());
        });

        // poi_get(pos, radius?, type?, occupation?, column_mode?)
        expression.addContextFunction("poi", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            if (lv.isEmpty())
            {
                throw new InternalExpressionException("'poi' requires at least one parameter");
            }
            BlockArgument locator = BlockArgument.findIn(cc, lv, 0, false);
            class_2338 pos = locator.block.getPos();
            class_4153 store = cc.level().method_19494();
            class_2378<class_4158> poiReg = cc.registry(class_7924.field_41212);
            if (lv.size() == locator.offset)
            {
                Optional<class_6880<class_4158>> foo = store.method_19132(pos);
                if (foo.isEmpty())
                {
                    return Value.NULL;
                }
                class_4158 poiType = foo.get().comp_349();

                // this feels wrong, but I don't want to mix-in more than I really need to.
                // also distance adds 0.5 to each point which screws up accurate distance calculations
                // you shoudn't be using POI with that in mind anyways, so I am not worried about it.
                class_4156 poi = store.method_19125(
                        type -> type.comp_349() == poiType,
                        pos,
                        1,
                        class_4153.class_4155.field_18489
                ).filter(p -> p.method_19141().equals(pos)).findFirst().orElse(null);
                return poi == null ? Value.NULL : ListValue.of(
                        ValueConversions.of(poiReg.method_10221(poi.method_19142().comp_349())),
                        new NumericValue(poiType.comp_816() - Vanilla.PoiRecord_getFreeTickets(poi))
                );
            }
            int radius = NumericValue.asNumber(lv.get(locator.offset)).getInt();
            if (radius < 0)
            {
                return ListValue.of();
            }
            Predicate<class_6880<class_4158>> condition = p -> true;
            class_4153.class_4155 status = class_4153.class_4155.field_18489;
            boolean inColumn = false;
            if (locator.offset + 1 < lv.size())
            {
                String poiType = lv.get(locator.offset + 1).getString().toLowerCase(Locale.ROOT);
                if (!"any".equals(poiType))
                {
                    class_4158 type = poiReg.method_17966(InputValidator.identifierOf(poiType))
                            .orElseThrow(() -> new ThrowStatement(poiType, Throwables.UNKNOWN_POI));
                    condition = tt -> tt.comp_349() == type;
                }
                if (locator.offset + 2 < lv.size())
                {
                    String statusString = lv.get(locator.offset + 2).getString().toLowerCase(Locale.ROOT);
                    if ("occupied".equals(statusString))
                    {
                        status = class_4153.class_4155.field_18488;
                    }
                    else if ("available".equals(statusString))
                    {
                        status = class_4153.class_4155.field_18487;
                    }
                    else if (!("any".equals(statusString)))
                    {
                        throw new InternalExpressionException(
                                "Incorrect POI occupation status " + status + " use `any`, " + "`occupied` or `available`"
                        );
                    }
                    if (locator.offset + 3 < lv.size())
                    {
                        inColumn = lv.get(locator.offset + 3).getBoolean();
                    }
                }
            }
            Stream<class_4156> pois = inColumn ?
                    store.method_22383(condition, pos, radius, status) :
                    store.method_19125(condition, pos, radius, status);
            return ListValue.wrap(pois.sorted(Comparator.comparingDouble(p -> p.method_19141().method_10262(pos))).map(p ->
                    ListValue.of(
                            ValueConversions.of(poiReg.method_10221(p.method_19142().comp_349())),
                            new NumericValue(p.method_19142().comp_349().comp_816() - Vanilla.PoiRecord_getFreeTickets(p)),
                            ValueConversions.of(p.method_19141())
                    )
            ));
        });

        //poi_set(pos, null) poi_set(pos, type, occupied?,
        expression.addContextFunction("set_poi", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            if (lv.isEmpty())
            {
                throw new InternalExpressionException("'set_poi' requires at least one parameter");
            }
            BlockArgument locator = BlockArgument.findIn(cc, lv, 0, false);
            class_2338 pos = locator.block.getPos();
            if (lv.size() < locator.offset)
            {
                throw new InternalExpressionException("'set_poi' requires the new poi type or null, after position argument");
            }
            Value poi = lv.get(locator.offset);
            class_4153 store = cc.level().method_19494();
            if (poi.isNull())
            {   // clear poi information
                if (store.method_19132(pos).isEmpty())
                {
                    return Value.FALSE;
                }
                store.method_19112(pos);
                return Value.TRUE;
            }
            String poiTypeString = poi.getString().toLowerCase(Locale.ROOT);
            class_2960 resource = InputValidator.identifierOf(poiTypeString);
            class_2378<class_4158> poiReg = cc.registry(class_7924.field_41212);
            class_4158 type = poiReg.method_17966(resource)
                    .orElseThrow(() -> new ThrowStatement(poiTypeString, Throwables.UNKNOWN_POI));
            class_6880<class_4158> holder = poiReg.method_46747(class_5321.method_29179(class_7924.field_41212, resource));

            int occupancy = 0;
            if (locator.offset + 1 < lv.size())
            {
                occupancy = (int) NumericValue.asNumber(lv.get(locator.offset + 1)).getLong();
                if (occupancy < 0)
                {
                    throw new InternalExpressionException("Occupancy cannot be negative");
                }
            }
            if (store.method_19132(pos).isPresent())
            {
                store.method_19112(pos);
            }
            store.method_19115(pos, holder);
            // setting occupancy for a
            // again - don't want to mix in unnecessarily - peeps not gonna use it that often so not worries about it.
            if (occupancy > 0)
            {
                int finalO = occupancy;
                store.method_22383(tt -> tt.comp_349() == type, pos, 1, class_4153.class_4155.field_18489
                ).filter(p -> p.method_19141().equals(pos)).findFirst().ifPresent(p -> {
                    for (int i = 0; i < finalO; i++)
                    {
                        Vanilla.PoiRecord_callAcquireTicket(p);
                    }
                });
            }
            return Value.TRUE;
        });


        expression.addContextFunction("weather", -1, (c, t, lv) -> {
            class_3218 world = ((CarpetContext) c).level();

            if (lv.isEmpty())//cos it can thunder when raining or when clear.
            {
                return new StringValue(world.method_8546() ? "thunder" : (world.method_8419() ? "rain" : "clear"));
            }

            Value weather = lv.get(0);
            class_5268 worldProperties = Vanilla.ServerLevel_getWorldProperties(world);
            if (lv.size() == 1)
            {
                return new NumericValue(switch (weather.getString().toLowerCase(Locale.ROOT))
                {
                    case "clear" -> worldProperties.method_155();
                    case "rain" -> world.method_8419() ? worldProperties.method_190() : 0;//cos if not it gives 1 for some reason
                    case "thunder" -> world.method_8546() ? worldProperties.method_145() : 0;//same dealio here
                    default -> throw new InternalExpressionException("Weather can only be 'clear', 'rain' or 'thunder'");
                });
            }
            if (lv.size() == 2)
            {
                int ticks = NumericValue.asNumber(lv.get(1), "tick_time in 'weather'").getInt();
                switch (weather.getString().toLowerCase(Locale.ROOT))
                {
                    case "clear" -> world.method_27910(ticks, 0, false, false);
                    case "rain" -> world.method_27910(0, ticks, true, false);
                    case "thunder" -> world.method_27910(
                            0,
                            ticks,//this is used to set thunder time, idk why...
                            true,
                            true
                    );
                    default -> throw new InternalExpressionException("Weather can only be 'clear', 'rain' or 'thunder'");
                }
                return NumericValue.of(ticks);
            }
            throw new InternalExpressionException("'weather' requires 0, 1 or 2 arguments");
        });

        expression.addUnaryFunction("pos", v ->
        {
            if (v instanceof final BlockValue bv)
            {
                class_2338 pos = bv.getPos();
                if (pos == null)
                {
                    throw new InternalExpressionException("Cannot fetch position of an unrealized block");
                }
                return ValueConversions.of(pos);
            }
            if (v instanceof final EntityValue ev)
            {
                class_1297 e = ev.getEntity();
                if (e == null)
                {
                    throw new InternalExpressionException("Null entity");
                }
                return ValueConversions.of(e.method_19538());
            }
            throw new InternalExpressionException("'pos' works only with a block or an entity type");
        });

        expression.addContextFunction("pos_offset", -1, (c, t, lv) ->
        {
            BlockArgument locator = BlockArgument.findIn((CarpetContext) c, lv, 0);
            class_2338 pos = locator.block.getPos();
            if (lv.size() <= locator.offset)
            {
                throw new InternalExpressionException("'pos_offset' needs at least position, and direction");
            }
            String directionString = lv.get(locator.offset).getString();
            class_2350 dir = DIRECTION_MAP.get(directionString);
            if (dir == null)
            {
                throw new InternalExpressionException("Unknown direction: " + directionString);
            }
            int howMuch = 1;
            if (lv.size() > locator.offset + 1)
            {
                howMuch = (int) NumericValue.asNumber(lv.get(locator.offset + 1)).getLong();
            }
            return ValueConversions.of(pos.method_10079(dir, howMuch));
        });

        expression.addContextFunction("solid", -1, (c, t, lv) ->
                genericStateTest(c, "solid", lv, (s, p, w) -> BooleanValue.of(s.method_26212(w, p)))); // isSimpleFullBlock

        expression.addContextFunction("air", -1, (c, t, lv) ->
                booleanStateTest(c, "air", lv, (s, p) -> s.method_26215()));

        expression.addContextFunction("liquid", -1, (c, t, lv) ->
                booleanStateTest(c, "liquid", lv, (s, p) -> !s.method_26227().method_15769()));

        expression.addContextFunction("flammable", -1, (c, t, lv) ->
                booleanStateTest(c, "flammable", lv, (s, p) -> s.method_50011()));

        expression.addContextFunction("transparent", -1, (c, t, lv) ->
                booleanStateTest(c, "transparent", lv, (s, p) -> !s.method_51367()));

        /*this.expr.addContextFunction("opacity", -1, (c, t, lv) ->
                genericStateTest(c, "opacity", lv, (s, p, w) -> new NumericValue(s.getOpacity(w, p))));

        this.expr.addContextFunction("blocks_daylight", -1, (c, t, lv) ->
                genericStateTest(c, "blocks_daylight", lv, (s, p, w) -> new NumericValue(s.propagatesSkylightDown(w, p))));*/ // investigate

        expression.addContextFunction("emitted_light", -1, (c, t, lv) ->
                genericStateTest(c, "emitted_light", lv, (s, p, w) -> new NumericValue(s.method_26213())));

        expression.addContextFunction("light", -1, (c, t, lv) ->
                genericStateTest(c, "light", lv, (s, p, w) -> new NumericValue(Math.max(w.method_8314(class_1944.field_9282, p), w.method_8314(class_1944.field_9284, p)))));

        expression.addContextFunction("block_light", -1, (c, t, lv) ->
                genericStateTest(c, "block_light", lv, (s, p, w) -> new NumericValue(w.method_8314(class_1944.field_9282, p))));

        expression.addContextFunction("sky_light", -1, (c, t, lv) ->
                genericStateTest(c, "sky_light", lv, (s, p, w) -> new NumericValue(w.method_8314(class_1944.field_9284, p))));

        expression.addContextFunction("effective_light", -1, (c, t, lv) ->
                genericStateTest(c, "effective_light", lv, (s, p, w) -> new NumericValue(w.method_22339(p))));

        expression.addContextFunction("see_sky", -1, (c, t, lv) ->
                genericStateTest(c, "see_sky", lv, (s, p, w) -> BooleanValue.of(w.method_8311(p))));

        expression.addContextFunction("brightness", -1, (c, t, lv) ->
                genericStateTest(c, "brightness", lv, (s, p, w) -> new NumericValue(w.method_22349(p))));

        expression.addContextFunction("hardness", -1, (c, t, lv) ->
                genericStateTest(c, "hardness", lv, (s, p, w) -> new NumericValue(s.method_26214(w, p))));

        expression.addContextFunction("blast_resistance", -1, (c, t, lv) ->
                genericStateTest(c, "blast_resistance", lv, (s, p, w) -> new NumericValue(s.method_26204().method_9520())));

        expression.addContextFunction("in_slime_chunk", -1, (c, t, lv) ->
        {
            class_2338 pos = BlockArgument.findIn((CarpetContext) c, lv, 0).block.getPos();
            class_1923 chunkPos = new class_1923(pos);
            return BooleanValue.of(class_2919.method_12662(
                    chunkPos.field_9181, chunkPos.field_9180,
                    ((CarpetContext) c).level().method_8412(),
                    987234911L
            ).method_43048(10) == 0);
        });

        expression.addContextFunction("top", -1, (c, t, lv) ->
        {
            String type = lv.get(0).getString().toLowerCase(Locale.ROOT);
            class_2902.class_2903 htype = switch (type)
            {
                //case "light": htype = Heightmap.Type.LIGHT_BLOCKING; break;  //investigate
                case "motion" -> class_2902.class_2903.field_13197;
                case "terrain" -> class_2902.class_2903.field_13203;
                case "ocean_floor" -> class_2902.class_2903.field_13200;
                case "surface" -> class_2902.class_2903.field_13202;
                default -> throw new InternalExpressionException("Unknown heightmap type: " + type);
            };
            BlockArgument locator = BlockArgument.findIn((CarpetContext) c, lv, 1);
            class_2338 pos = locator.block.getPos();
            int x = pos.method_10263();
            int z = pos.method_10260();
            return new NumericValue(((CarpetContext) c).level().method_8497(x >> 4, z >> 4).method_12005(htype, x & 15, z & 15) + 1);
        });

        expression.addContextFunction("loaded", -1, (c, t, lv) ->
                BooleanValue.of((((CarpetContext) c).level().method_22340(BlockArgument.findIn((CarpetContext) c, lv, 0).block.getPos()))));

        // Deprecated, use loaded_status as more indicative
        expression.addContextFunction("loaded_ep", -1, (c, t, lv) ->
        {
            c.host.issueDeprecation("loaded_ep(...)");
            class_2338 pos = BlockArgument.findIn((CarpetContext) c, lv, 0).block.getPos();
            return BooleanValue.of(((CarpetContext) c).level().method_37118(pos));
        });

        expression.addContextFunction("loaded_status", -1, (c, t, lv) ->
        {
            class_2338 pos = BlockArgument.findIn((CarpetContext) c, lv, 0).block.getPos();
            class_2818 chunk = ((CarpetContext) c).level().method_14178().method_12126(pos.method_10263() >> 4, pos.method_10260() >> 4, false);
            return chunk == null ? Value.ZERO : new NumericValue(chunk.method_12225().ordinal());
        });

        expression.addContextFunction("is_chunk_generated", -1, (c, t, lv) ->
        {
            BlockArgument locator = BlockArgument.findIn((CarpetContext) c, lv, 0);
            class_2338 pos = locator.block.getPos();
            boolean force = false;
            if (lv.size() > locator.offset)
            {
                force = lv.get(locator.offset).getBoolean();
            }
            return BooleanValue.of(canHasChunk(((CarpetContext) c).level(), new class_1923(pos), null, force));
        });

        expression.addContextFunction("generation_status", -1, (c, t, lv) ->
        {
            BlockArgument blockArgument = BlockArgument.findIn((CarpetContext) c, lv, 0);
            class_2338 pos = blockArgument.block.getPos();
            boolean forceLoad = false;
            if (lv.size() > blockArgument.offset)
            {
                forceLoad = lv.get(blockArgument.offset).getBoolean();
            }
            class_2791 chunk = ((CarpetContext) c).level().method_8402(pos.method_10263() >> 4, pos.method_10260() >> 4, class_2806.field_12798, forceLoad);
            return chunk == null ? Value.NULL : ValueConversions.of(class_7923.field_41184.method_10221(chunk.method_12009()));
        });

        expression.addContextFunction("chunk_tickets", -1, (c, t, lv) ->
        {
            class_3218 world = ((CarpetContext) c).level();
            class_3204 foo = world.method_14178().field_17254.method_17263();
            Long2ObjectOpenHashMap<List<class_3228>> levelTickets = Vanilla.ChunkTicketManager_getTicketsByPosition(foo);

            List<Value> res = new ArrayList<>();
            if (lv.isEmpty())
            {
                for (long key : levelTickets.keySet())
                {
                    class_1923 chpos = new class_1923(key);
                    for (class_3228 ticket : levelTickets.get(key))
                    {
                        res.add(ListValue.of(
                                new StringValue(ticket.method_14281().toString()),
                                new NumericValue(33 - ticket.method_14283()),
                                new NumericValue(chpos.field_9181),
                                new NumericValue(chpos.field_9180)
                        ));
                    }
                }
            }
            else
            {
                BlockArgument blockArgument = BlockArgument.findIn((CarpetContext) c, lv, 0);
                class_2338 pos = blockArgument.block.getPos();
                List<class_3228> tickets = levelTickets.get(new class_1923(pos).method_8324());
                if (tickets != null)
                {
                    for (class_3228 ticket : tickets)
                    {
                        res.add(ListValue.of(
                                new StringValue(ticket.method_14281().toString()),
                                new NumericValue(33 - ticket.method_14283())
                        ));
                    }
                }
            }
            res.sort(Comparator.comparing(e -> ((ListValue) e).getItems().get(1)).reversed());
            return ListValue.wrap(res);
        });

        expression.addContextFunction("suffocates", -1, (c, t, lv) ->
                genericStateTest(c, "suffocates", lv, (s, p, w) -> BooleanValue.of(s.method_26228(w, p)))); // canSuffocate

        expression.addContextFunction("power", -1, (c, t, lv) ->
                genericStateTest(c, "power", lv, (s, p, w) -> new NumericValue(w.method_49804(p))));

        expression.addContextFunction("ticks_randomly", -1, (c, t, lv) ->
                booleanStateTest(c, "ticks_randomly", lv, (s, p) -> s.method_26229()));

        expression.addContextFunction("update", -1, (c, t, lv) ->
                booleanStateTest(c, "update", lv, (s, p) ->
                {
                    ((CarpetContext) c).level().method_8492(p, s.method_26204(), null);
                    return true;
                }));

        expression.addContextFunction("block_tick", -1, (c, t, lv) ->
                booleanStateTest(c, "block_tick", lv, (s, p) ->
                {
                    class_3218 w = ((CarpetContext) c).level();
                    s.method_26199(w, p, w.field_9229);
                    return true;
                }));

        expression.addContextFunction("random_tick", -1, (c, t, lv) ->
                booleanStateTest(c, "random_tick", lv, (s, p) ->
                {
                    class_3218 w = ((CarpetContext) c).level();
                    if (s.method_26229() || s.method_26227().method_15773())
                    {
                        s.method_26199(w, p, w.field_9229);
                    }
                    return true;
                }));

        // lazy cause its parked execution
        expression.addLazyFunction("without_updates", 1, (c, t, lv) ->
        {
            if (Carpet.getImpendingFillSkipUpdates().get())
            {
                return lv.get(0);
            }
            Value[] result = new Value[]{Value.NULL};
            ((CarpetContext) c).server().method_19537(() ->
            {
                ThreadLocal<Boolean> skipUpdates = Carpet.getImpendingFillSkipUpdates();
                boolean previous = skipUpdates.get();
                try
                {
                    skipUpdates.set(true);
                    result[0] = lv.get(0).evalValue(c, t);
                }
                finally
                {
                    skipUpdates.set(previous);
                }
            });
            return (cc, tt) -> result[0];
        });

        expression.addContextFunction("set", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            class_3218 world = cc.level();
            BlockArgument targetLocator = BlockArgument.findIn(cc, lv, 0);
            BlockArgument sourceLocator = BlockArgument.findIn(cc, lv, targetLocator.offset, true);
            class_2680 sourceBlockState = sourceLocator.block.getBlockState();
            class_2680 targetBlockState = world.method_8320(targetLocator.block.getPos());
            class_2487 data = null;
            if (lv.size() > sourceLocator.offset)
            {
                List<Value> args = new ArrayList<>();
                for (int i = sourceLocator.offset, m = lv.size(); i < m; i++)
                {
                    args.add(lv.get(i));
                }
                if (args.get(0) instanceof final ListValue list)
                {
                    if (args.size() == 2 && NBTSerializableValue.fromValue(args.get(1)) instanceof final NBTSerializableValue nbtsv)
                    {
                        data = nbtsv.getCompoundTag();
                    }
                    args = list.getItems();
                }
                else if (args.get(0) instanceof final MapValue map)
                {
                    if (args.size() == 2 && NBTSerializableValue.fromValue(args.get(1)) instanceof final NBTSerializableValue nbtsv)
                    {
                        data = nbtsv.getCompoundTag();
                    }
                    Map<Value, Value> state = map.getMap();
                    List<Value> mapargs = new ArrayList<>();
                    state.forEach((k, v) -> {
                        mapargs.add(k);
                        mapargs.add(v);
                    });
                    args = mapargs;
                }
                else
                {
                    if ((args.size() & 1) == 1 && NBTSerializableValue.fromValue(args.get(args.size() - 1)) instanceof final NBTSerializableValue nbtsv)
                    {
                        data = nbtsv.getCompoundTag();
                    }
                }
                class_2689<class_2248, class_2680> states = sourceBlockState.method_26204().method_9595();
                for (int i = 0; i < args.size() - 1; i += 2)
                {
                    String paramString = args.get(i).getString();
                    class_2769<?> property = states.method_11663(paramString);
                    if (property == null)
                    {
                        throw new InternalExpressionException("Property " + paramString + " doesn't apply to " + sourceLocator.block.getString());
                    }
                    String paramValue = args.get(i + 1).getString();
                    sourceBlockState = setProperty(property, paramString, paramValue, sourceBlockState);
                }
            }

            if (data == null)
            {
                data = sourceLocator.block.getData();
            }
            class_2487 finalData = data;

            if (sourceBlockState == targetBlockState && data == null)
            {
                return Value.FALSE;
            }
            class_2680 finalSourceBlockState = sourceBlockState;
            class_2338 targetPos = targetLocator.block.getPos();
            Boolean[] result = new Boolean[]{true};
            cc.server().method_19537(() ->
            {
                boolean success = world.method_8652(targetPos, finalSourceBlockState, class_2248.field_31028  | class_2248.field_55739 );
                if (finalData != null)
                {
                    class_2586 be = world.method_8321(targetPos);
                    if (be != null)
                    {
                        class_2487 destTag = finalData.method_10553();
                        destTag.method_10569("x", targetPos.method_10263());
                        destTag.method_10569("y", targetPos.method_10264());
                        destTag.method_10569("z", targetPos.method_10260());
                        try (final class_8942.class_11340 reporter = new class_8942.class_11340(be.method_71402(), CarpetScriptServer.LOG)) {
                            be.method_58690(class_11352.method_71417(reporter, world.method_30349(), destTag));
                        }
                        be.method_5431();
                        success = true;
                    }
                }
                result[0] = success;
            });
            return !result[0] ? Value.FALSE : new BlockValue(finalSourceBlockState, world, targetLocator.block.getPos());
        });

        expression.addContextFunction("destroy", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            class_5455 regs = cc.registryAccess();
            class_3218 world = cc.level();
            BlockArgument locator = BlockArgument.findIn(cc, lv, 0);
            class_2680 state = locator.block.getBlockState();
            if (state.method_26215())
            {
                return Value.FALSE;
            }
            class_2338 where = locator.block.getPos();
            class_2586 be = world.method_8321(where);
            long how = 0;
            class_1792 item = class_1802.field_8377;
            boolean playerBreak = false;
            if (lv.size() > locator.offset)
            {
                Value val = lv.get(locator.offset);
                if (val instanceof final NumericValue number)
                {
                    how = number.getLong();
                }
                else
                {
                    playerBreak = true;
                    String itemString = val.getString();
                    item = cc.registry(class_7924.field_41197).method_17966(InputValidator.identifierOf(itemString))
                            .orElseThrow(() -> new ThrowStatement(itemString, Throwables.UNKNOWN_ITEM));
                }
            }
            class_2487 tag = null;
            if (lv.size() > locator.offset + 1)
            {
                if (!playerBreak)
                {
                    throw new InternalExpressionException("tag is not necessary with 'destroy' with no item");
                }
                Value tagValue = lv.get(locator.offset + 1);
                if (!tagValue.isNull())
                {
                    tag = tagValue instanceof final NBTSerializableValue nbtsv
                            ? nbtsv.getCompoundTag()
                            : NBTSerializableValue.parseStringOrFail(tagValue.getString()).getCompoundTag();
                }
            }
            class_1799 tool;
            if (tag != null)
            {
                tool = class_1799.field_24671.parse(regs.method_57093(class_2509.field_11560), tag).getOrThrow(s -> new InternalExpressionException("Failed to parse item stack data: " + s));
            }
            else
            {
                tool = new class_1799(item, 1);
            }
            if (playerBreak && state.method_26214(world, where) < 0.0)
            {
                return Value.FALSE;
            }
            boolean removed = world.method_8650(where, false);
            if (!removed)
            {
                return Value.FALSE;
            }
            world.method_8444(null, 2001, where, class_2248.method_9507(state));

            final MutableBoolean toolBroke = new MutableBoolean(false);
            boolean dropLoot = true;
            if (playerBreak)
            {
                boolean isUsingEffectiveTool = !state.method_29291() || tool.method_7951(state);
                //postMine() durability from item classes
                float hardness = state.method_26214(world, where);
                int damageAmount = 0;
                if ((tool.method_31573(class_3489.field_42614) && hardness > 0.0) || item instanceof class_1820)
                {
                    damageAmount = 1;
                }
                else if (item instanceof class_1835 || tool.method_31573(class_3489.field_42611))
                {
                    damageAmount = 2;
                }
                final int finalDamageAmount = damageAmount;
                tool.method_7956(damageAmount, world, null, (i) ->  { if (finalDamageAmount > 0) toolBroke.setTrue(); } );
                if (!isUsingEffectiveTool)
                {
                    dropLoot = false;
                }
            }

            if (dropLoot)
            {
                if (how < 0 || (tag != null && class_1890.method_8225(world.method_30349().method_30530(class_7924.field_41265).method_46747(class_1893.field_9099), tool) > 0))
                {
                    class_2248.method_9577(world, where, new class_1799(state.method_26204()));
                }
                else
                {
                    if (how > 0)
                    {
                        tool.method_7978(world.method_30349().method_30530(class_7924.field_41265).method_46747(class_1893.field_9130), (int) how);
                    }
                    if (DUMMY_ENTITY == null)
                    {
                        DUMMY_ENTITY = new class_1540(class_1299.field_6089, null);
                    }
                    class_2248.method_9511(state, world, where, be, DUMMY_ENTITY, tool);
                }
            }
            if (!playerBreak) // no tool info - block brokwn
            {
                return Value.TRUE;
            }
            if (toolBroke.booleanValue())
            {
                return Value.NULL;
            }
            return new NBTSerializableValue(() -> class_1799.field_24671.encodeStart(regs.method_57093(class_2509.field_11560), tool).getOrThrow(s -> new InternalExpressionException("Failed to parse item stack data: " + s)));

        });

        expression.addContextFunction("harvest", -1, (c, t, lv) ->
        {
            if (lv.size() < 2)
            {
                throw new InternalExpressionException("'harvest' takes at least 2 parameters: entity and block, or position, to harvest");
            }
            CarpetContext cc = (CarpetContext) c;
            class_1937 world = cc.level();
            Value entityValue = lv.get(0);
            if (!(entityValue instanceof final EntityValue ev))
            {
                return Value.FALSE;
            }
            class_1297 e = ev.getEntity();
            if (!(e instanceof final class_3222 player))
            {
                return Value.FALSE;
            }
            BlockArgument locator = BlockArgument.findIn(cc, lv, 1);
            class_2338 where = locator.block.getPos();
            class_2680 state = locator.block.getBlockState();
            class_2248 block = state.method_26204();
            boolean success = false;
            if (!((block == class_2246.field_9987 || block == class_2246.field_10499) && player.field_13974.method_14267()))
            {
                success = player.field_13974.method_14266(where);
            }
            if (success)
            {
                world.method_8444(null, 2001, where, class_2248.method_9507(state));
            }
            return BooleanValue.of(success);
        });

        expression.addContextFunction("create_explosion", -1, (c, t, lv) ->
        {
            if (lv.isEmpty())
            {
                throw new InternalExpressionException("'create_explosion' requires at least a position to explode");
            }
            CarpetContext cc = (CarpetContext) c;
            float powah = 4.0f;
            class_1927.class_4179 mode = class_1927.class_4179.field_18687; // should probably read the gamerule for default behaviour
            boolean createFire = false;
            class_1297 source = null;
            class_1309 attacker = null;
            Vector3Argument location = Vector3Argument.findIn(lv, 0, false, true);
            class_243 pos = location.vec;
            if (lv.size() > location.offset)
            {
                powah = NumericValue.asNumber(lv.get(location.offset), "explosion power").getFloat();
                if (powah < 0)
                {
                    throw new InternalExpressionException("Explosion power cannot be negative");
                }
                if (lv.size() > location.offset + 1)
                {
                    String strval = lv.get(location.offset + 1).getString();
                    try
                    {
                        mode = class_1927.class_4179.valueOf(strval.toUpperCase(Locale.ROOT));
                    }
                    catch (IllegalArgumentException ile)
                    {
                        throw new InternalExpressionException("Illegal explosions block behaviour: " + strval);
                    }
                    if (lv.size() > location.offset + 2)
                    {
                        createFire = lv.get(location.offset + 2).getBoolean();
                        if (lv.size() > location.offset + 3)
                        {
                            Value enVal = lv.get(location.offset + 3);
                            if (!enVal.isNull())
                            {
                                if (enVal instanceof final EntityValue ev)
                                {
                                    source = ev.getEntity();
                                }
                                else
                                {
                                    throw new InternalExpressionException("Fourth parameter of the explosion has to be an entity, not " + enVal.getTypeString());
                                }
                            }
                            if (lv.size() > location.offset + 4)
                            {
                                enVal = lv.get(location.offset + 4);
                                if (!enVal.isNull())
                                {
                                    if (enVal instanceof final EntityValue ev)
                                    {
                                        class_1297 attackingEntity = ev.getEntity();
                                        if (attackingEntity instanceof final class_1309 le)
                                        {
                                            attacker = le;
                                        }
                                        else
                                        {
                                            throw new InternalExpressionException("Attacking entity needs to be a living thing, " +
                                                    ValueConversions.of(cc.registry(class_7924.field_41266).method_10221(attackingEntity.method_5864())).getString() + " ain't it.");
                                        }
                                    }
                                    else
                                    {
                                        throw new InternalExpressionException("Fifth parameter of the explosion has to be a living entity, not " + enVal.getTypeString());
                                    }
                                }
                            }
                        }
                    }
                }
            }
            class_1309 theAttacker = attacker;

            // copy of ServerWorld.createExplosion #TRACK#
            class_9892 explosion = new class_9892(cc.level(), source, null, null, pos, powah, createFire, mode)
            {
                @Override
                @Nullable
                public
                class_1309 method_8347()
                {
                    return theAttacker;
                }
            };
            explosion.method_61737();
            class_2394 explosionParticle = explosion.method_61739() ? class_2398.field_11236 : class_2398.field_11221;
            cc.level().method_18456().forEach(spe -> {
                if (spe.method_5707(pos) < 4096.0D)
                {
                    spe.field_13987.method_14364(new class_2664(pos, Optional.ofNullable(explosion.method_61738().get(spe)), explosionParticle, class_3417.field_15152));
                }
            });
            return Value.TRUE;
        });

        // TODO rename to use_item
        expression.addContextFunction("place_item", -1, (c, t, lv) ->
        {
            if (lv.size() < 2)
            {
                throw new InternalExpressionException("'place_item' takes at least 2 parameters: item and block, or position, to place onto");
            }
            CarpetContext cc = (CarpetContext) c;
            String itemString = lv.get(0).getString();
            Vector3Argument locator = Vector3Argument.findIn(lv, 1);
            class_1799 stackArg = NBTSerializableValue.parseItem(itemString, cc.registryAccess());
            class_2338 where = class_2338.method_49638(locator.vec);
            // Paintings throw an exception if their direction is vertical, therefore we change the default here
            String facing = lv.size() > locator.offset
                    ? lv.get(locator.offset).getString()
                    : stackArg.method_7909() != class_1802.field_8892 ? "up" : "north";
            boolean sneakPlace = false;
            if (lv.size() > locator.offset + 1)
            {
                sneakPlace = lv.get(locator.offset + 1).getBoolean();
            }

            BlockValue.PlacementContext ctx = BlockValue.PlacementContext.from(cc.level(), where, facing, sneakPlace, stackArg);

            if (!(stackArg.method_7909() instanceof final class_1747 blockItem))
            {
                class_1269 useResult = ctx.method_8041().method_7981(ctx);
                if (useResult == class_1269.field_21466 || useResult == class_1269.field_5812)
                {
                    return Value.TRUE;
                }
            }
            else
            { // not sure we need special case for block items, since useOnBlock can do that as well
                if (!ctx.method_7716())
                {
                    return Value.FALSE;
                }
                class_2680 placementState = blockItem.method_7711().method_9605(ctx);
                if (placementState != null)
                {
                    class_1937 level = ctx.method_8045();
                    if (placementState.method_26184(level, where))
                    {
                        level.method_8652(where, placementState, 2);
                        class_2498 blockSoundGroup = placementState.method_26231();
                        level.method_8396(null, where, blockSoundGroup.method_10598(), class_3419.field_15245, (blockSoundGroup.method_10597() + 1.0F) / 2.0F, blockSoundGroup.method_10599() * 0.8F);
                        return Value.TRUE;
                    }
                }
            }
            return Value.FALSE;
        });

        expression.addContextFunction("blocks_movement", -1, (c, t, lv) ->
                booleanStateTest(c, "blocks_movement", lv, (s, p) ->
                        !s.method_26171(class_10.field_50)));

        expression.addContextFunction("block_sound", -1, (c, t, lv) ->
                stateStringQuery(c, "block_sound", lv, (s, p) ->
                        Colors.soundName.get(s.method_26231())));

        expression.addContextFunction("material", -1, (c, t, lv) -> {
            c.host.issueDeprecation("material(...)"); // deprecated for block_state()
            return StringValue.of("unknown");
        });

        expression.addContextFunction("map_colour", -1, (c, t, lv) ->
                stateStringQuery(c, "map_colour", lv, (s, p) ->
                        Colors.mapColourName.get(s.method_26205(((CarpetContext) c).level(), p))));

        // Deprecated for block_state()
        expression.addContextFunction("property", -1, (c, t, lv) ->
        {
            c.host.issueDeprecation("property(...)");
            BlockArgument locator = BlockArgument.findIn((CarpetContext) c, lv, 0);
            class_2680 state = locator.block.getBlockState();
            if (lv.size() <= locator.offset)
            {
                throw new InternalExpressionException("'property' requires to specify a property to query");
            }
            String tag = lv.get(locator.offset).getString();
            class_2689<class_2248, class_2680> states = state.method_26204().method_9595();
            class_2769<?> property = states.method_11663(tag);
            return property == null ? Value.NULL : new StringValue(state.method_11654(property).toString().toLowerCase(Locale.ROOT));
        });

        // Deprecated for block_state()
        expression.addContextFunction("block_properties", -1, (c, t, lv) ->
        {
            c.host.issueDeprecation("block_properties(...)");
            BlockArgument locator = BlockArgument.findIn((CarpetContext) c, lv, 0);
            class_2680 state = locator.block.getBlockState();
            class_2689<class_2248, class_2680> states = state.method_26204().method_9595();
            return ListValue.wrap(states.method_11659().stream().map(
                    p -> new StringValue(p.method_11899()))
            );
        });

        // block_state(block)
        // block_state(block, property)
        expression.addContextFunction("block_state", -1, (c, t, lv) ->
        {
            BlockArgument locator = BlockArgument.findIn((CarpetContext) c, lv, 0, true);
            class_2680 state = locator.block.getBlockState();
            class_2689<class_2248, class_2680> states = state.method_26204().method_9595();
            if (locator.offset == lv.size())
            {
                Map<Value, Value> properties = new HashMap<>();
                for (class_2769<?> p : states.method_11659())
                {
                    properties.put(StringValue.of(p.method_11899()), ValueConversions.fromProperty(state, p));
                }
                return MapValue.wrap(properties);
            }
            String tag = lv.get(locator.offset).getString();
            class_2769<?> property = states.method_11663(tag);
            return property == null ? Value.NULL : ValueConversions.fromProperty(state, property);
        });

        expression.addContextFunction("block_list", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            class_2378<class_2248> blocks = cc.registry(class_7924.field_41254);
            if (lv.isEmpty())
            {
                return ListValue.wrap(blocks.method_42017().map(blockReference -> ValueConversions.of(blockReference.method_40237().method_29177())));
            }
            class_2960 tag = InputValidator.identifierOf(lv.get(0).getString());
            Optional<class_6885.class_6888<class_2248>> tagset = blocks.method_46733(class_6862.method_40092(class_7924.field_41254, tag));
            return tagset.isEmpty() ? Value.NULL : ListValue.wrap(tagset.get().method_40239().map(b -> ValueConversions.of(blocks.method_10221(b.comp_349()))));
        });

        expression.addContextFunction("block_tags", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            class_2378<class_2248> blocks = cc.registry(class_7924.field_41254);
            if (lv.isEmpty())
            {
                return ListValue.wrap(blocks.method_40272().map(ValueConversions::of));
            }
            BlockArgument blockLocator = BlockArgument.findIn(cc, lv, 0, true);
            if (blockLocator.offset == lv.size())
            {
                class_2248 target = blockLocator.block.getBlockState().method_26204();
                return ListValue.wrap(blocks.method_40272().filter(e -> e.method_40239().anyMatch(h -> (h.comp_349() == target))).map(ValueConversions::of));
            }
            String tag = lv.get(blockLocator.offset).getString();
            Optional<class_6885.class_6888<class_2248>> tagSet = blocks.method_46733(class_6862.method_40092(class_7924.field_41254, InputValidator.identifierOf(tag)));
            return tagSet.isEmpty() ? Value.NULL : BooleanValue.of(blockLocator.block.getBlockState().method_40143(tagSet.get()));
        });

        expression.addContextFunction("biome", -1, (c, t, lv) -> {
            CarpetContext cc = (CarpetContext) c;
            class_3218 world = cc.level();
            if (lv.isEmpty())
            {
                return ListValue.wrap(cc.registry(class_7924.field_41236).method_42017().map(biomeReference -> ValueConversions.of(biomeReference.method_40237().method_29177())));
            }

            class_1959 biome;
            class_1966 biomeSource = world.method_14178().method_12129().method_12098();
            if (lv.size() == 1
                    && lv.get(0) instanceof final MapValue map
                    && biomeSource instanceof final class_4766 mnbs
            )
            {
                Value temperature = map.get(new StringValue("temperature"));
                nullCheck(temperature, "temperature");

                Value humidity = map.get(new StringValue("humidity"));
                nullCheck(humidity, "humidity");

                Value continentalness = map.get(new StringValue("continentalness"));
                nullCheck(continentalness, "continentalness");

                Value erosion = map.get(new StringValue("erosion"));
                nullCheck(erosion, "erosion");

                Value depth = map.get(new StringValue("depth"));
                nullCheck(depth, "depth");

                Value weirdness = map.get(new StringValue("weirdness"));
                nullCheck(weirdness, "weirdness");

                class_6544.class_6553 point = new class_6544.class_6553(
                        class_6544.method_38665(numberGetOrThrow(temperature)),
                        class_6544.method_38665(numberGetOrThrow(humidity)),
                        class_6544.method_38665(numberGetOrThrow(continentalness)),
                        class_6544.method_38665(numberGetOrThrow(erosion)),
                        class_6544.method_38665(numberGetOrThrow(depth)),
                        class_6544.method_38665(numberGetOrThrow(weirdness))
                );
                biome = mnbs.method_38167(point).comp_349();
                class_2960 biomeId = cc.registry(class_7924.field_41236).method_10221(biome);
                return NBTSerializableValue.nameFromRegistryId(biomeId);
            }

            BlockArgument locator = BlockArgument.findIn(cc, lv, 0, false, false, true);

            if (locator.replacement != null)
            {
                biome = world.method_30349().method_30530(class_7924.field_41236).method_63535(InputValidator.identifierOf(locator.replacement));
                if (biome == null)
                {
                    throw new ThrowStatement(locator.replacement, Throwables.UNKNOWN_BIOME);
                }
            }
            else
            {
                biome = world.method_23753(locator.block.getPos()).comp_349();
            }
            // in locatebiome
            if (locator.offset == lv.size())
            {
                class_2960 biomeId = cc.registry(class_7924.field_41236).method_10221(biome);
                return NBTSerializableValue.nameFromRegistryId(biomeId);
            }
            String biomeFeature = lv.get(locator.offset).getString();
            BiFunction<class_3218, class_1959, Value> featureProvider = BiomeInfo.biomeFeatures.get(biomeFeature);
            if (featureProvider == null)
            {
                throw new InternalExpressionException("Unknown biome feature: " + biomeFeature);
            }
            return featureProvider.apply(world, biome);
        });

        expression.addContextFunction("set_biome", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            BlockArgument locator = BlockArgument.findIn(cc, lv, 0);
            if (lv.size() == locator.offset)
            {
                throw new InternalExpressionException("'set_biome' needs a biome name as an argument");
            }
            String biomeName = lv.get(locator.offset).getString();
            // from locatebiome command code
            class_6880<class_1959> biome = cc.registry(class_7924.field_41236).method_46746(class_5321.method_29179(class_7924.field_41236, InputValidator.identifierOf(biomeName)))
                    .orElseThrow(() -> new ThrowStatement(biomeName, Throwables.UNKNOWN_BIOME));
            boolean doImmediateUpdate = true;
            if (lv.size() > locator.offset + 1)
            {
                doImmediateUpdate = lv.get(locator.offset + 1).getBoolean();
            }
            class_3218 world = cc.level();
            class_2338 pos = locator.block.getPos();
            class_2791 chunk = world.method_22350(pos); // getting level chunk instead of protochunk with biomes
            int biomeX = class_5742.method_33100(pos.method_10263());
            int biomeY = class_5742.method_33100(pos.method_10264());
            int biomeZ = class_5742.method_33100(pos.method_10260());
            try
            {
                int i = class_5742.method_33100(chunk.method_31607());
                int j = i + class_5742.method_33100(chunk.method_31605()) - 1;
                int k = class_3532.method_15340(biomeY, i, j);
                int l = chunk.method_31602(class_5742.method_33101(k));
                // accessing outside of the interface - might be dangerous in the future.
                ((class_2841<class_6880<class_1959>>) chunk.method_38259(l).method_38294()).method_35321(biomeX & 3, k & 3, biomeZ & 3, biome);
            }
            catch (Throwable var8)
            {
                return Value.FALSE;
            }
            if (doImmediateUpdate)
            {
                WorldTools.forceChunkUpdate(pos, world);
            }
            chunk.method_65063();
            return Value.TRUE;
        });

        expression.addContextFunction("reload_chunk", -1, (c, t, lv) -> {
            CarpetContext cc = (CarpetContext) c;
            class_2338 pos = BlockArgument.findIn(cc, lv, 0).block.getPos();
            class_3218 world = cc.level();
            cc.server().method_19537(() -> WorldTools.forceChunkUpdate(pos, world));
            return Value.TRUE;
        });

        expression.addContextFunction("structure_references", -1, (c, t, lv) -> {
            CarpetContext cc = (CarpetContext) c;
            BlockArgument locator = BlockArgument.findIn(cc, lv, 0);
            class_3218 world = cc.level();
            class_2338 pos = locator.block.getPos();
            Map<class_3195, LongSet> references = world.method_22342(pos.method_10263() >> 4, pos.method_10260() >> 4, class_2806.field_16422).method_12179();
            class_2378<class_3195> reg = cc.registry(class_7924.field_41246);
            if (lv.size() == locator.offset)
            {
                return ListValue.wrap(references.entrySet().stream().
                        filter(e -> e.getValue() != null && !e.getValue().isEmpty()).
                        map(e -> NBTSerializableValue.nameFromRegistryId(reg.method_10221(e.getKey())))
                );
            }
            String simpleStructureName = lv.get(locator.offset).getString().toLowerCase(Locale.ROOT);
            class_3195 structureName = reg.method_63535(InputValidator.identifierOf(simpleStructureName));
            if (structureName == null)
            {
                return Value.NULL;
            }
            LongSet structureReferences = references.get(structureName);
            if (structureReferences == null || structureReferences.isEmpty())
            {
                return ListValue.of();
            }
            return ListValue.wrap(structureReferences.longStream().mapToObj(l -> ListValue.of(
                    new NumericValue(16L * class_1923.method_8325(l)),
                    Value.ZERO,
                    new NumericValue(16L * class_1923.method_8332(l)))));
        });

        expression.addContextFunction("structure_eligibility", -1, (c, t, lv) ->
        {// TODO rename structureName to class
            CarpetContext cc = (CarpetContext) c;
            BlockArgument locator = BlockArgument.findIn(cc, lv, 0);

            class_3218 world = cc.level();

            // well, because
            theBooYah(world);

            class_2338 pos = locator.block.getPos();
            List<class_3195> structure = new ArrayList<>();
            boolean needSize = false;
            boolean singleOutput = false;
            class_2378<class_3195> reg = cc.registry(class_7924.field_41246);
            if (lv.size() > locator.offset)
            {
                Value requested = lv.get(locator.offset);
                if (!requested.isNull())
                {
                    String reqString = requested.getString();
                    class_2960 id = InputValidator.identifierOf(reqString);
                    class_3195 requestedStructure = reg.method_63535(id);
                    if (requestedStructure != null)
                    {
                        singleOutput = true;
                        structure.add(requestedStructure);
                    }
                    else
                    {
                        class_7151<?> sss = cc.registry(class_7924.field_41231).method_63535(id);
                        reg.method_29722().stream().filter(e -> e.getValue().method_41618() == sss).forEach(e -> structure.add(e.getValue()));
                    }
                    if (structure.isEmpty())
                    {
                        throw new ThrowStatement(reqString, Throwables.UNKNOWN_STRUCTURE);
                    }

                }
                else
                {
                    structure.addAll(reg.method_29722().stream().map(Map.Entry::getValue).toList());
                }
                if (lv.size() > locator.offset + 1)
                {
                    needSize = lv.get(locator.offset + 1).getBoolean();
                }
            }
            else
            {
                structure.addAll(reg.method_29722().stream().map(Map.Entry::getValue).toList());
            }
            if (singleOutput)
            {
                class_3449 start = FeatureGenerator.shouldStructureStartAt(world, pos, structure.get(0), needSize);
                return start == null ? Value.NULL : !needSize ? Value.TRUE : ValueConversions.of(start, cc.registryAccess());
            }
            Map<Value, Value> ret = new HashMap<>();
            for (class_3195 str : structure)
            {
                class_3449 start;
                try
                {
                    start = FeatureGenerator.shouldStructureStartAt(world, pos, str, needSize);
                }
                catch (NullPointerException npe)
                {
                    CarpetScriptServer.LOG.error("Failed to detect structure: " + reg.method_10221(str));
                    start = null;
                }

                if (start == null)
                {
                    continue;
                }

                Value key = NBTSerializableValue.nameFromRegistryId(reg.method_10221(str));
                ret.put(key, (!needSize) ? Value.NULL : ValueConversions.of(start, cc.registryAccess()));
            }
            return MapValue.wrap(ret);
        });

        expression.addContextFunction("structures", -1, (c, t, lv) -> {
            CarpetContext cc = (CarpetContext) c;
            BlockArgument locator = BlockArgument.findIn(cc, lv, 0);

            class_3218 world = cc.level();
            class_2338 pos = locator.block.getPos();
            Map<class_3195, class_3449> structures = world.method_22342(pos.method_10263() >> 4, pos.method_10260() >> 4, class_2806.field_16423).method_12016();
            class_2378<class_3195> reg = cc.registry(class_7924.field_41246);
            if (lv.size() == locator.offset)
            {
                Map<Value, Value> structureList = new HashMap<>();
                for (Map.Entry<class_3195, class_3449> entry : structures.entrySet())
                {
                    class_3449 start = entry.getValue();
                    if (start == class_3449.field_16713)
                    {
                        continue;
                    }
                    class_3341 box = start.method_14969();
                    structureList.put(
                            NBTSerializableValue.nameFromRegistryId(reg.method_10221(entry.getKey())),
                            ValueConversions.of(box)
                    );
                }
                return MapValue.wrap(structureList);
            }
            String structureName = lv.get(locator.offset).getString().toLowerCase(Locale.ROOT);
            return ValueConversions.of(structures.get(reg.method_63535(InputValidator.identifierOf(structureName))), cc.registryAccess());
        });

        expression.addContextFunction("set_structure", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            BlockArgument locator = BlockArgument.findIn(cc, lv, 0);

            class_3218 world = cc.level();
            class_2338 pos = locator.block.getPos();

            if (lv.size() == locator.offset)
            {
                throw new InternalExpressionException("'set_structure requires at least position and a structure name");
            }
            String structureName = lv.get(locator.offset).getString().toLowerCase(Locale.ROOT);
            class_3195 configuredStructure = FeatureGenerator.resolveConfiguredStructure(structureName, world, pos);
            if (configuredStructure == null)
            {
                throw new ThrowStatement(structureName, Throwables.UNKNOWN_STRUCTURE);
            }
            // good 'ol pointer
            Value[] result = new Value[]{Value.NULL};
            // technically a world modification. Even if we could let it slide, we will still park it
            ((CarpetContext) c).server().method_19537(() ->
            {
                Map<class_3195, class_3449> structures = world.method_22350(pos).method_12016();
                if (lv.size() == locator.offset + 1)
                {
                    boolean res = FeatureGenerator.plopGrid(configuredStructure, ((CarpetContext) c).level(), locator.block.getPos());
                    result[0] = res ? Value.TRUE : Value.FALSE;
                    return;
                }
                Value newValue = lv.get(locator.offset + 1);
                if (newValue.isNull()) // remove structure
                {
                    if (!structures.containsKey(configuredStructure))
                    {
                        return;
                    }
                    class_3449 start = structures.get(configuredStructure);
                    class_1923 structureChunkPos = start.method_34000();
                    class_3341 box = start.method_14969();
                    for (int chx = box.method_35415() / 16; chx <= box.method_35418() / 16; chx++)  // minx maxx
                    {
                        for (int chz = box.method_35417() / 16; chz <= box.method_35420() / 16; chz++) //minZ maxZ
                        {
                            class_1923 chpos = new class_1923(chx, chz);
                            // getting a chunk will convert it to full, allowing to modify references
                            Map<class_3195, LongSet> references =
                                    world.method_22350(chpos.method_8323()).method_12179();
                            if (references.containsKey(configuredStructure) && references.get(configuredStructure) != null)
                            {
                                references.get(configuredStructure).remove(structureChunkPos.method_8324());
                            }
                        }
                    }
                    structures.remove(configuredStructure);
                    result[0] = Value.TRUE;
                }
            });
            return result[0]; // preventing from lazy evaluating of the result in case a future completes later
        });

        // todo maybe enable chunk blending?
        expression.addContextFunction("reset_chunk", -1, (c, t, lv) ->
        {
            return Value.NULL;
            /*
            CarpetContext cc = (CarpetContext) c;
            List<ChunkPos> requestedChunks = new ArrayList<>();
            if (lv.size() == 1)
            {
                //either one block or list of chunks
                Value first = lv.get(0);
                if (first instanceof final ListValue list)
                {
                    List<Value> listVal = list.getItems();
                    BlockArgument locator = BlockArgument.findIn(cc, listVal, 0);
                    requestedChunks.add(new ChunkPos(locator.block.getPos()));
                    while (listVal.size() > locator.offset)
                    {
                        locator = BlockArgument.findIn(cc, listVal, locator.offset);
                        requestedChunks.add(new ChunkPos(locator.block.getPos()));
                    }
                }
                else
                {
                    BlockArgument locator = BlockArgument.findIn(cc, Collections.singletonList(first), 0);
                    requestedChunks.add(new ChunkPos(locator.block.getPos()));
                }
            }
            else
            {
                BlockArgument locator = BlockArgument.findIn(cc, lv, 0);
                ChunkPos from = new ChunkPos(locator.block.getPos());
                if (lv.size() > locator.offset)
                {
                    locator = BlockArgument.findIn(cc, lv, locator.offset);
                    ChunkPos to = new ChunkPos(locator.block.getPos());
                    int xmax = Math.max(from.x, to.x);
                    int zmax = Math.max(from.z, to.z);
                    for (int x = Math.min(from.x, to.x); x <= xmax; x++)
                    {
                        for (int z = Math.min(from.z, to.z); z <= zmax; z++)
                        {
                            requestedChunks.add(new ChunkPos(x, z));
                        }
                    }
                }
                else
                {
                    requestedChunks.add(from);
                }
            }
            ServerLevel world = cc.level();
            Value[] result = new Value[]{Value.NULL};
            ((CarpetContext) c).server().executeBlocking(() ->
            {
                Map<String, Integer> report = Vanilla.ChunkMap_regenerateChunkRegion(world.getChunkSource().chunkMap, requestedChunks);
                result[0] = MapValue.wrap(report.entrySet().stream().collect(Collectors.toMap(
                        e -> new StringValue(e.getKey()),
                        e -> new NumericValue(e.getValue())
                )));
            });
            return result[0];

             */
        });

        expression.addContextFunction("inhabited_time", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            BlockArgument locator = BlockArgument.findIn(cc, lv, 0);
            class_2338 pos = locator.block.getPos();
            return new NumericValue(cc.level().method_22350(pos).method_12033());
        });

        expression.addContextFunction("spawn_potential", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            BlockArgument locator = BlockArgument.findIn(cc, lv, 0);
            class_2338 pos = locator.block.getPos();
            double requiredCharge = 1;
            if (lv.size() > locator.offset)
            {
                requiredCharge = NumericValue.asNumber(lv.get(locator.offset)).getDouble();
            }
            class_1948.class_5262 charger = cc.level().method_14178().method_27908();
            return charger == null ? Value.NULL : new NumericValue(Vanilla.SpawnState_getPotentialCalculator(charger).method_27832(pos, requiredCharge)
            );
        });

        expression.addContextFunction("add_chunk_ticket", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            BlockArgument locator = BlockArgument.findIn(cc, lv, 0);
            class_2338 pos = locator.block.getPos();
            if (lv.size() != locator.offset + 2)
            {
                throw new InternalExpressionException("'add_chunk_ticket' requires block position, ticket type and radius");
            }
            String type = lv.get(locator.offset).getString();
            class_3230 ticket = ticketTypes.get(type.toLowerCase(Locale.ROOT));
            if (ticket == null)
            {
                throw new InternalExpressionException("Unknown ticket type: " + type);
            }
            int radius = NumericValue.asNumber(lv.get(locator.offset + 1)).getInt();
            if (radius < 1 || radius > 32)
            {
                throw new InternalExpressionException("Ticket radius should be between 1 and 32 chunks");
            }
            // due to types we will wing it:
            class_1923 target = new class_1923(pos);
            if (ticket == class_3230.field_19280) // portal
            {
                cc.level().method_14178().method_66009(class_3230.field_19280, target, radius);
            }
            else if (ticket == class_3230.field_54211) // post teleport
            {
                cc.level().method_14178().method_66009(class_3230.field_54211, target, radius);
            }
            else
            {
                cc.level().method_14178().method_66009(class_3230.field_14032, target, radius);
            }
            return new NumericValue(ticket.comp_3474());
        });

        expression.addContextFunction("sample_noise", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            if (lv.isEmpty())
            {
                return ListValue.wrap(cc.registry(class_7924.field_41240).method_10235().stream().map(ValueConversions::of));
            }
            class_3218 level = cc.level();
            BlockArgument locator = BlockArgument.findIn(cc, lv, 0);
            class_2338 pos = locator.block.getPos();
            String[] densityFunctionQueries = lv.stream().skip(locator.offset).map(Value::getString).toArray(String[]::new);
            if (densityFunctionQueries.length == 0)
            {
                return ListValue.wrap(cc.registry(class_7924.field_41240).method_10235().stream().map(ValueConversions::of));
            }
            class_6953 router = level.method_14178().method_41248().method_42370();
            return densityFunctionQueries.length == 1
                    ? NumericValue.of(sampleNoise(router, level, densityFunctionQueries[0], pos))
                    : ListValue.wrap(Arrays.stream(densityFunctionQueries).map(s -> NumericValue.of(sampleNoise(router, level, s, pos))));
        });
    }

    public static double sampleNoise(class_6953 router, class_3218 level, String what, class_2338 pos)
    {
        class_6910 densityFunction = switch (what)
        {
            case "barrier_noise" -> router.comp_414();
            case "fluid_level_floodedness_noise" -> router.comp_415();
            case "fluid_level_spread_noise" -> router.comp_416();
            case "lava_noise" -> router.comp_417();
            case "temperature" -> router.comp_420();
            case "vegetation" -> router.comp_539();
            case "continents" -> router.comp_484();
            case "erosion" -> router.comp_423();
            case "depth" -> router.comp_424();
            case "ridges" -> router.comp_485();
            case "initial_density_without_jaggedness" -> router.comp_486();
            case "final_density" -> router.comp_487();
            case "vein_toggle" -> router.comp_428();
            case "vein_ridged" -> router.comp_429();
            case "vein_gap" -> router.comp_430();
            default -> stupidWorldgenNoiseCacheGetter.apply(Pair.of(level, what));
        };
        return densityFunction.method_40464(new class_6910.class_6914(pos.method_10263(), pos.method_10264(), pos.method_10260()));
    }

    // to be used with future seedable noise
    public static final Function<Pair<class_3218, String>, class_6910> stupidWorldgenNoiseCacheGetter = class_156.method_34866(pair -> {
        class_3218 level = pair.getKey();
        String densityFunctionQuery = pair.getValue();
        class_2794 generator = level.method_14178().method_12129();

        if (generator instanceof final class_3754 noiseBasedChunkGenerator)
        {
            class_2378<class_6910> densityFunctionRegistry = level.method_30349().method_30530(class_7924.field_41240);
            class_6953 router = noiseBasedChunkGenerator.method_41541().comp_349().comp_477();
            class_6910 densityFunction = switch (densityFunctionQuery)
                    {
                        case "barrier_noise" -> router.comp_414();
                        case "fluid_level_floodedness_noise" -> router.comp_415();
                        case "fluid_level_spread_noise" -> router.comp_416();
                        case "lava_noise" -> router.comp_417();
                        case "temperature" -> router.comp_420();
                        case "vegetation" -> router.comp_539();
                        case "continents" -> router.comp_484();
                        case "erosion" -> router.comp_423();
                        case "depth" -> router.comp_424();
                        case "ridges" -> router.comp_485();
                        case "initial_density_without_jaggedness" -> router.comp_486();
                        case "final_density" -> router.comp_487();
                        case "vein_toggle" -> router.comp_428();
                        case "vein_ridged" -> router.comp_429();
                        case "vein_gap" -> router.comp_430();
                        default -> {
                            class_6910 result = densityFunctionRegistry.method_63535(InputValidator.identifierOf(densityFunctionQuery));
                            if (result == null)
                            {
                                throw new InternalExpressionException("Density function '" + densityFunctionQuery + "' is not defined in the registies.");
                            }
                            yield result;
                        }
                    };

            class_7138 randomState = class_7138.method_41556(
                    noiseBasedChunkGenerator.method_41541().comp_349(),
                    level.method_30349().method_30530(class_7924.field_41244), level.method_8412()
            );
            class_6910.class_6915 visitor = Vanilla.RandomState_getVisitor(randomState);

            return densityFunction.method_40469(visitor);
        }
        return class_6916.method_40479();
    });
}
