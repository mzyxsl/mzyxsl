package carpet.script.value;

import net.minecraft.class_2520;
import net.minecraft.class_5455;

public abstract class FrameworkValue extends Value
{
    @Override
    public String getString()
    {
        throw new UnsupportedOperationException("Scarpet language component cannot be used");
    }

    @Override
    public boolean getBoolean()
    {
        throw new UnsupportedOperationException("Scarpet language component cannot be used");
    }

    @Override
    public Value clone()
    {
        throw new UnsupportedOperationException("Scarpet language component cannot be used");
    }

    @Override
    public int hashCode()
    {
        throw new UnsupportedOperationException("Scarpet language component cannot be used as map key");
    }

    @Override
    public class_2520 toTag(boolean force, class_5455 regs)
    {
        throw new UnsupportedOperationException("Scarpet language component cannot be serialized to the tag");
    }
}
