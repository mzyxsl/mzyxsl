package carpet.script;

import carpet.script.value.Value;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.server.MinecraftServer;

public class CarpetContext extends Context
{
    /**
     * @deprecated Use {@link #source()} or the new methods to access stuff in it instead
     */
    @Deprecated(forRemoval = true)
    public class_2168 s;
    private final class_2338 origin;

    public CarpetContext(CarpetScriptHost host, class_2168 source)
    {
        this(host, source, class_2338.field_10980);
    }

    public CarpetContext(ScriptHost host, class_2168 source, class_2338 origin)
    {
        super(host);
        s = source;
        this.origin = origin;
    }

    @Override
    public CarpetContext duplicate()
    {
        return new CarpetContext(this.host, this.s, this.origin);
    }

    @Override
    protected void initialize()
    {
        super.initialize();
        variables.put("_x", (c, t) -> Value.ZERO);
        variables.put("_y", (c, t) -> Value.ZERO);
        variables.put("_z", (c, t) -> Value.ZERO);
    }

    public MinecraftServer server()
    {
        return s.method_9211();
    }

    public class_3218 level()
    {
        return s.method_9225();
    }

    public class_5455 registryAccess()
    {
        return s.method_9225().method_30349();
    }

    public <T> class_2378<T> registry(class_5321<? extends class_2378<? extends T>> resourceKey)
    {
        return registryAccess().method_30530(resourceKey);
    }

    public class_2168 source()
    {
        return s;
    }

    public class_2338 origin()
    {
        return origin;
    }

    public void swapSource(class_2168 source)
    {
        s = source;
    }
}
