package carpet.script.utils;

//import carpet.fakes.MinecraftServerInterface;
import carpet.script.external.Vanilla;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2672;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_2861;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_9240;
import net.minecraft.server.MinecraftServer;
import javax.annotation.Nullable;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class WorldTools
{

    public static boolean canHasChunk(class_3218 world, class_1923 chpos, @Nullable Map<String, class_2861> regionCache, boolean deepcheck)
    {
        if (world.method_8402(chpos.field_9181, chpos.field_9180, class_2806.field_16423, false) != null)
        {
            return true;
        }
        String currentRegionName = "r." + chpos.method_17885() + "." + chpos.method_17886() + ".mca";
        if (regionCache != null && regionCache.containsKey(currentRegionName))
        {
            class_2861 region = regionCache.get(currentRegionName);
            if (region == null)
            {
                return false;
            }
            return region.method_12423(chpos);
        }
        Path regionsFolder = Vanilla.MinecraftServer_storageSource(world.method_8503()).method_27424(world.method_27983()).resolve("region");
        Path regionPath = regionsFolder.resolve(currentRegionName);
        if (!regionPath.toFile().exists())
        {
            if (regionCache != null)
            {
                regionCache.put(currentRegionName, null);
            }
            return false;
        }
        if (!deepcheck)
        {
            return true; // not using cache in this case.
        }
        try
        {
            class_9240 levelStorageInfo = new class_9240(Vanilla.MinecraftServer_storageSource(world.method_8503()).method_27005(), world.method_27983(), "chunk");
            class_2861 region = new class_2861(levelStorageInfo, regionPath, regionsFolder, true);
            if (regionCache != null)
            {
                regionCache.put(currentRegionName, region);
            }
            return region.method_12423(chpos);
        }
        catch (IOException ignored)
        {
        }
        return true;
    }
/*
    public static boolean createWorld(MinecraftServer server, String worldKey, Long seed)
    {
        ResourceLocation worldId = new ResourceLocation(worldKey);
        ServerLevel overWorld = server.overworld();

        Set<ResourceKey<Level>> worldKeys = server.levelKeys();
        for (ResourceKey<Level> worldRegistryKey : worldKeys)
        {
            if (worldRegistryKey.location().equals(worldId))
            {
                // world with this id already exists
                return false;
            }
        }
        ServerLevelData serverWorldProperties = server.getWorldData().overworldData();
        WorldGenSettings generatorOptions = server.getWorldData().worldGenSettings();
        boolean bl = generatorOptions.isDebug();
        long l = generatorOptions.seed();
        long m = BiomeManager.obfuscateSeed(l);
        List<CustomSpawner> list = List.of();
        Registry<LevelStem> simpleRegistry = generatorOptions.dimensions();
        LevelStem dimensionOptions = simpleRegistry.get(LevelStem.OVERWORLD);
        ChunkGenerator chunkGenerator2;
        Holder<DimensionType> dimensionType2;
        if (dimensionOptions == null) {
            dimensionType2 = server.registryAccess().registryOrThrow(Registry.DIMENSION_TYPE_REGISTRY).getOrCreateHolder(DimensionType.OVERWORLD_LOCATION);;
            chunkGenerator2 = WorldGenSettings.makeDefaultOverworld(server.registryAccess(), (new Random()).nextLong());
        } else {
            dimensionType2 = dimensionOptions.typeHolder();
            chunkGenerator2 = dimensionOptions.generator();
        }

        ResourceKey<Level> customWorld = ResourceKey.create(Registry.DIMENSION_REGISTRY, worldId);

        //chunkGenerator2 = GeneratorOptions.createOverworldGenerator(server.getRegistryManager().get(Registry.BIOME_KEY), server.getRegistryManager().get(Registry.NOISE_SETTINGS_WORLDGEN), (seed==null)?l:seed);

        // from world/gen/GeneratorOptions
        //chunkGenerator2 = new NoiseChunkGenerator(MultiNoiseBiomeSource.createVanillaSource(server.getRegistryManager().get(Registry.BIOME_KEY), seed), seed, () -> {
        //    return server.getRegistryManager().get(Registry.CHUNK_GENERATOR_SETTINGS_KEY).getOrThrow(ChunkGeneratorSettings.OVERWORLD);
        //});

        chunkGenerator2 = new NoiseBasedChunkGenerator(
                server.registryAccess().registryOrThrow(Registry.STRUCTURE_SET_REGISTRY),
                server.registryAccess().registryOrThrow(Registry.NOISE_REGISTRY),
                MultiNoiseBiomeSource.Preset.OVERWORLD.biomeSource(server.registryAccess().registryOrThrow(Registry.BIOME_REGISTRY)), seed,
            Holder.direct(server.registryAccess().registryOrThrow(Registry.NOISE_GENERATOR_SETTINGS_REGISTRY).getOrThrow(NoiseGeneratorSettings.OVERWORLD))
        );

        ServerLevel serverWorld = new ServerLevel(
                server,
                Util.backgroundExecutor(),
                ((MinecraftServerInterface) server).getCMSession(),
                new DerivedLevelData(server.getWorldData(), serverWorldProperties),
                customWorld,
                dimensionType2,
                NOOP_LISTENER,
                chunkGenerator2,
                bl,
                (seed==null)?l:seed,
                list,
                false);
        overWorld.getWorldBorder().addListener(new BorderChangeListener.DelegateBorderChangeListener(serverWorld.getWorldBorder()));
        ((MinecraftServerInterface) server).getCMWorlds().put(customWorld, serverWorld);
        return true;
    }*/

    public static void forceChunkUpdate(class_2338 pos, class_3218 world)
    {
        class_1923 chunkPos = new class_1923(pos);
        class_2818 worldChunk = world.method_14178().method_12126(chunkPos.field_9181, chunkPos.field_9180, false);
        if (worldChunk != null)
        {
            List<class_3222> players = world.method_14178().field_17254.method_17210(chunkPos, false);
            if (!players.isEmpty())
            {
                class_2672 packet = new class_2672(worldChunk, world.method_22336(), null, null); // false seems to update neighbours as well.
                players.forEach(p -> p.field_13987.method_14364(packet));
            }
        }
    }

/*
    private static class NoopWorldGenerationProgressListener implements ChunkProgressListener
    {
        @Override
        public void updateSpawnPos(final ChunkPos spawnPos)
        {
        }

        @Override
        public void onStatusChange(final ChunkPos pos, final ChunkStatus status)
        {
        }

        //@Environment(EnvType.CLIENT)
        @Override
        public void start()
        {
        }

        @Override
        public void stop()
        {
        }
    }

    public static final ChunkProgressListener NOOP_LISTENER = new NoopWorldGenerationProgressListener();

 */
}
