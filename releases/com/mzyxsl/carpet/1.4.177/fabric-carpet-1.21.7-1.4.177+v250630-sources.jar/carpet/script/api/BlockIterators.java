package carpet.script.api;

import carpet.script.CarpetContext;
import carpet.script.Context;
import carpet.script.Expression;
import carpet.script.Fluff;
import carpet.script.LazyValue;
import carpet.script.argument.BlockArgument;
import carpet.script.argument.Vector3Argument;
import carpet.script.exception.BreakStatement;
import carpet.script.exception.ContinueStatement;
import carpet.script.exception.InternalExpressionException;
import carpet.script.value.BlockValue;
import carpet.script.value.LazyListValue;
import carpet.script.value.ListValue;
import carpet.script.value.NumericValue;
import carpet.script.value.Value;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_3218;
import net.minecraft.class_3532;

import static java.lang.Math.abs;
import static java.lang.Math.max;
import static java.lang.Math.min;

public class BlockIterators
{
    public static void apply(Expression expression)
    {
        // lazy cause of lazy expression
        expression.addLazyFunction("scan", (c, t, llv) ->
        {
            if (llv.size() < 3)
            {
                throw new InternalExpressionException("'scan' needs many more arguments");
            }
            List<Value> lv = Fluff.AbstractFunction.unpackLazy(llv.subList(0, llv.size() - 1), c, Context.NONE);
            CarpetContext cc = (CarpetContext) c;
            BlockArgument centerLocator = BlockArgument.findIn(cc, lv, 0);
            Vector3Argument rangeLocator = Vector3Argument.findIn(lv, centerLocator.offset);
            class_2338 center = centerLocator.block.getPos();
            class_2382 range;

            if (rangeLocator.fromBlock)
            {
                range = new class_2382(
                        class_3532.method_15357(abs(rangeLocator.vec.field_1352 - center.method_10263())),
                        class_3532.method_15357(abs(rangeLocator.vec.field_1351 - center.method_10264())),
                        class_3532.method_15357(abs(rangeLocator.vec.field_1350 - center.method_10260()))
                );
            }
            else
            {
                range = new class_2382(
                        class_3532.method_15357(abs(rangeLocator.vec.field_1352)),
                        class_3532.method_15357(abs(rangeLocator.vec.field_1351)),
                        class_3532.method_15357(abs(rangeLocator.vec.field_1350))
                );
            }
            class_2382 upperRange = range;
            if (lv.size() > rangeLocator.offset + 1) // +1 cause we still need the expression
            {
                rangeLocator = Vector3Argument.findIn(lv, rangeLocator.offset);
                if (rangeLocator.fromBlock)
                {
                    upperRange = new class_2382(
                            class_3532.method_15357(abs(rangeLocator.vec.field_1352 - center.method_10263())),
                            class_3532.method_15357(abs(rangeLocator.vec.field_1351 - center.method_10264())),
                            class_3532.method_15357(abs(rangeLocator.vec.field_1350 - center.method_10260()))
                    );
                }
                else
                {
                    upperRange = new class_2382(
                            class_3532.method_15357(abs(rangeLocator.vec.field_1352)),
                            class_3532.method_15357(abs(rangeLocator.vec.field_1351)),
                            class_3532.method_15357(abs(rangeLocator.vec.field_1350)));
                }
            }
            if (llv.size() != rangeLocator.offset + 1)
            {
                throw new InternalExpressionException("'scan' takes two, or three block positions, and an expression: " + lv.size() + " " + rangeLocator.offset);
            }
            LazyValue expr = llv.get(rangeLocator.offset);

            int cx = center.method_10263();
            int cy = center.method_10264();
            int cz = center.method_10260();
            int xrange = range.method_10263();
            int yrange = range.method_10264();
            int zrange = range.method_10260();
            int xprange = upperRange.method_10263();
            int yprange = upperRange.method_10264();
            int zprange = upperRange.method_10260();

            //saving outer scope
            LazyValue xVal = c.getVariable("_x");
            LazyValue yVal = c.getVariable("_y");
            LazyValue zVal = c.getVariable("_z");
            LazyValue defaultVal = c.getVariable("_");
            int sCount = 0;
            outer:
            for (int y = cy - yrange; y <= cy + yprange; y++)
            {
                int yFinal = y;
                c.setVariable("_y", (ct, tt) -> new NumericValue(yFinal).bindTo("_y"));
                for (int x = cx - xrange; x <= cx + xprange; x++)
                {
                    int xFinal = x;
                    c.setVariable("_x", (ct, tt) -> new NumericValue(xFinal).bindTo("_x"));
                    for (int z = cz - zrange; z <= cz + zprange; z++)
                    {
                        int zFinal = z;

                        c.setVariable("_z", (ct, tt) -> new NumericValue(zFinal).bindTo("_z"));
                        Value blockValue = BlockValue.fromCoords(((CarpetContext) c), xFinal, yFinal, zFinal).bindTo("_");
                        c.setVariable("_", (ct, tt) -> blockValue);
                        Value result;
                        try
                        {
                            result = expr.evalValue(c, t);
                        }
                        catch (ContinueStatement notIgnored)
                        {
                            result = notIgnored.retval;
                        }
                        catch (BreakStatement notIgnored)
                        {
                            break outer;
                        }
                        if (t != Context.VOID && result.getBoolean())
                        {
                            sCount += 1;
                        }
                    }
                }
            }
            //restoring outer scope
            c.setVariable("_x", xVal);
            c.setVariable("_y", yVal);
            c.setVariable("_z", zVal);
            c.setVariable("_", defaultVal);
            int finalSCount = sCount;
            return (ct, tt) -> new NumericValue(finalSCount);
        });

        // must be lazy
        expression.addLazyFunction("volume", (c, t, llv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            if (llv.size() < 3)
            {
                throw new InternalExpressionException("'volume' needs many more arguments");
            }
            List<Value> lv = Fluff.AbstractFunction.unpackLazy(llv.subList(0, llv.size() - 1), c, Context.NONE);

            BlockArgument pos1Locator = BlockArgument.findIn(cc, lv, 0);
            BlockArgument pos2Locator = BlockArgument.findIn(cc, lv, pos1Locator.offset);
            class_2338 pos1 = pos1Locator.block.getPos();
            class_2338 pos2 = pos2Locator.block.getPos();

            int x1 = pos1.method_10263();
            int y1 = pos1.method_10264();
            int z1 = pos1.method_10260();
            int x2 = pos2.method_10263();
            int y2 = pos2.method_10264();
            int z2 = pos2.method_10260();
            int minx = min(x1, x2);
            int miny = min(y1, y2);
            int minz = min(z1, z2);
            int maxx = max(x1, x2);
            int maxy = max(y1, y2);
            int maxz = max(z1, z2);
            LazyValue expr = llv.get(pos2Locator.offset);

            //saving outer scope
            LazyValue xVal = c.getVariable("_x");
            LazyValue yVal = c.getVariable("_y");
            LazyValue zVal = c.getVariable("_z");
            LazyValue defaultVal = c.getVariable("_");
            int sCount = 0;
            outer:
            for (int y = miny; y <= maxy; y++)
            {
                int yFinal = y;
                c.setVariable("_y", (ct, tt) -> new NumericValue(yFinal).bindTo("_y"));
                for (int x = minx; x <= maxx; x++)
                {
                    int xFinal = x;
                    c.setVariable("_x", (ct, tt) -> new NumericValue(xFinal).bindTo("_x"));
                    for (int z = minz; z <= maxz; z++)
                    {
                        int zFinal = z;
                        c.setVariable("_z", (ct, tt) -> new NumericValue(zFinal).bindTo("_z"));
                        Value blockValue = BlockValue.fromCoords(((CarpetContext) c), xFinal, yFinal, zFinal).bindTo("_");
                        c.setVariable("_", (ct, tt) -> blockValue);
                        Value result;
                        try
                        {
                            result = expr.evalValue(c, t);
                        }
                        catch (ContinueStatement notIgnored)
                        {
                            result = notIgnored.retval;
                        }
                        catch (BreakStatement notIgnored)
                        {
                            break outer;
                        }
                        if (t != Context.VOID && result.getBoolean())
                        {
                            sCount += 1;
                        }
                    }
                }
            }
            //restoring outer scope
            c.setVariable("_x", xVal);
            c.setVariable("_y", yVal);
            c.setVariable("_z", zVal);
            c.setVariable("_", defaultVal);
            int finalSCount = sCount;
            return (ct, tt) -> new NumericValue(finalSCount);
        });

        expression.addContextFunction("neighbours", -1, (c, t, lv) ->
        {
            class_2338 center = BlockArgument.findIn((CarpetContext) c, lv, 0).block.getPos();
            class_3218 world = ((CarpetContext) c).level();

            List<Value> neighbours = new ArrayList<>();
            neighbours.add(new BlockValue(world, center.method_10084()));
            neighbours.add(new BlockValue(world, center.method_10074()));
            neighbours.add(new BlockValue(world, center.method_10095()));
            neighbours.add(new BlockValue(world, center.method_10072()));
            neighbours.add(new BlockValue(world, center.method_10078()));
            neighbours.add(new BlockValue(world, center.method_10067()));
            return ListValue.wrap(neighbours);
        });

        expression.addContextFunction("rect", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;
            int cx;
            int cy;
            int cz;
            int sminx;
            int sminy;
            int sminz;
            int smaxx;
            int smaxy;
            int smaxz;
            BlockArgument cposLocator = BlockArgument.findIn(cc, lv, 0);
            class_2338 cpos = cposLocator.block.getPos();
            cx = cpos.method_10263();
            cy = cpos.method_10264();
            cz = cpos.method_10260();
            if (lv.size() > cposLocator.offset)
            {
                Vector3Argument diffLocator = Vector3Argument.findIn(lv, cposLocator.offset);
                if (diffLocator.fromBlock)
                {
                    sminx = class_3532.method_15357(abs(diffLocator.vec.field_1352 - cx));
                    sminy = class_3532.method_15357(abs(diffLocator.vec.field_1351 - cx));
                    sminz = class_3532.method_15357(abs(diffLocator.vec.field_1350 - cx));
                }
                else
                {
                    sminx = class_3532.method_15357(abs(diffLocator.vec.field_1352));
                    sminy = class_3532.method_15357(abs(diffLocator.vec.field_1351));
                    sminz = class_3532.method_15357(abs(diffLocator.vec.field_1350));
                }
                if (lv.size() > diffLocator.offset)
                {
                    Vector3Argument posDiff = Vector3Argument.findIn(lv, diffLocator.offset);
                    if (posDiff.fromBlock)
                    {
                        smaxx = class_3532.method_15357(abs(posDiff.vec.field_1352 - cx));
                        smaxy = class_3532.method_15357(abs(posDiff.vec.field_1351 - cx));
                        smaxz = class_3532.method_15357(abs(posDiff.vec.field_1350 - cx));
                    }
                    else
                    {
                        smaxx = class_3532.method_15357(abs(posDiff.vec.field_1352));
                        smaxy = class_3532.method_15357(abs(posDiff.vec.field_1351));
                        smaxz = class_3532.method_15357(abs(posDiff.vec.field_1350));
                    }
                }
                else
                {
                    smaxx = sminx;
                    smaxy = sminy;
                    smaxz = sminz;
                }
            }
            else
            {
                sminx = 1;
                sminy = 1;
                sminz = 1;
                smaxx = 1;
                smaxy = 1;
                smaxz = 1;
            }

            return new LazyListValue()
            {
                final int minx = cx - sminx;
                final int miny = cy - sminy;
                final int minz = cz - sminz;
                final int maxx = cx + smaxx;
                final int maxy = cy + smaxy;
                final int maxz = cz + smaxz;

                int x;
                int y;
                int z;

                {
                    reset();
                }

                @Override
                public boolean hasNext()
                {
                    return y <= maxy;
                }

                @Override
                public Value next()
                {
                    Value r = BlockValue.fromCoords(cc, x, y, z);
                    //possibly reroll context
                    x++;
                    if (x > maxx)
                    {
                        x = minx;
                        z++;
                        if (z > maxz)
                        {
                            z = minz;
                            y++;
                            // hasNext should fail if we went over
                        }
                    }

                    return r;
                }

                @Override
                public void fatality()
                {
                    // possibly return original x, y, z
                    super.fatality();
                }

                @Override
                public void reset()
                {
                    x = minx;
                    y = miny;
                    z = minz;
                }

                @Override
                public String getString()
                {
                    return String.format(Locale.ROOT, "rect[(%d,%d,%d),..,(%d,%d,%d)]", minx, miny, minz, maxx, maxy, maxz);
                }
            };
        });

        expression.addContextFunction("diamond", -1, (c, t, lv) ->
        {
            CarpetContext cc = (CarpetContext) c;

            BlockArgument cposLocator = BlockArgument.findIn((CarpetContext) c, lv, 0);
            class_2338 cpos = cposLocator.block.getPos();

            int cx;
            int cy;
            int cz;
            int width;
            int height;
            try
            {
                cx = cpos.method_10263();
                cy = cpos.method_10264();
                cz = cpos.method_10260();

                if (lv.size() == cposLocator.offset)
                {
                    return ListValue.of(
                            BlockValue.fromCoords(cc, cx, cy - 1, cz),
                            BlockValue.fromCoords(cc, cx, cy, cz),
                            BlockValue.fromCoords(cc, cx - 1, cy, cz),
                            BlockValue.fromCoords(cc, cx, cy, cz - 1),
                            BlockValue.fromCoords(cc, cx + 1, cy, cz),
                            BlockValue.fromCoords(cc, cx, cy, cz + 1),
                            BlockValue.fromCoords(cc, cx, cy + 1, cz)
                    );
                }
                else if (lv.size() == 1 + cposLocator.offset)
                {
                    width = (int) ((NumericValue) lv.get(cposLocator.offset)).getLong();
                    height = 0;
                }
                else if (lv.size() == 2 + cposLocator.offset)
                {
                    width = (int) ((NumericValue) lv.get(cposLocator.offset)).getLong();
                    height = (int) ((NumericValue) lv.get(cposLocator.offset + 1)).getLong();
                }
                else
                {
                    throw new InternalExpressionException("Incorrect number of arguments for 'diamond'");
                }
            }
            catch (ClassCastException ignored)
            {
                throw new InternalExpressionException("Attempted to pass a non-number to 'diamond'");
            }
            if (height == 0)
            {
                return new LazyListValue()
                {
                    int curradius;
                    int curpos;

                    {
                        reset();
                    }

                    @Override
                    public boolean hasNext()
                    {
                        return curradius <= width;
                    }

                    @Override
                    public Value next()
                    {
                        if (curradius == 0)
                        {
                            curradius = 1;
                            return BlockValue.fromCoords(cc, cx, cy, cz);
                        }
                        // x = 3-|i-6|
                        // z = |( (i-3)%12-6|-3
                        Value block = BlockValue.fromCoords(cc, cx + (curradius - abs(curpos - 2 * curradius)), cy, cz - curradius + abs(abs(curpos - curradius) % (4 * curradius) - 2 * curradius));
                        curpos++;
                        if (curpos >= curradius * 4)
                        {
                            curradius++;
                            curpos = 0;
                        }
                        return block;

                    }

                    @Override
                    public void reset()
                    {
                        curradius = 0;
                        curpos = 0;
                    }

                    @Override
                    public String getString()
                    {
                        return String.format(Locale.ROOT, "diamond[(%d,%d,%d),%d,0]", cx, cy, cz, width);
                    }
                };
            }
            else
            {
                return new LazyListValue()
                {
                    int curradius;
                    int curpos;
                    int curheight;

                    {
                        reset();
                    }

                    @Override
                    public boolean hasNext()
                    {
                        return curheight <= height;
                    }

                    @Override
                    public Value next()
                    {
                        if (curheight == -height || curheight == height)
                        {
                            return BlockValue.fromCoords(cc, cx, cy + curheight++, cz);
                        }
                        if (curradius == 0)
                        {
                            curradius++;
                            return BlockValue.fromCoords(cc, cx, cy + curheight, cz);
                        }
                        // x = 3-|i-6|
                        // z = |( (i-3)%12-6|-3

                        Value block = BlockValue.fromCoords(cc, cx + (curradius - abs(curpos - 2 * curradius)), cy + curheight, cz - curradius + abs(abs(curpos - curradius) % (4 * curradius) - 2 * curradius));
                        curpos++;
                        if (curpos >= curradius * 4)
                        {
                            curradius++;
                            curpos = 0;
                            if (curradius > width - abs(width * curheight / height))
                            {
                                curheight++;
                                curradius = 0;
                            }
                        }
                        return block;
                    }

                    @Override
                    public void reset()
                    {
                        curradius = 0;
                        curpos = 0;
                        curheight = -height;
                    }

                    @Override
                    public String getString()
                    {
                        return String.format(Locale.ROOT, "diamond[(%d,%d,%d),%d,%d]", cx, cy, cz, width, height);
                    }
                };
            }
        });
    }
}
