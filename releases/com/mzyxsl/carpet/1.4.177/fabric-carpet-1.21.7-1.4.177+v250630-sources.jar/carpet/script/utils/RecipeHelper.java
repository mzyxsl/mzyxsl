package carpet.script.utils;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10295;
import net.minecraft.class_10352;
import net.minecraft.class_10363;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_5321;
import net.minecraft.class_7923;

public class RecipeHelper
{
    public static List<class_1860<?>> getRecipesForOutput(class_1863 recipeManager, class_3956<?> type, class_2960 id, class_1937 level)
    {
        List<class_1860<?>> results = new ArrayList<>();


        class_10352 context = class_10363.method_65008(level);
        recipeManager.method_8126().forEach(r -> {
            if (r.comp_1933().method_17716() == type)
            {
                for (class_10295 recipeDisplay : r.comp_1933().method_64664())
                {
                    recipeDisplay.comp_3258().method_64738(context).forEach(stack -> {
                        if (class_7923.field_41178.method_47983(stack.method_7909()).method_40230().map(class_5321::method_29177).orElseThrow(IllegalStateException::new).equals(id))
                        {
                            results.add(r.comp_1933());
                        }
                    });
                }
            }
        });
        return results;
    }

    public static List<class_1860<?>> getRecipesForOutput(class_1863 recipeManager, class_2960 id, class_1937 level)
    {
        List<class_1860<?>> results = new ArrayList<>();

        class_10352 context = class_10363.method_65008(level);
        recipeManager.method_8126().forEach(r -> {
            for (class_10295 recipeDisplay : r.comp_1933().method_64664())
            {
                recipeDisplay.comp_3258().method_64738(context).forEach(stack -> {
                    if (class_7923.field_41178.method_47983(stack.method_7909()).method_40230().map(class_5321::method_29177).orElseThrow(IllegalStateException::new).equals(id))
                    {
                        results.add(r.comp_1933());
                    }
                });
            }

        });
        return results;
    }
}
