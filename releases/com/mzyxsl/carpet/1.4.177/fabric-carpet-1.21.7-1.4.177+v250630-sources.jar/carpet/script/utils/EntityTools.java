package carpet.script.utils;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class EntityTools
{
    /**
     * Not a replacement for living entity jump() - this barely is to allow other entities that can't jump in vanilla to 'jump'
     */
    public static void genericJump(class_1297 e)
    {
        if (!e.method_24828() && !e.method_52535())
        {
            return;
        }
        float m = e.method_37908().method_8320(e.method_24515()).method_26204().method_23350();
        float g = e.method_37908().method_8320(class_2338.method_49637(e.method_23317(), e.method_5829().field_1322 - 0.5000001D, e.method_23321())).method_26204().method_23350();
        float jumpVelocityMultiplier = m == 1.0D ? g : m;
        float jumpStrength = (0.42F * jumpVelocityMultiplier);
        class_243 vec3d = e.method_18798();
        e.method_18800(vec3d.field_1352, jumpStrength, vec3d.field_1350);
        if (e.method_5624())
        {
            float u = e.method_36454() * 0.017453292F; // yaw
            e.method_18799(e.method_18798().method_1031((-class_3532.method_15374(g) * 0.2F), 0.0D, (class_3532.method_15362(u) * 0.2F)));
        }
        e.field_6007 = true;
    }
}
