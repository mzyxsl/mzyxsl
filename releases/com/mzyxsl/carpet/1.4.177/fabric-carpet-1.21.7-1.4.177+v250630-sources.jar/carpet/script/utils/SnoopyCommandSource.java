package carpet.script.utils;

import carpet.script.external.Vanilla;
import net.minecraft.class_1297;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2183;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2874;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_7448;
import net.minecraft.class_7620;
import net.minecraft.class_8935;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.OptionalLong;
import java.util.function.BinaryOperator;
import java.util.function.Supplier;

public class SnoopyCommandSource extends class_2168
{
    private final class_2165 output;
    private final class_243 position;
    private final class_3218 world;
    private final int level;
    private final String simpleName;
    private final class_2561 name;
    private final MinecraftServer server;
    // skipping silent since snooper is never silent
    private final class_1297 entity;
    private final class_8935 resultConsumer;
    private final class_2183.class_2184 entityAnchor;
    private final class_241 rotation;
    // good stuff
    private final class_2561[] error;
    private final List<class_2561> chatOutput;
    private final class_7448 signingContext;

    private final class_7620 taskChainer;

    public SnoopyCommandSource(class_2168 original, class_2561[] error, List<class_2561> chatOutput, OptionalLong[] returnValue)
    {
        super(class_2165.field_17395, original.method_9222(), original.method_9210(), original.method_9225(), Vanilla.MinecraftServer_getRunPermissionLevel(original.method_9211()),
                original.method_9214(), original.method_9223(), original.method_9211(), original.method_9228(), false,
                (b, i) -> returnValue[0] = OptionalLong.of(i), class_2183.class_2184.field_9853, class_7448.field_39901, class_7620.immediate(original.method_9211()));
        this.output = class_2165.field_17395;
        this.position = original.method_9222();
        this.world = original.method_9225();
        this.level = Vanilla.MinecraftServer_getRunPermissionLevel(original.method_9211());
        this.simpleName = original.method_9214();
        this.name = original.method_9223();
        this.server = original.method_9211();
        this.entity = original.method_9228();
        this.resultConsumer = (b, i) -> returnValue[0] = OptionalLong.of(i);
        this.entityAnchor = original.method_9219();
        this.rotation = original.method_9210();
        this.error = error;
        this.chatOutput = chatOutput;
        this.signingContext = original.method_43738();
        this.taskChainer = class_7620.immediate(original.method_9211());
    }

    public SnoopyCommandSource(class_3222 player, class_2561[] error, List<class_2561> output, int [] result)
    {
        super(player.method_64401(), player.method_19538(), player.method_5802(),
                player.method_51469() instanceof final class_3218 serverLevel ? serverLevel : null,
                player.method_5682().method_3835(player.method_7334()), player.method_5477().getString(), player.method_5476(),
                player.method_51469().method_8503(), player);
        this.output = player.method_64401();
        this.position = player.method_19538();
        this.world = player.method_51469() instanceof final class_3218 serverLevel ? serverLevel : null;
        this.level = player.method_5682().method_3835(player.method_7334());
        this.simpleName = player.method_5477().getString();
        this.name = player.method_5476();
        this.server = player.method_51469().method_8503();
        this.entity = player;
        this.resultConsumer = (b, i) -> result[0] = i;
        this.entityAnchor = class_2183.class_2184.field_9853;
        this.rotation = player.method_5802(); // not a client call really
        this.error = error;
        this.chatOutput = output;
        this.signingContext = class_7448.field_39901;
        this.taskChainer = class_7620.immediate(player.method_5682());
    }

    private SnoopyCommandSource(class_2165 output, class_243 pos, class_241 rot, class_3218 world, int level, String simpleName, class_2561 name, MinecraftServer server, @Nullable class_1297 entity, class_8935 consumer, class_2183.class_2184 entityAnchor, class_7448 context, class_7620 chainer,
                                class_2561[] error, List<class_2561> chatOutput
    )
    {
        super(output, pos, rot, world, level,
                simpleName, name, server, entity, false,
                consumer, entityAnchor, context, chainer);
        this.output = output;
        this.position = pos;
        this.rotation = rot;
        this.world = world;
        this.level = level;
        this.simpleName = simpleName;
        this.name = name;
        this.server = server;
        this.entity = entity;
        this.resultConsumer = consumer;
        this.entityAnchor = entityAnchor;
        this.error = error;
        this.chatOutput = chatOutput;
        this.signingContext = context;
        this.taskChainer = chainer;
    }

    @Override
    public class_2168 method_9232(class_1297 entity)
    {
        return new SnoopyCommandSource(output, position, rotation, world, level, entity.method_5477().getString(), entity.method_5476(), server, entity, resultConsumer, entityAnchor, signingContext, taskChainer, error, chatOutput);
    }

    @Override
    public class_2168 method_9208(class_243 position)
    {
        return new SnoopyCommandSource(output, position, rotation, world, level, simpleName, name, server, entity, resultConsumer, entityAnchor, signingContext, taskChainer, error, chatOutput);
    }

    @Override
    public class_2168 method_9216(class_241 rotation)
    {
        return new SnoopyCommandSource(output, position, rotation, world, level, simpleName, name, server, entity, resultConsumer, entityAnchor, signingContext, taskChainer, error, chatOutput);
    }

    @Override
    public class_2168 method_54307(class_8935 consumer)
    {
        return new SnoopyCommandSource(output, position, rotation, world, level, simpleName, name, server, entity, consumer, entityAnchor, signingContext, taskChainer, error, chatOutput);
    }

    @Override
    public class_2168 method_9209(class_8935 consumer, BinaryOperator<class_8935> binaryOperator)
    {
        class_8935 resultConsumer = binaryOperator.apply(this.resultConsumer, consumer);
        return this.method_54307(resultConsumer);
    }

    //@Override // only used in fuctions and we really don't care to track these actually, besides the basic output
    // also other overrides target ONLY execute command, which withSilent doesn't care bout.
    //public ServerCommandSource withSilent() { return this; }

    @Override
    public class_2168 method_9206(int level)
    {
        return this;
    }

    @Override
    public class_2168 method_9230(int level)
    {
        return this;
    }

    @Override
    public class_2168 method_9218(class_2183.class_2184 anchor)
    {
        return new SnoopyCommandSource(output, position, rotation, world, level, simpleName, name, server, entity, resultConsumer, anchor, signingContext, taskChainer, error, chatOutput);
    }

    @Override
    public class_2168 method_43735(class_7448 commandSigningContext, class_7620 taskChainer)
    {
        return new SnoopyCommandSource(output, position, rotation, world, level, simpleName, name, server, entity, resultConsumer, entityAnchor, commandSigningContext, taskChainer, error, chatOutput);
    }

    @Override
    public class_2168 method_9227(class_3218 world)
    {
        double d = class_2874.method_31109(this.world.method_8597(), world.method_8597());
        class_243 position = new class_243(this.position.field_1352 * d, this.position.field_1351, this.position.field_1350 * d);
        return new SnoopyCommandSource(output, position, rotation, world, level, simpleName, name, server, entity, resultConsumer, entityAnchor, signingContext, taskChainer, error, chatOutput);
    }

    @Override
    public class_2168 method_9221(class_243 position)
    {
        class_243 vec3d = this.entityAnchor.method_9299(this);
        double d = position.field_1352 - vec3d.field_1352;
        double e = position.field_1351 - vec3d.field_1351;
        double f = position.field_1350 - vec3d.field_1350;
        double g = Math.sqrt(d * d + f * f);
        float h = class_3532.method_15393((float) (-(class_3532.method_15349(e, g) * 57.2957763671875D)));
        float i = class_3532.method_15393((float) (class_3532.method_15349(f, d) * 57.2957763671875D) - 90.0F);
        return this.method_9216(new class_241(h, i));
    }

    @Override
    public void method_9213(class_2561 message)
    {
        error[0] = message;
    }

    @Override
    public void method_9226(Supplier<class_2561> message, boolean broadcastToOps)
    {
        chatOutput.add(message.get());
    }
}
