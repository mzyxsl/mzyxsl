package carpet.script.utils;

import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class Tracer
{
    public static class_239 rayTrace(class_1297 source, float partialTicks, double reach, boolean fluids)
    {
        class_3965 blockHit = rayTraceBlocks(source, partialTicks, reach, fluids);
        double maxSqDist = reach * reach;
        if (blockHit != null)
        {
            maxSqDist = blockHit.method_17784().method_1025(source.method_5836(partialTicks));
        }
        class_3966 entityHit = rayTraceEntities(source, partialTicks, reach, maxSqDist);
        return entityHit == null ? blockHit : entityHit;
    }

    public static class_3965 rayTraceBlocks(class_1297 source, float partialTicks, double reach, boolean fluids)
    {
        class_243 pos = source.method_5836(partialTicks);
        class_243 rotation = source.method_5828(partialTicks);
        class_243 reachEnd = pos.method_1031(rotation.field_1352 * reach, rotation.field_1351 * reach, rotation.field_1350 * reach);
        return source.method_37908().method_17742(new class_3959(pos, reachEnd, class_3959.class_3960.field_17559, fluids ?
                class_3959.class_242.field_1347 : class_3959.class_242.field_1348, source));
    }

    public static class_3966 rayTraceEntities(class_1297 source, float partialTicks, double reach, double maxSqDist)
    {
        class_243 pos = source.method_5836(partialTicks);
        class_243 reachVec = source.method_5828(partialTicks).method_1021(reach);
        class_238 box = source.method_5829().method_18804(reachVec).method_1014(1);
        return rayTraceEntities(source, pos, pos.method_1019(reachVec), box, e -> !e.method_7325() && e.method_5863(), maxSqDist);
    }

    public static class_3966 rayTraceEntities(class_1297 source, class_243 start, class_243 end, class_238 box, Predicate<class_1297> predicate, double maxSqDistance)
    {
        class_1937 world = source.method_37908();
        double targetDistance = maxSqDistance;
        class_1297 target = null;
        class_243 targetHitPos = null;
        for (class_1297 current : world.method_8333(source, box, predicate))
        {
            class_238 currentBox = current.method_5829().method_1014(current.method_5871());
            Optional<class_243> currentHit = currentBox.method_992(start, end);
            if (currentBox.method_1006(start))
            {
                if (targetDistance >= 0)
                {
                    target = current;
                    targetHitPos = currentHit.orElse(start);
                    targetDistance = 0;
                }
            }
            else if (currentHit.isPresent())
            {
                class_243 currentHitPos = currentHit.get();
                double currentDistance = start.method_1025(currentHitPos);
                if (currentDistance < targetDistance || targetDistance == 0)
                {
                    if (current.method_5668() == source.method_5668())
                    {
                        if (targetDistance == 0)
                        {
                            target = current;
                            targetHitPos = currentHitPos;
                        }
                    }
                    else
                    {
                        target = current;
                        targetHitPos = currentHitPos;
                        targetDistance = currentDistance;
                    }
                }
            }
        }
        return target == null ? null : new class_3966(target, targetHitPos);
    }
}
