package carpet.script.utils;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import javax.annotation.Nullable;
import net.minecraft.class_2223;
import net.minecraft.class_2394;
import net.minecraft.class_5455;
import java.util.HashMap;
import java.util.Map;

public class ParticleParser
{
    private static final Map<String, class_2394> particleCache = new HashMap<>(); // we reset this on reloads, but probably need something better

    private static class_2394 parseParticle(String name, class_5455 lookup)
    {
        try
        {
            return class_2223.method_9418(new StringReader(name), lookup);
        }
        catch (CommandSyntaxException e)
        {
            throw new IllegalArgumentException("No such particle: " + name);
        }
    }

    @Nullable
    public static class_2394 getEffect(@Nullable String name, class_5455 lookup)
    {
        if (name == null)
        {
            return null;
        }
        return particleCache.computeIfAbsent(name, particle -> parseParticle(particle, lookup));
    }

    public static void resetCache()
    {
        particleCache.clear();
    }
}
