package carpet.script.utils;

import carpet.script.CarpetScriptServer;
import carpet.script.external.Carpet;
import carpet.script.utils.shapes.ShapeDirection;

import com.mojang.blaze3d.systems.RenderSystem;
//import com.mojang.blaze3d.vertex.VertexBuffer;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.function.BiFunction;
import net.minecraft.class_11352;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2397;
import net.minecraft.class_243;
import net.minecraft.class_2464;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_4696;
import net.minecraft.class_5321;
import net.minecraft.class_638;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_827;
import net.minecraft.class_8942;
import net.minecraft.class_9799;
import net.minecraft.class_9801;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;

public class ShapesRenderer
{
    private final Map<class_5321<class_1937>, Long2ObjectOpenHashMap<RenderedShape<? extends ShapeDispatcher.ExpiringShape>>> shapes;
    private final Map<class_5321<class_1937>, Long2ObjectOpenHashMap<RenderedShape<? extends ShapeDispatcher.ExpiringShape>>> labels;
    private final class_310 client;

    private final Map<String, BiFunction<class_310, ShapeDispatcher.ExpiringShape, RenderedShape<? extends ShapeDispatcher.ExpiringShape>>> renderedShapes
            = new HashMap<>()
    {{
        put("line", RenderedLine::new);
        put("box", RenderedBox::new);
        put("sphere", RenderedSphere::new);
        put("cylinder", RenderedCylinder::new);
        put("label", RenderedText::new);
        put("polygon", RenderedPolyface::new);
        put("block", (c, s) -> new RenderedSprite(c, s, false));
        put("item", (c, s) -> new RenderedSprite(c, s, true));
    }};

    public static void rotatePoseStackByShapeDirection(class_4587 poseStack, ShapeDirection shapeDirection, class_4184 camera, class_243 objectPos)
    {
        switch (shapeDirection)
        {
            case NORTH -> {}
            case SOUTH -> poseStack.method_22907(class_7833.field_40716.rotationDegrees(180));
            case EAST -> poseStack.method_22907(class_7833.field_40716.rotationDegrees(270));
            case WEST -> poseStack.method_22907(class_7833.field_40716.rotationDegrees(90));
            case UP -> poseStack.method_22907(class_7833.field_40714.rotationDegrees(90));
            case DOWN -> poseStack.method_22907(class_7833.field_40714.rotationDegrees(-90));
            case CAMERA -> poseStack.method_22907(camera.method_23767());
            case PLAYER -> {
                class_243 vector = objectPos.method_1020(camera.method_19326());
                double x = vector.field_1352;
                double y = vector.field_1351;
                double z = vector.field_1350;
                double d = Math.sqrt(x * x + z * z);
                float rotX = (float) (Math.atan2(x, z));
                float rotY = (float) (Math.atan2(y, d));

                // that should work somehow but it doesn't for some reason
                //matrices.mulPose(new Quaternion( -rotY, rotX, 0, false));

                poseStack.method_22907(class_7833.field_40716.rotation(rotX));
                poseStack.method_22907(class_7833.field_40714.rotation(-rotY));
            }
        }
    }

    public ShapesRenderer(class_310 minecraftClient)
    {
        this.client = minecraftClient;
        shapes = new HashMap<>();
        labels = new HashMap<>();
    }

    public void render(Matrix4f modelViewMatrix, class_4184 camera, float partialTick)
    {
        Runnable token = Carpet.startProfilerSection("Scarpet client");
        // posestack is not needed anymore - left as TODO to cleanup later
        class_4587 matrices = new class_4587();

        //Camera camera = this.client.gameRenderer.getCamera();
        class_638 iWorld = this.client.field_1687;
        class_5321<class_1937> dimensionType = iWorld.method_27983();
        if ((shapes.get(dimensionType) == null || shapes.get(dimensionType).isEmpty()) &&
                (labels.get(dimensionType) == null || labels.get(dimensionType).isEmpty()))
        {
            return;
        }
        long currentTime = client.field_1687.method_8510();
        ////RenderSystem.enableDepthTest();
        //RenderSystem.setShader(CoreShaders.POSITION_COLOR);
        ////RenderSystem.depthFunc(515);
        ////RenderSystem.enableBlend();
        ////RenderSystem.defaultBlendFunc();
        // too bright
        //RenderSystem.blendFuncSeparate(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE, GlStateManager.SrcFactor.ONE, GlStateManager.DstFactor.ZERO);
        // meh
        //RenderSystem.blendFuncSeparate(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SrcFactor.ONE, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);

        ////RenderSystem.disableCull();
        ////RenderSystem.depthMask(false);
        //RenderSystem.polygonOffset(-3f, -3f);
        //RenderSystem.enablePolygonOffset();

        class_289 tesselator = class_289.method_1348();

        // render
        double cameraX = camera.method_19326().field_1352;
        double cameraY = camera.method_19326().field_1351;
        double cameraZ = camera.method_19326().field_1350;
        boolean entityBoxes = client.method_1561().method_3958();

        if (!shapes.isEmpty())
        {
            shapes.get(dimensionType).long2ObjectEntrySet().removeIf(
                    entry -> entry.getValue().isExpired(currentTime)
            );
            Matrix4fStack matrixStack = RenderSystem.getModelViewStack();
            matrixStack.pushMatrix();
            matrixStack.mul(matrices.method_23760().method_23761());

            // lines
            RenderSystem.lineWidth(0.5F);
            shapes.get(dimensionType).values().forEach(s -> {
                if ((!s.shape.debug || entityBoxes) && s.shouldRender(dimensionType))
                {
                    s.renderLines(matrices, tesselator, cameraX, cameraY, cameraZ, partialTick);
                }
            });
            // faces
            RenderSystem.lineWidth(0.1F);
            shapes.get(dimensionType).values().forEach(s -> {
                if ((!s.shape.debug || entityBoxes) && s.shouldRender(dimensionType))
                {
                    s.renderFaces(tesselator, cameraX, cameraY, cameraZ, partialTick);
                }
            });
            RenderSystem.lineWidth(1.0F);
            matrixStack.popMatrix();

        }
        if (!labels.isEmpty())
        {
            labels.get(dimensionType).long2ObjectEntrySet().removeIf(
                    entry -> entry.getValue().isExpired(currentTime)
            );
            labels.get(dimensionType).values().forEach(s -> {
                if ((!s.shape.debug || entityBoxes) && s.shouldRender(dimensionType))
                {
                    s.renderLines(matrices, tesselator, cameraX, cameraY, cameraZ, partialTick);
                }
            });
        }
        ////RenderSystem.enableCull();
        ////RenderSystem.depthMask(true);
        ////RenderSystem.enableBlend();
        ////RenderSystem.defaultBlendFunc();
        token.run();
    }

    public void addShapes(class_2499 tag)
    {
        Runnable token = Carpet.startProfilerSection("Scarpet client");
        for (int i = 0, count = tag.size(); i < count; i++)
        {
            addShape(tag.method_10602(i).orElseThrow());
        }
        token.run();
    }

    public void addShape(class_2487 tag)
    {
        ShapeDispatcher.ExpiringShape shape = ShapeDispatcher.fromTag(tag, client.field_1687);
        if (shape == null)
        {
            return;
        }
        BiFunction<class_310, ShapeDispatcher.ExpiringShape, RenderedShape<? extends ShapeDispatcher.ExpiringShape>> shapeFactory;
        shapeFactory = renderedShapes.get(tag.method_10558("shape").orElseThrow());
        if (shapeFactory == null)
        {
            CarpetScriptServer.LOG.info("Unrecognized shape: " + tag.method_10558("shape"));
        }
        else
        {
            RenderedShape<?> rshape = shapeFactory.apply(client, shape);
            class_5321<class_1937> dim = shape.shapeDimension;
            long key = rshape.key();
            Map<class_5321<class_1937>, Long2ObjectOpenHashMap<RenderedShape<? extends ShapeDispatcher.ExpiringShape>>> container =
                    rshape.stageDeux() ? labels : shapes;
            RenderedShape<?> existing = container.computeIfAbsent(dim, d -> new Long2ObjectOpenHashMap<>()).get(key);
            if (existing != null)
            {   // promoting previous shape
                existing.promoteWith(rshape);
            }
            else
            {
                container.get(dim).put(key, rshape);
            }

        }
    }

    public void reset()
    {
        shapes.values().forEach(Long2ObjectOpenHashMap::clear);
        labels.values().forEach(Long2ObjectOpenHashMap::clear);
    }

    public void renewShapes()
    {
        Runnable token = Carpet.startProfilerSection("Scarpet client");
        shapes.values().forEach(el -> el.values().forEach(shape -> shape.expiryTick++));
        labels.values().forEach(el -> el.values().forEach(shape -> shape.expiryTick++));

        token.run();
    }

    public abstract static class RenderedShape<T extends ShapeDispatcher.ExpiringShape>
    {
        protected T shape;
        protected class_310 client;
        long expiryTick;
        double renderEpsilon;

        public abstract void renderLines(class_4587 matrices, class_289 tesselator, double cx, double cy, double cz, float partialTick);

        public void renderFaces(class_289 tesselator, double cx, double cy, double cz, float partialTick)
        {
        }

        protected RenderedShape(class_310 client, T shape)
        {
            this.shape = shape;
            this.client = client;
            expiryTick = client.field_1687.method_8510() + shape.getExpiry();
            renderEpsilon = (3 + ((double) key()) / Long.MAX_VALUE) / 1000;
        }

        public boolean isExpired(long currentTick)
        {
            return expiryTick < currentTick;
        }

        public long key()
        {
            return shape.key(client.field_1687.method_30349());
        }

        public boolean shouldRender(class_5321<class_1937> dim)
        {
            if (shape.followEntity <= 0)
            {
                return true;
            }
            if (client.field_1687 == null)
            {
                return false;
            }
            if (client.field_1687.method_27983() != dim)
            {
                return false;
            }
            return client.field_1687.method_8469(shape.followEntity) != null;
        }

        public boolean stageDeux()
        {
            return false;
        }

        public void promoteWith(RenderedShape<?> rshape)
        {
            expiryTick = rshape.expiryTick;
        }
    }

    public static class RenderedSprite extends RenderedShape<ShapeDispatcher.DisplayedSprite>
    {

        private final boolean isitem;
        private class_811 transformType = class_811.field_4315;

        private class_2338 blockPos;
        private class_2680 blockState;
        private class_2586 BlockEntity = null;

        protected RenderedSprite(class_310 client, ShapeDispatcher.ExpiringShape shape, boolean isitem)
        {
            super(client, (ShapeDispatcher.DisplayedSprite) shape);
            this.isitem = isitem;
            if (isitem)
            {
                this.transformType = class_811.valueOf(((ShapeDispatcher.DisplayedSprite) shape).itemTransformType.toUpperCase(Locale.ROOT));
            }
        }

        @Override
        public void renderLines(class_4587 matrices, class_289 tesselator, double cx, double cy,
                                double cz, float partialTick)
        {
            if (shape.a == 0.0)
            {
                return;
            }

            class_243 v1 = shape.relativiseRender(client.field_1687, shape.pos, partialTick);
            class_4184 camera1 = client.field_1773.method_19418();

            matrices.method_22903();
            if (!isitem)// blocks should use its center as the origin
            {
                matrices.method_22904(0.5, 0.5, 0.5);
            }

            matrices.method_22904(v1.field_1352 - cx, v1.field_1351 - cy, v1.field_1350 - cz);
            rotatePoseStackByShapeDirection(matrices, shape.facing, camera1, isitem ? v1 : v1.method_1031(0.5, 0.5, 0.5));
            if (shape.tilt != 0.0f)
            {
                matrices.method_22907(class_7833.field_40718.rotationDegrees(-shape.tilt));
            }
            if (shape.lean != 0.0f)
            {
                matrices.method_22907(class_7833.field_40714.rotationDegrees(-shape.lean));
            }
            if (shape.turn != 0.0f)
            {
                matrices.method_22907(class_7833.field_40716.rotationDegrees(shape.turn));
            }
            matrices.method_22905(shape.scaleX, shape.scaleY, shape.scaleZ);

            if (!isitem)
            {
                // blocks should use its center as the origin
                matrices.method_22904(-0.5, -0.5, -0.5);
            }
            else
            {
                // items seems to be flipped by default
                matrices.method_22907(class_7833.field_40716.rotationDegrees(180));
            }

            ////RenderSystem.depthMask(true);
            ////RenderSystem.enableCull();
            ////RenderSystem.enableDepthTest();

            blockPos = class_2338.method_49638(v1);
            int light = 0;
            if (client.field_1687 != null)
            {
                light = class_765.method_23687(
                        shape.blockLight < 0 ? client.field_1687.method_8314(class_1944.field_9282, blockPos) : shape.blockLight,
                        shape.skyLight < 0 ? client.field_1687.method_8314(class_1944.field_9284, blockPos) : shape.skyLight
                );
            }

            blockState = shape.blockState;

            class_4597.class_4598 immediate = client.method_22940().method_23000();
            if (!isitem)
            {
                // draw the block itself
                if (blockState.method_26217() == class_2464.field_11458)
                {

                    var bakedModel = client.method_1541().method_3349(blockState);
                    int color = client.method_1505().method_1697(blockState, client.field_1687, blockPos, 0);
                    //dont know why there is a 0. 
                    //see https://github.com/senseiwells/EssentialClient/blob/4db1f291936f502304791ee323f369c206b3021d/src/main/java/me/senseiwells/essentialclient/utils/render/RenderHelper.java#L464
                    float red = (color >> 16 & 0xFF) / 255.0F;
                    float green = (color >> 8 & 0xFF) / 255.0F;
                    float blue = (color & 0xFF) / 255.0F;
                    class_1921 type;
                    if (blockState.method_26204() instanceof class_2397 && !class_310.method_1517()) {
                        type = class_1921.method_23577();
                    } else {
                        type = class_4696.method_23683(blockState);
                    }
                    client.method_1541().method_3350().method_3367(matrices.method_23760(), immediate.getBuffer(type), bakedModel, red, green, blue, light, class_4608.field_21444);
                }

                // draw the block`s entity part
                if (BlockEntity == null)
                {
                    if (blockState.method_26204() instanceof class_2343 eb)
                    {
                        BlockEntity = eb.method_10123(blockPos, blockState);
                        if (BlockEntity != null)
                        {
                            BlockEntity.method_31662(client.field_1687);
                            if (shape.blockEntity != null)
                            {
                                try (final class_8942.class_11340 reporter = new class_8942.class_11340(BlockEntity.method_71402(), CarpetScriptServer.LOG)) {
                                    BlockEntity.method_58690(class_11352.method_71417(reporter, client.field_1687.method_30349(), shape.blockEntity));
                                }
                            }
                        }
                    }
                }
                if (BlockEntity != null)
                {
                        class_827<class_2586> blockEntityRenderer = client.method_31975().method_3550(BlockEntity);
                        if (blockEntityRenderer != null)
                        {
                            blockEntityRenderer.method_3569(BlockEntity, partialTick,
                                    matrices, immediate, light, class_4608.field_21444, camera1.method_19326());

                        }
                }
            }
            else
            {
                if (shape.item != null)
                {
                    // draw the item
                    client.method_1480().method_23178(shape.item, transformType, light,
                            class_4608.field_21444, matrices, immediate, client.field_1687, (int) shape.key(client.field_1687.method_30349()));
                }
            }
            matrices.method_22909();
            immediate.method_22993();
            ////RenderSystem.disableCull();
            ////RenderSystem.disableDepthTest();
            ////RenderSystem.depthMask(false);

        }

        @Override
        public boolean stageDeux()
        {
            return true;
        }
    }


    public static class RenderedText extends RenderedShape<ShapeDispatcher.DisplayedText>
    {

        protected RenderedText(class_310 client, ShapeDispatcher.ExpiringShape shape)
        {
            super(client, (ShapeDispatcher.DisplayedText) shape);
        }

        @Override
        public void renderLines(class_4587 matrices, class_289 tesselator, double cx, double cy, double cz, float partialTick)
        {
            if (shape.a == 0.0)
            {
                return;
            }
            class_243 v1 = shape.relativiseRender(client.field_1687, shape.pos, partialTick);
            class_4184 camera1 = client.field_1773.method_19418();
            class_327 textRenderer = client.field_1772;
            if (shape.doublesided)
            {
                //// RenderSystem.disableCull(); TODO culling
            }
            else
            {
                //// RenderSystem.enableCull();
            }
            matrices.method_22903();
            matrices.method_22904(v1.field_1352 - cx, v1.field_1351 - cy, v1.field_1350 - cz);

            rotatePoseStackByShapeDirection(matrices, shape.facing, camera1, v1);

            matrices.method_22905(shape.size * 0.0025f, -shape.size * 0.0025f, shape.size * 0.0025f);
            //RenderSystem.scalef(shape.size* 0.0025f, -shape.size*0.0025f, shape.size*0.0025f);
            if (shape.tilt != 0.0f)
            {
                matrices.method_22907(class_7833.field_40718.rotationDegrees(shape.tilt));
            }
            if (shape.lean != 0.0f)
            {
                matrices.method_22907(class_7833.field_40714.rotationDegrees(shape.lean));
            }
            if (shape.turn != 0.0f)
            {
                matrices.method_22907(class_7833.field_40716.rotationDegrees(shape.turn));
            }
            matrices.method_22904(-10 * shape.indent, -10 * shape.height - 9, (-10 * renderEpsilon) - 10 * shape.raise);
            //if (visibleThroughWalls) RenderSystem.disableDepthTest();
            matrices.method_22905(-1, 1, 1);
            //RenderSystem.applyModelViewMatrix(); // passed matrix directly to textRenderer.draw, not AffineTransformation.identity().getMatrix(),

            float text_x = 0;
            if (shape.align == 0)
            {
                text_x = (float) (-textRenderer.method_1727(shape.value.getString())) / 2.0F;
            }
            else if (shape.align == 1)
            {
                text_x = (float) (-textRenderer.method_1727(shape.value.getString()));
            }
            class_4597.class_4598 immediate = class_4597.method_22991(new class_9799(class_1921.field_32775));
            // text doesn't appear if backgroud is set
            ///script run draw_shape('label', 100, 'pos', [200, 100, 200], 'text', 'Hewwo World!', 'color', 0xffffffff, 'fill', 0x33333333)
            textRenderer.method_27522(shape.value, text_x, 0.0F, shape.textcolor, false, matrices.method_23760().method_23761(), immediate, class_327.class_6415.field_33994, shape.textbck, 15728880);
            immediate.method_22993();
            matrices.method_22909();
            ////RenderSystem.enableCull();
        }

        @Override
        public boolean stageDeux()
        {
            return true;
        }

        @Override
        public void promoteWith(RenderedShape<?> rshape)
        {
            super.promoteWith(rshape);
            try
            {
                this.shape.value = ((ShapeDispatcher.DisplayedText) rshape.shape).value;
            }
            catch (ClassCastException ignored)
            {
                CarpetScriptServer.LOG.error("shape " + rshape.shape.getClass() + " cannot cast to a Label");
            }
        }
    }

    public static class RenderedBox extends RenderedShape<ShapeDispatcher.Box>
    {

        private RenderedBox(class_310 client, ShapeDispatcher.ExpiringShape shape)
        {
            super(client, (ShapeDispatcher.Box) shape);
        }

        @Override
        public void renderLines(class_4587 matrices, class_289 tesselator, double cx, double cy, double cz, float partialTick)
        {
            if (shape.a == 0.0)
            {
                return;
            }
            class_243 v1 = shape.relativiseRender(client.field_1687, shape.from, partialTick);
            class_243 v2 = shape.relativiseRender(client.field_1687, shape.to, partialTick);
            drawBoxWireGLLines(tesselator,
                    (float) (v1.field_1352 - cx - renderEpsilon), (float) (v1.field_1351 - cy - renderEpsilon), (float) (v1.field_1350 - cz - renderEpsilon),
                    (float) (v2.field_1352 - cx + renderEpsilon), (float) (v2.field_1351 - cy + renderEpsilon), (float) (v2.field_1350 - cz + renderEpsilon),
                    v1.field_1352 != v2.field_1352, v1.field_1351 != v2.field_1351, v1.field_1350 != v2.field_1350,
                    shape.r, shape.g, shape.b, shape.a, shape.r, shape.g, shape.b
            );
        }

        @Override
        public void renderFaces(class_289 tesselator, double cx, double cy, double cz, float partialTick)
        {
            if (shape.fa == 0.0)
            {
                return;
            }
            class_243 v1 = shape.relativiseRender(client.field_1687, shape.from, partialTick);
            class_243 v2 = shape.relativiseRender(client.field_1687, shape.to, partialTick);
            // consider using built-ins
            //DebugRenderer.drawBox(new Box(v1.x, v1.y, v1.z, v2.x, v2.y, v2.z), 0.5f, 0.5f, 0.5f, 0.5f);//shape.r, shape.g, shape.b, shape.a);
            drawBoxFaces(tesselator,
                    (float) (v1.field_1352 - cx - renderEpsilon), (float) (v1.field_1351 - cy - renderEpsilon), (float) (v1.field_1350 - cz - renderEpsilon),
                    (float) (v2.field_1352 - cx + renderEpsilon), (float) (v2.field_1351 - cy + renderEpsilon), (float) (v2.field_1350 - cz + renderEpsilon),
                    v1.field_1352 != v2.field_1352, v1.field_1351 != v2.field_1351, v1.field_1350 != v2.field_1350,
                    shape.fr, shape.fg, shape.fb, shape.fa
            );
        }
    }

    public static class RenderedLine extends RenderedShape<ShapeDispatcher.Line>
    {
        public RenderedLine(class_310 client, ShapeDispatcher.ExpiringShape shape)
        {
            super(client, (ShapeDispatcher.Line) shape);
        }

        @Override
        public void renderLines(class_4587 matrices, class_289 tesselator, double cx, double cy, double cz, float partialTick)
        {
            class_243 v1 = shape.relativiseRender(client.field_1687, shape.from, partialTick);
            class_243 v2 = shape.relativiseRender(client.field_1687, shape.to, partialTick);
            drawLine(tesselator,
                    (float) (v1.field_1352 - cx - renderEpsilon), (float) (v1.field_1351 - cy - renderEpsilon), (float) (v1.field_1350 - cz - renderEpsilon),
                    (float) (v2.field_1352 - cx + renderEpsilon), (float) (v2.field_1351 - cy + renderEpsilon), (float) (v2.field_1350 - cz + renderEpsilon),
                    shape.r, shape.g, shape.b, shape.a
            );
        }
    }

    private static void drawWithShader(class_9801 mesh, class_1921 type) {
        type.method_60895(mesh);
        //VertexBuffer buffre = mesh.drawState().format().getImmediateDrawVertexBuffer();
        //buffre.bind();
        //buffre.upload(mesh);
        //buffre.drawWithShader(RenderSystem.getModelViewMatrix(), RenderSystem.getProjectionMatrix(), RenderType. RenderSystem.getShader());
    }


    public static class RenderedPolyface extends RenderedShape<ShapeDispatcher.Polyface>
    {
        // mode now can only be 4, 5, or 6
        private static final VertexFormat.class_5596[] faceIndices = new VertexFormat.class_5596[]{
                class_5596.field_27377, class_5596.field_27378, class_5596.field_29344, class_5596.field_29345, class_5596.field_27379, class_5596.field_27380, class_5596.field_27381, class_5596.field_27382};

        private static final class_1921 [] renderTypes = new class_1921[] {
                class_1921.method_49043(1),
                class_1921.method_49043(1),
                class_1921.method_49043(1),
                class_1921.method_49043(1),
                class_1921.method_62278(), // TODO wrong
                class_1921.method_62278(), // TODO wrong
                class_1921.method_62278(),
                class_1921.method_49042()
        };

        public RenderedPolyface(class_310 client, ShapeDispatcher.ExpiringShape shape)
        {
            super(client, (ShapeDispatcher.Polyface) shape);
        }

        @Override
        public void renderFaces(class_289 tesselator, double cx, double cy, double cz, float partialTick)
        {
            if (shape.fa == 0)
            {
                return;
            }

            if (shape.doublesided)
            {
                ////RenderSystem.disableCull(); // todo culling
            }
            else
            {
                ////RenderSystem.enableCull();
            }

            class_287 builder = tesselator.method_60827(faceIndices[shape.mode], class_290.field_1576);
            for (int i = 0; i < shape.vertexList.size(); i++)
            {
                class_243 vec = shape.vertexList.get(i);
                if (shape.relative.get(i))
                {
                    vec = shape.relativiseRender(client.field_1687, vec, partialTick);
                }
                builder.method_22912((float) (vec.method_10216() - cx), (float) (vec.method_10214() - cy), (float) (vec.method_10215() - cz)).method_22915(shape.fr, shape.fg, shape.fb, shape.fa);
            }
            drawWithShader(builder.method_60800(), renderTypes[shape.mode]);

            ////RenderSystem.disableCull();
            ////RenderSystem.depthMask(false);
            //RenderSystem.enableDepthTest();


        }

        @Override
        public void renderLines(class_4587 matrices, class_289 tesselator, double cx, double cy,
                                double cz, float partialTick)
        {
            if (shape.a == 0)
            {
                return;
            }

            if (shape.mode == 6)
            {
                class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_29345, class_290.field_1576);
                class_243 vec0 = null;
                for (int i = 0; i < shape.vertexList.size(); i++)
                {
                    class_243 vec = shape.vertexList.get(i);
                    if (shape.relative.get(i))
                    {
                        vec = shape.relativiseRender(client.field_1687, vec, partialTick);
                    }
                    if (i == 0)
                    {
                        vec0 = vec;
                    }
                    builder.method_22912((float) (vec.method_10216() - cx), (float) (vec.method_10214() - cy), (float) (vec.method_10215() - cz)).method_22915(shape.r, shape.g, shape.b, shape.a);
                }
                builder.method_22912((float) (vec0.method_10216() - cx), (float) (vec0.method_10214() - cy), (float) (vec0.method_10215() - cz)).method_22915(shape.r, shape.g, shape.b, shape.a);
                drawWithShader(builder.method_60800(), class_1921.method_49043(1));
                if (shape.inneredges)
                {
                    class_287 builderr = tesselator.method_60827(class_5596.field_29345, class_290.field_1576);
                    for (int i = 1; i < shape.vertexList.size() - 1; i++)
                    {
                        class_243 vec = shape.vertexList.get(i);
                        if (shape.relative.get(i))
                        {
                            vec = shape.relativiseRender(client.field_1687, vec, partialTick);
                        }
                        builderr.method_22912((float) (vec0.method_10216() - cx), (float) (vec0.method_10214() - cy), (float) (vec0.method_10215() - cz)).method_22915(shape.r, shape.g, shape.b, shape.a);
                        builderr.method_22912((float) (vec.method_10216() - cx), (float) (vec.method_10214() - cy), (float) (vec.method_10215() - cz)).method_22915(shape.r, shape.g, shape.b, shape.a);
                        builderr.method_22912((float) (vec0.method_10216() - cx), (float) (vec0.method_10214() - cy), (float) (vec0.method_10215() - cz)).method_22915(shape.r, shape.g, shape.b, shape.a);
                    }
                    drawWithShader(builderr.method_60800(), class_1921.method_49043(1));
                }
                return;
            }
            if (shape.mode == 5)
            {
                class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_29345, class_290.field_1576);
                class_243 vec = shape.vertexList.get(1);
                if (shape.relative.get(1))
                {
                    vec = shape.relativiseRender(client.field_1687, vec, partialTick);
                }
                builder.method_22912((float) (vec.method_10216() - cx), (float) (vec.method_10214() - cy), (float) (vec.method_10215() - cz)).method_22915(shape.r, shape.g, shape.b, shape.a);
                int i;
                for (i = 0; i < shape.vertexList.size(); i += 2)
                {
                    vec = shape.vertexList.get(i);
                    if (shape.relative.get(i))
                    {
                        vec = shape.relativiseRender(client.field_1687, vec, partialTick);
                    }
                    builder.method_22912((float) (vec.method_10216() - cx), (float) (vec.method_10214() - cy), (float) (vec.method_10215() - cz)).method_22915(shape.r, shape.g, shape.b, shape.a);
                }
                i = shape.vertexList.size() - 1;
                for (i -= 1 - i % 2; i > 0; i -= 2)
                {
                    vec = shape.vertexList.get(i);
                    if (shape.relative.get(i))
                    {
                        vec = shape.relativiseRender(client.field_1687, vec, partialTick);
                    }
                    builder.method_22912((float) (vec.method_10216() - cx), (float) (vec.method_10214() - cy), (float) (vec.method_10215() - cz)).method_22915(shape.r, shape.g, shape.b, shape.a);
                }
                if (shape.inneredges)
                {
                    for (i = 2; i < shape.vertexList.size() - 1; i++)
                    {
                        vec = shape.vertexList.get(i);
                        if (shape.relative.get(i))
                        {
                            vec = shape.relativiseRender(client.field_1687, vec, partialTick);
                        }
                        builder.method_22912((float) (vec.method_10216() - cx), (float) (vec.method_10214() - cy), (float) (vec.method_10215() - cz)).method_22915(shape.r, shape.g, shape.b, shape.a);
                    }
                }
                drawWithShader(builder.method_60800(), class_1921.method_49043(1));
                return;
            }
            if (shape.mode == 4)
            {
                //
                for (int i = 0; i < shape.vertexList.size(); i++)
                {
                    class_287 builder = tesselator.method_60827(class_5596.field_29345, class_290.field_1576);
                    class_243 vecA = shape.vertexList.get(i);
                    if (shape.relative.get(i))
                    {
                        vecA = shape.relativiseRender(client.field_1687, vecA, partialTick);
                    }
                    i++;
                    class_243 vecB = shape.vertexList.get(i);
                    if (shape.relative.get(i))
                    {
                        vecB = shape.relativiseRender(client.field_1687, vecB, partialTick);
                    }
                    i++;
                    class_243 vecC = shape.vertexList.get(i);
                    if (shape.relative.get(i))
                    {
                        vecC = shape.relativiseRender(client.field_1687, vecC, partialTick);
                    }
                    builder.method_22912((float) (vecA.method_10216() - cx), (float) (vecA.method_10214() - cy), (float) (vecA.method_10215() - cz)).method_22915(shape.r, shape.g, shape.b, shape.a);
                    builder.method_22912((float) (vecB.method_10216() - cx), (float) (vecB.method_10214() - cy), (float) (vecB.method_10215() - cz)).method_22915(shape.r, shape.g, shape.b, shape.a);

                    //builder.addVertex((float) (vecB.x() - cx), (float) (vecB.y() - cy), (float) (vecB.z() - cz)).setColor(shape.r, shape.g, shape.b, shape.a);
                    builder.method_22912((float) (vecC.method_10216() - cx), (float) (vecC.method_10214() - cy), (float) (vecC.method_10215() - cz)).method_22915(shape.r, shape.g, shape.b, shape.a);

                    //builder.addVertex((float) (vecC.x() - cx), (float) (vecC.y() - cy), (float) (vecC.z() - cz)).setColor(shape.r, shape.g, shape.b, shape.a);
                    builder.method_22912((float) (vecA.method_10216() - cx), (float) (vecA.method_10214() - cy), (float) (vecA.method_10215() - cz)).method_22915(shape.r, shape.g, shape.b, shape.a);

                    drawWithShader(builder.method_60800(), class_1921.method_49043(1));
                }
                //drawWithShader(builder.buildOrThrow(), RenderType.debugLineStrip(1));
            }
        }
    }

    public static class RenderedSphere extends RenderedShape<ShapeDispatcher.Sphere>
    {
        public RenderedSphere(class_310 client, ShapeDispatcher.ExpiringShape shape)
        {
            super(client, (ShapeDispatcher.Sphere) shape);
        }

        @Override
        public void renderLines(class_4587 matrices, class_289 tesselator, double cx, double cy, double cz, float partialTick)
        {
            if (shape.a == 0.0)
            {
                return;
            }
            class_243 vc = shape.relativiseRender(client.field_1687, shape.center, partialTick);
            drawSphereWireframe(tesselator,
                    (float) (vc.field_1352 - cx), (float) (vc.field_1351 - cy), (float) (vc.field_1350 - cz),
                    (float) (shape.radius + renderEpsilon), shape.subdivisions,
                    shape.r, shape.g, shape.b, shape.a);
        }

        @Override
        public void renderFaces(class_289 tesselator, double cx, double cy, double cz, float partialTick)
        {
            if (shape.fa == 0.0)
            {
                return;
            }
            class_243 vc = shape.relativiseRender(client.field_1687, shape.center, partialTick);
            drawSphereFaces(tesselator,
                    (float) (vc.field_1352 - cx), (float) (vc.field_1351 - cy), (float) (vc.field_1350 - cz),
                    (float) (shape.radius + renderEpsilon), shape.subdivisions,
                    shape.fr, shape.fg, shape.fb, shape.fa);
        }
    }

    public static class RenderedCylinder extends RenderedShape<ShapeDispatcher.Cylinder>
    {
        public RenderedCylinder(class_310 client, ShapeDispatcher.ExpiringShape shape)
        {
            super(client, (ShapeDispatcher.Cylinder) shape);
        }

        @Override
        public void renderLines(class_4587 matrices, class_289 tesselator, double cx, double cy, double cz, float partialTick)
        {
            if (shape.a == 0.0)
            {
                return;
            }
            class_243 vc = shape.relativiseRender(client.field_1687, shape.center, partialTick);
            double dir = class_3532.method_17822(shape.height);
            drawCylinderWireframe(tesselator,
                    (float) (vc.field_1352 - cx - dir * renderEpsilon), (float) (vc.field_1351 - cy - dir * renderEpsilon), (float) (vc.field_1350 - cz - dir * renderEpsilon),
                    (float) (shape.radius + renderEpsilon), (float) (shape.height + 2 * dir * renderEpsilon), shape.axis,
                    shape.subdivisions, shape.height == 0,
                    shape.r, shape.g, shape.b, shape.a);

        }

        @Override
        public void renderFaces(class_289 tesselator, double cx, double cy, double cz, float partialTick)
        {
            if (shape.fa == 0.0)
            {
                return;
            }
            class_243 vc = shape.relativiseRender(client.field_1687, shape.center, partialTick);
            double dir = class_3532.method_17822(shape.height);
            drawCylinderFaces(tesselator,
                    (float) (vc.field_1352 - cx - dir * renderEpsilon), (float) (vc.field_1351 - cy - dir * renderEpsilon), (float) (vc.field_1350 - cz - dir * renderEpsilon),
                    (float) (shape.radius + renderEpsilon), (float) (shape.height + 2 * dir * renderEpsilon), shape.axis,
                    shape.subdivisions, shape.radius == 0,
                    shape.fr, shape.fg, shape.fb, shape.fa);
        }
    }

    // some raw shit

    public static void drawLine(class_289 tesselator, float x1, float y1, float z1, float x2, float y2, float z2, float red1, float grn1, float blu1, float alpha)
    {
        class_287 builder = tesselator.method_60827(class_5596.field_29345, class_290.field_1576);
        builder.method_22912(x1, y1, z1).method_22915(red1, grn1, blu1, alpha);
        builder.method_22912(x2, y2, z2).method_22915(red1, grn1, blu1, alpha);
        drawWithShader(builder.method_60800(), class_1921.method_49043(1));
    }

    public static void drawBoxWireGLLines(
            class_289 tesselator,
            float x1, float y1, float z1,
            float x2, float y2, float z2,
            boolean xthick, boolean ythick, boolean zthick,
            float red1, float grn1, float blu1, float alpha, float red2, float grn2, float blu2)
    {
        class_287 builder = tesselator.method_60827(class_5596.field_29345, class_290.field_1576);
        /* old lines not using strip
        if (xthick)
        {
            builder.addVertex(x1, y1, z1).setColor(red1, grn2, blu2, alpha);
            builder.addVertex(x2, y1, z1).setColor(red1, grn2, blu2, alpha);

            builder.addVertex(x2, y2, z1).setColor(red1, grn1, blu1, alpha);
            builder.addVertex(x1, y2, z1).setColor(red1, grn1, blu1, alpha);

            builder.addVertex(x1, y1, z2).setColor(red1, grn1, blu1, alpha);
            builder.addVertex(x2, y1, z2).setColor(red1, grn1, blu1, alpha);

            builder.addVertex(x1, y2, z2).setColor(red1, grn1, blu1, alpha);
            builder.addVertex(x2, y2, z2).setColor(red1, grn1, blu1, alpha);
        }
        if (ythick)
        {
            builder.addVertex(x1, y1, z1).setColor(red2, grn1, blu2, alpha);
            builder.addVertex(x1, y2, z1).setColor(red2, grn1, blu2, alpha);

            builder.addVertex(x2, y1, z1).setColor(red1, grn1, blu1, alpha);
            builder.addVertex(x2, y2, z1).setColor(red1, grn1, blu1, alpha);

            builder.addVertex(x1, y2, z2).setColor(red1, grn1, blu1, alpha);
            builder.addVertex(x1, y1, z2).setColor(red1, grn1, blu1, alpha);

            builder.addVertex(x2, y1, z2).setColor(red1, grn1, blu1, alpha);
            builder.addVertex(x2, y2, z2).setColor(red1, grn1, blu1, alpha);
        }
        if (zthick)
        {
            builder.addVertex(x1, y1, z1).setColor(red2, grn2, blu1, alpha);
            builder.addVertex(x1, y1, z2).setColor(red2, grn2, blu1, alpha);

            builder.addVertex(x1, y2, z1).setColor(red1, grn1, blu1, alpha);
            builder.addVertex(x1, y2, z2).setColor(red1, grn1, blu1, alpha);

            builder.addVertex(x2, y1, z2).setColor(red1, grn1, blu1, alpha);
            builder.addVertex(x2, y1, z1).setColor(red1, grn1, blu1, alpha);

            builder.addVertex(x2, y2, z1).setColor(red1, grn1, blu1, alpha);
            builder.addVertex(x2, y2, z2).setColor(red1, grn1, blu1, alpha);
        }
         */

        if (xthick)

        {
            builder.method_22912(x1, y1, z1).method_22915(red1, grn2, blu2, alpha);
            builder.method_22912(x2, y1, z1).method_22915(red1, grn2, blu2, alpha);

            builder.method_22912(x2, y2, z1).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x1, y2, z1).method_22915(red1, grn1, blu1, alpha);

            builder.method_22912(x1, y2, z2).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x2, y2, z2).method_22915(red1, grn1, blu1, alpha);

            builder.method_22912(x2, y1, z2).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x1, y1, z2).method_22915(red1, grn1, blu1, alpha);
        }
        if (ythick)
        {
            builder.method_22912(x1, y1, z1).method_22915(red2, grn1, blu2, alpha);
            builder.method_22912(x1, y2, z1).method_22915(red2, grn1, blu2, alpha);

            builder.method_22912(x2, y2, z1).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x2, y1, z1).method_22915(red1, grn1, blu1, alpha);

            builder.method_22912(x2, y1, z2).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x2, y2, z2).method_22915(red1, grn1, blu1, alpha);

            builder.method_22912(x1, y2, z2).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x1, y1, z2).method_22915(red1, grn1, blu1, alpha);
        }
        if (zthick)
        {
            builder.method_22912(x1, y1, z1).method_22915(red2, grn2, blu1, alpha);
            builder.method_22912(x1, y1, z2).method_22915(red2, grn2, blu1, alpha);

            builder.method_22912(x1, y2, z2).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x1, y2, z1).method_22915(red1, grn1, blu1, alpha);

            builder.method_22912(x2, y2, z1).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x2, y2, z2).method_22915(red1, grn1, blu1, alpha);

            builder.method_22912(x2, y1, z2).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x2, y1, z1).method_22915(red1, grn1, blu1, alpha);
        }
        drawWithShader(builder.method_60800(), class_1921.method_49043(1));
    }

    public static void drawBoxFaces(
            class_289 tesselator,
            float x1, float y1, float z1,
            float x2, float y2, float z2,
            boolean xthick, boolean ythick, boolean zthick,
            float red1, float grn1, float blu1, float alpha)
    {
        class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);

        if (xthick && ythick)
        {
            builder.method_22912(x1, y1, z1).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x2, y1, z1).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x2, y2, z1).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x1, y2, z1).method_22915(red1, grn1, blu1, alpha);
            if (zthick)
            {
                builder.method_22912(x1, y1, z2).method_22915(red1, grn1, blu1, alpha);
                builder.method_22912(x1, y2, z2).method_22915(red1, grn1, blu1, alpha);
                builder.method_22912(x2, y2, z2).method_22915(red1, grn1, blu1, alpha);
                builder.method_22912(x2, y1, z2).method_22915(red1, grn1, blu1, alpha);
            }
        }


        if (zthick && ythick)
        {
            builder.method_22912(x1, y1, z1).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x1, y2, z1).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x1, y2, z2).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x1, y1, z2).method_22915(red1, grn1, blu1, alpha);

            if (xthick)
            {
                builder.method_22912(x2, y1, z1).method_22915(red1, grn1, blu1, alpha);
                builder.method_22912(x2, y1, z2).method_22915(red1, grn1, blu1, alpha);
                builder.method_22912(x2, y2, z2).method_22915(red1, grn1, blu1, alpha);
                builder.method_22912(x2, y2, z1).method_22915(red1, grn1, blu1, alpha);
            }
        }

        // now at least drawing one
        if (zthick && xthick)
        {
            builder.method_22912(x1, y1, z1).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x2, y1, z1).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x2, y1, z2).method_22915(red1, grn1, blu1, alpha);
            builder.method_22912(x1, y1, z2).method_22915(red1, grn1, blu1, alpha);


            if (ythick)
            {
                builder.method_22912(x1, y2, z1).method_22915(red1, grn1, blu1, alpha);
                builder.method_22912(x2, y2, z1).method_22915(red1, grn1, blu1, alpha);
                builder.method_22912(x2, y2, z2).method_22915(red1, grn1, blu1, alpha);
                builder.method_22912(x1, y2, z2).method_22915(red1, grn1, blu1, alpha);
            }
        }
        drawWithShader(builder.method_60800(), class_1921.method_49042());
    }

    public static void drawCylinderWireframe(class_289 tesselator,
                                             float cx, float cy, float cz,
                                             float r, float h, class_2350.class_2351 axis, int subd, boolean isFlat,
                                             float red, float grn, float blu, float alpha)
    {
        float step = (float) Math.PI / (subd / 2);
        int num_steps180 = (int) (Math.PI / step) + 1;
        int num_steps360 = (int) (2 * Math.PI / step);
        int hsteps = 1;
        float hstep = 1.0f;
        if (!isFlat)
        {
            hsteps = (int) Math.ceil(class_3532.method_15379(h) / (step * r)) + 1;
            hstep = h / (hsteps - 1);
        }// draw base

        if (axis == class_2350.class_2351.field_11052)
        {
            for (int dh = 0; dh < hsteps; dh++)
            {
                float hh = dh * hstep;
                class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_29345, class_290.field_1576);  // line loop to line strip
                for (int i = 0; i <= num_steps360 + 1; i++)
                {
                    float theta = step * i;
                    float x = r * class_3532.method_15362(theta);
                    float y = hh;
                    float z = r * class_3532.method_15374(theta);
                    builder.method_22912(x + cx, y + cy, z + cz).method_22915(red, grn, blu, alpha);
                }
                drawWithShader(builder.method_60800(), class_1921.method_49043(1));
            }

            if (!isFlat)
            {
                for (int i = 0; i <= num_steps180; i++)
                {
                    class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_29345, class_290.field_1576); // line loop to line strip
                    float theta = step * i;
                    float x = r * class_3532.method_15362(theta);

                    float z = r * class_3532.method_15374(theta);

                    builder.method_22912(cx - x, cy + 0, cz + z).method_22915(red, grn, blu, alpha);
                    builder.method_22912(cx + x, cy + 0, cz - z).method_22915(red, grn, blu, alpha);
                    builder.method_22912(cx + x, cy + h, cz - z).method_22915(red, grn, blu, alpha);
                    builder.method_22912(cx - x, cy + h, cz + z).method_22915(red, grn, blu, alpha);
                    builder.method_22912(cx - x, cy + 0, cz + z).method_22915(red, grn, blu, alpha);
                    drawWithShader(builder.method_60800(), class_1921.method_49043(1));
                }
            }
            /* else
            {
                BufferBuilder builder = tesselator.begin(VertexFormat.Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);
                for (int i = 0; i <= num_steps180; i++)
                {
                    float theta = step * i;
                    float x = r * Mth.cos(theta);
                    float z = r * Mth.sin(theta);
                    builder.addVertex(cx - x, cy, cz + z).setColor(red, grn, blu, alpha);
                    builder.addVertex(cx + x, cy, cz - z).setColor(red, grn, blu, alpha);
                }
                drawWithShader(builder.buildOrThrow(), RenderType.debugLineStrip(1));
            }*/

        }
        else if (axis == class_2350.class_2351.field_11048)
        {
            for (int dh = 0; dh < hsteps; dh++)
            {
                float hh = dh * hstep;
                class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_29345, class_290.field_1576); // line loop to line strip
                for (int i = 0; i <= num_steps360; i++)
                {
                    float theta = step * i;
                    float z = r * class_3532.method_15362(theta);
                    float x = hh;
                    float y = r * class_3532.method_15374(theta);
                    builder.method_22912(x + cx, y + cy, z + cz).method_22915(red, grn, blu, alpha);
                }
                drawWithShader(builder.method_60800(), class_1921.method_49043(1));
            }

            if (!isFlat)
            {
                for (int i = 0; i <= num_steps180; i++)
                {
                    class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_29345, class_290.field_1576); // line loop to line strip
                    float theta = step * i;
                    float y = r * class_3532.method_15362(theta);

                    float z = r * class_3532.method_15374(theta);

                    builder.method_22912(cx + 0, cy - y, cz + z).method_22915(red, grn, blu, alpha);
                    builder.method_22912(cx + 0, cy + y, cz - z).method_22915(red, grn, blu, alpha);
                    builder.method_22912(cx + h, cy + y, cz - z).method_22915(red, grn, blu, alpha);
                    builder.method_22912(cx + h, cy - y, cz + z).method_22915(red, grn, blu, alpha);
                    drawWithShader(builder.method_60800(), class_1921.method_49043(1));
                }
            }
            /*else
            {
                BufferBuilder builder = tesselator.begin(Mode.DEBUG_LINE_STRIP, DefaultVertexFormat.POSITION_COLOR);
                for (int i = 0; i <= num_steps360+1; i++)
                {
                    float theta = step * i;
                    float y = r * Mth.cos(theta);
                    float z = r * Mth.sin(theta);
                    builder.addVertex(cx, cy + y, cz + z).setColor(red, grn, blu, alpha);
                    //builder.addVertex(cx, cy + y, cz - z).setColor(red, grn, blu, alpha);
                }
                drawWithShader(builder.buildOrThrow(), RenderType.debugLineStrip(1));
            }*/
        }
        else if (axis == class_2350.class_2351.field_11051)
        {
            for (int dh = 0; dh < hsteps; dh++)
            {
                float hh = dh * hstep;
                class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_29345, class_290.field_1576); // line loop to line strip
                for (int i = 0; i <= num_steps360; i++)
                {
                    float theta = step * i;
                    float y = r * class_3532.method_15362(theta);
                    float z = hh;
                    float x = r * class_3532.method_15374(theta);
                    builder.method_22912(x + cx, y + cy, z + cz).method_22915(red, grn, blu, alpha);
                }
                drawWithShader(builder.method_60800(), class_1921.method_49043(1));
            }
            if (!isFlat)
            {
                for (int i = 0; i <= num_steps180; i++)
                {
                    class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_29345, class_290.field_1576); // line loop to line strip
                    float theta = step * i;
                    float x = r * class_3532.method_15362(theta);

                    float y = r * class_3532.method_15374(theta);

                    builder.method_22912(cx + x, cy - y, cz + 0).method_22915(red, grn, blu, alpha);
                    builder.method_22912(cx - x, cy + y, cz + 0).method_22915(red, grn, blu, alpha);
                    builder.method_22912(cx - x, cy + y, cz + h).method_22915(red, grn, blu, alpha);
                    builder.method_22912(cx + x, cy - y, cz + h).method_22915(red, grn, blu, alpha);
                    drawWithShader(builder.method_60800(), class_1921.method_49043(1));
                }
            }
            /*else
            {
                BufferBuilder builder = tesselator.begin(VertexFormat.Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);
                for (int i = 0; i <= num_steps180; i++)
                {
                    float theta = step * i;
                    float x = r * Mth.cos(theta);
                    float y = r * Mth.sin(theta);
                    builder.addVertex(cx + x, cy - y, cz).setColor(red, grn, blu, alpha);
                    builder.addVertex(cx - x, cy + y, cz).setColor(red, grn, blu, alpha);
                }
                drawWithShader(builder.buildOrThrow(), RenderType.debugLineStrip(1));
            }*/
        }
    }

    public static void drawCylinderFaces(class_289 tesselator,
                                         float cx, float cy, float cz,
                                         float r, float h, class_2350.class_2351 axis, int subd, boolean isFlat,
                                         float red, float grn, float blu, float alpha)
    {
        float step = (float) Math.PI / (subd / 2);
        //final int num_steps180 = (int) (Math.PI / step) + 1;
        int num_steps360 = (int) (2 * Math.PI / step) + 1;

        if (axis == class_2350.class_2351.field_11052)
        {

            class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_27381, class_290.field_1576);
            builder.method_22912(cx, cy, cz).method_22915(red, grn, blu, alpha);
            for (int i = 0; i <= num_steps360; i++)
            {
                float theta = step * i;
                float x = r * class_3532.method_15362(theta);
                float z = r * class_3532.method_15374(theta);
                builder.method_22912(x + cx, cy, z + cz).method_22915(red, grn, blu, alpha);
            }
            drawWithShader(builder.method_60800(), class_1921.method_62278());
            if (!isFlat)
            {
                class_287 builderr = tesselator.method_60827(VertexFormat.class_5596.field_27381, class_290.field_1576);
                builderr.method_22912(cx, cy + h, cz).method_22915(red, grn, blu, alpha);
                for (int i = 0; i <= num_steps360; i++)
                {
                    float theta = step * i;
                    float x = r * class_3532.method_15362(theta);
                    float z = r * class_3532.method_15374(theta);
                    builderr.method_22912(x + cx, cy + h, z + cz).method_22915(red, grn, blu, alpha);
                }
                drawWithShader(builderr.method_60800(), class_1921.method_62278());

                class_287 builderrr = tesselator.method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);  // quad strip to quads
                float xp = r * 1;
                float zp = r * 0;
                for (int i = 1; i <= num_steps360; i++)
                {
                    float theta = step * i;
                    float x = r * class_3532.method_15362(theta);
                    float z = r * class_3532.method_15374(theta);
                    builderrr.method_22912(cx + xp, cy + 0, cz + zp).method_22915(red, grn, blu, alpha);
                    builderrr.method_22912(cx + xp, cy + h, cz + zp).method_22915(red, grn, blu, alpha);
                    builderrr.method_22912(cx + x, cy + h, cz + z).method_22915(red, grn, blu, alpha);
                    builderrr.method_22912(cx + x, cy + 0, cz + z).method_22915(red, grn, blu, alpha);
                    xp = x;
                    zp = z;
                }
                drawWithShader(builderrr.method_60800(), class_1921.method_49042());
            }

        }
        else if (axis == class_2350.class_2351.field_11048)
        {
            class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_27381, class_290.field_1576);
            builder.method_22912(cx, cy, cz).method_22915(red, grn, blu, alpha);
            for (int i = 0; i <= num_steps360; i++)
            {
                float theta = step * i;
                float y = r * class_3532.method_15362(theta);
                float z = r * class_3532.method_15374(theta);
                builder.method_22912(cx, cy + y, z + cz).method_22915(red, grn, blu, alpha);
            }
            drawWithShader(builder.method_60800(), class_1921.method_62278());
            if (!isFlat)
            {
                class_287 builderr = tesselator.method_60827(VertexFormat.class_5596.field_27381, class_290.field_1576);
                builderr.method_22912(cx + h, cy, cz).method_22915(red, grn, blu, alpha);
                for (int i = 0; i <= num_steps360; i++)
                {
                    float theta = step * i;
                    float y = r * class_3532.method_15362(theta);
                    float z = r * class_3532.method_15374(theta);
                    builderr.method_22912(cx + h, cy + y, cz + z).method_22915(red, grn, blu, alpha);
                }
                drawWithShader(builderr.method_60800(), class_1921.method_62278());

                class_287 builderrr = tesselator.method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);  // quad strip to quads
                float yp = r * 1;
                float zp = r * 0;
                for (int i = 1; i <= num_steps360; i++)
                {
                    float theta = step * i;
                    float y = r * class_3532.method_15362(theta);
                    float z = r * class_3532.method_15374(theta);
                    builderrr.method_22912(cx + 0, cy + yp, cz + zp).method_22915(red, grn, blu, alpha);
                    builderrr.method_22912(cx + h, cy + yp, cz + zp).method_22915(red, grn, blu, alpha);
                    builderrr.method_22912(cx + h, cy + y, cz + z).method_22915(red, grn, blu, alpha);
                    builderrr.method_22912(cx + 0, cy + y, cz + z).method_22915(red, grn, blu, alpha);
                    yp = y;
                    zp = z;
                }
                drawWithShader(builderrr.method_60800(), class_1921.method_49042());
            }
        }
        else if (axis == class_2350.class_2351.field_11051)
        {
            class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_27381, class_290.field_1576);
            builder.method_22912(cx, cy, cz).method_22915(red, grn, blu, alpha);
            for (int i = 0; i <= num_steps360; i++)
            {
                float theta = step * i;
                float x = r * class_3532.method_15362(theta);
                float y = r * class_3532.method_15374(theta);
                builder.method_22912(x + cx, cy + y, cz).method_22915(red, grn, blu, alpha);
            }
            drawWithShader(builder.method_60800(), class_1921.method_62278());
            if (!isFlat)
            {
                class_287 builderr = tesselator.method_60827(VertexFormat.class_5596.field_27381, class_290.field_1576);
                builderr.method_22912(cx, cy, cz + h).method_22915(red, grn, blu, alpha);
                for (int i = 0; i <= num_steps360; i++)
                {
                    float theta = step * i;
                    float x = r * class_3532.method_15362(theta);
                    float y = r * class_3532.method_15374(theta);
                    builderr.method_22912(x + cx, cy + y, cz + h).method_22915(red, grn, blu, alpha);
                }
                drawWithShader(builderr.method_60800(), class_1921.method_62278());

                class_287 builderrr = tesselator.method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);  // quad strip to quads
                float xp = r;
                float yp = 0;
                for (int i = 1; i <= num_steps360; i++)
                {
                    float theta = step * i;
                    float x = r * class_3532.method_15362(theta);
                    float y = r * class_3532.method_15374(theta);
                    builderrr.method_22912(cx + xp, cy + yp, cz + 0).method_22915(red, grn, blu, alpha);
                    builderrr.method_22912(cx + xp, cy + yp, cz + h).method_22915(red, grn, blu, alpha);
                    builderrr.method_22912(cx + x, cy + y, cz + h).method_22915(red, grn, blu, alpha);
                    builderrr.method_22912(cx + x, cy + y, cz + 0).method_22915(red, grn, blu, alpha);
                    xp = x;
                    yp = y;
                }
                drawWithShader(builderrr.method_60800(), class_1921.method_49042());
            }
        }
    }

    public static void drawSphereWireframe(class_289 tesselator,
                                           float cx, float cy, float cz,
                                           float r, int subd,
                                           float red, float grn, float blu, float alpha)
    {
        float step = (float) Math.PI / (subd / 2);
        int num_steps180 = (int) (Math.PI / step) + 1;
        int num_steps360 = (int) (2 * Math.PI / step) + 1;
        for (int i = 0; i <= num_steps360; i++)
        {
            class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_29345, class_290.field_1576);
            float theta = step * i;
            for (int j = 0; j <= num_steps180; j++)
            {
                float phi = step * j;
                float x = r * class_3532.method_15374(phi) * class_3532.method_15362(theta);
                float z = r * class_3532.method_15374(phi) * class_3532.method_15374(theta);
                float y = r * class_3532.method_15362(phi);
                builder.method_22912(x + cx, y + cy, z + cz).method_22915(red, grn, blu, alpha);
            }
            drawWithShader(builder.method_60800(), class_1921.method_49043(1));
        }
        for (int j = 0; j <= num_steps180; j++)
        {
            class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_29345, class_290.field_1576); // line loop to line strip
            float phi = step * j;

            for (int i = 0; i <= num_steps360; i++)
            {
                float theta = step * i;
                float x = r * class_3532.method_15374(phi) * class_3532.method_15362(theta);
                float z = r * class_3532.method_15374(phi) * class_3532.method_15374(theta);
                float y = r * class_3532.method_15362(phi);
                builder.method_22912(x + cx, y + cy, z + cz).method_22915(red, grn, blu, alpha);
            }
            drawWithShader(builder.method_60800(), class_1921.method_49043(1));
        }

    }

    public static void drawSphereFaces(class_289 tesselator,
                                       float cx, float cy, float cz,
                                       float r, int subd,
                                       float red, float grn, float blu, float alpha)
    {

        float step = (float) Math.PI / (subd / 2);
        int num_steps180 = (int) (Math.PI / step) + 1;
        int num_steps360 = (int) (2 * Math.PI / step);
        for (int i = 0; i <= num_steps360; i++)
        {
            float theta = i * step;
            float thetaprime = theta + step;
            class_287 builder = tesselator.method_60827(VertexFormat.class_5596.field_27382, class_290.field_1576);  // quad strip to quads
            float xb = 0;
            float zb = 0;
            float xbp = 0;
            float zbp = 0;
            float yp = r;
            for (int j = 0; j <= num_steps180; j++)
            {
                float phi = j * step;
                float x = r * class_3532.method_15374(phi) * class_3532.method_15362(theta);
                float z = r * class_3532.method_15374(phi) * class_3532.method_15374(theta);
                float y = r * class_3532.method_15362(phi);
                float xp = r * class_3532.method_15374(phi) * class_3532.method_15362(thetaprime);
                float zp = r * class_3532.method_15374(phi) * class_3532.method_15374(thetaprime);
                builder.method_22912(xb + cx, yp + cy, zb + cz).method_22915(red, grn, blu, alpha);
                builder.method_22912(xbp + cx, yp + cy, zbp + cz).method_22915(red, grn, blu, alpha);
                builder.method_22912(xp + cx, y + cy, zp + cz).method_22915(red, grn, blu, alpha);
                builder.method_22912(x + cx, y + cy, z + cz).method_22915(red, grn, blu, alpha);
                xb = x;
                zb = z;
                xbp = xp;
                zbp = zp;
                yp = y;
            }
            drawWithShader(builder.method_60800(), class_1921.method_49042());
        }
    }
}
