package carpet.patches;

import net.minecraft.class_10182;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_2596;
import net.minecraft.class_2709;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_8792;
import net.minecraft.server.MinecraftServer;
import java.util.Set;

public class NetHandlerPlayServerFake extends class_3244
{
    public NetHandlerPlayServerFake(final MinecraftServer minecraftServer, final class_2535 connection, final class_3222 serverPlayer, final class_8792 i)
    {
        super(minecraftServer, connection, serverPlayer, i);
    }

    @Override
    public void method_14364(final class_2596<?> packetIn)
    {
    }

    @Override
    public void method_52396(class_2561 message)
    {
        if (message.method_10851() instanceof class_2588 text && (text.method_11022().equals("multiplayer.disconnect.idling") || text.method_11022().equals("multiplayer.disconnect.duplicate_login")))
        {
            ((EntityPlayerMPFake) field_14140).kill(message);
        }
    }

    @Override
    public void method_14360(class_10182 positionMoveRotation, Set<class_2709> set)
    {
        super.method_14360(positionMoveRotation, set);
        if (field_14140.method_51469().method_18470(field_14140.method_5667()) != null) {
            method_14372();
            field_14140.method_51469().method_14178().method_14096(field_14140);
        }
    }

}



