package carpet.patches;

import carpet.CarpetSettings;
import com.mojang.authlib.GameProfile;
import net.minecraft.class_10264;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1702;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_2598;
import net.minecraft.class_2631;
import net.minecraft.class_2680;
import net.minecraft.class_2703;
import net.minecraft.class_2726;
import net.minecraft.class_2799;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3312;
import net.minecraft.class_3738;
import net.minecraft.class_4844;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_5454;
import net.minecraft.class_8791;
import net.minecraft.class_8792;
import net.minecraft.class_9812;
import net.minecraft.server.MinecraftServer;
import carpet.fakes.ServerPlayerInterface;
import carpet.utils.Messenger;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

@SuppressWarnings("EntityConstructor")
public class EntityPlayerMPFake extends class_3222
{
    private static final Set<String> spawning = new HashSet<>();

    public Runnable fixStartingPosition = () -> {};
    public boolean isAShadow;

    // Returns true if it was successful, false if couldn't spawn due to the player not existing in Mojang servers
    public static boolean createFake(String username, MinecraftServer server, class_243 pos, double yaw, double pitch, class_5321<class_1937> dimensionId, class_1934 gamemode, boolean flying)
    {
        //prolly half of that crap is not necessary, but it works
        class_3218 worldIn = server.method_3847(dimensionId);
        class_3312.method_14510(false);
        GameProfile gameprofile;
        try {
            gameprofile = server.method_3793().method_14515(username).orElse(null); //findByName  .orElse(null)
        }
        finally {
            class_3312.method_14510(server.method_3816() && server.method_3828());
        }
        if (gameprofile == null)
        {
            if (!CarpetSettings.allowSpawningOfflinePlayers)
            {
                return false;
            } else {
                gameprofile = new GameProfile(class_4844.method_43344(username), username);
            }
        }
        GameProfile finalGP = gameprofile;

        // We need to mark this player as spawning so that we do not
        // try to spawn another player with the name while the profile
        // is being fetched - preventing multiple players spawning
        String name = gameprofile.getName();
        spawning.add(name);

        fetchGameProfile(name).whenCompleteAsync((p, t) -> {
            // Always remove the name, even if exception occurs
            spawning.remove(name);
            if (t != null)
            {
                return;
            }

            GameProfile current = finalGP;
            if (p.isPresent())
            {
                current = p.get();
            }
            EntityPlayerMPFake instance = new EntityPlayerMPFake(server, worldIn, current, class_8791.method_53821(), false);
            instance.fixStartingPosition = () -> instance.method_5808(pos.field_1352, pos.field_1351, pos.field_1350, (float) yaw, (float) pitch);
            server.method_3760().method_14570(new FakeClientConnection(class_2598.field_11941), instance, new class_8792(current, 0, instance.method_53823(), false));
            instance.method_48105(worldIn, pos.field_1352, pos.field_1351, pos.field_1350, Set.of(), (float) yaw, (float) pitch, true);
            instance.method_6033(20.0F);
            instance.method_31482();
            instance.method_5996(class_5134.field_47761).method_6192(0.6F);
            instance.field_13974.method_30118(gamemode);
            server.method_3760().method_14589(new class_2726(instance, (byte) (instance.field_6241 * 256 / 360)), dimensionId);//instance.dimension);
            server.method_3760().method_14589(class_10264.method_64558(instance), dimensionId);//instance.dimension);
            //instance.world.getChunkManager(). updatePosition(instance);
            instance.field_6011.method_12778(field_7518, (byte) 0x7f); // show all model layers (incl. capes)
            instance.method_31549().field_7479 = flying;
        }, server);
        return true;
    }

    private static CompletableFuture<Optional<GameProfile>> fetchGameProfile(final String name) {
        return class_2631.method_52580(name);
    }

    public static EntityPlayerMPFake createShadow(MinecraftServer server, class_3222 player)
    {
        player.method_5682().method_3760().method_14611(player);
        player.field_13987.method_52396(class_2561.method_43471("multiplayer.disconnect.duplicate_login"));
        class_3218 worldIn = player.method_51469();//.getWorld(player.dimension);
        GameProfile gameprofile = player.method_7334();
        EntityPlayerMPFake playerShadow = new EntityPlayerMPFake(server, worldIn, gameprofile, player.method_53823(), true);
        playerShadow.method_46364(player.method_45163());
        server.method_3760().method_14570(new FakeClientConnection(class_2598.field_11941), playerShadow, new class_8792(gameprofile, 0, player.method_53823(), true));

        playerShadow.method_6033(player.method_6032());
        playerShadow.field_13987.method_14363(player.method_23317(), player.method_23318(), player.method_23321(), player.method_36454(), player.method_36455());
        playerShadow.field_13974.method_30118(player.field_13974.method_14257());
        ((ServerPlayerInterface) playerShadow).getActionPack().copyFrom(((ServerPlayerInterface) player).getActionPack());
        // this might create problems if a player logs back in...
        playerShadow.method_5996(class_5134.field_47761).method_6192(0.6F);
        playerShadow.field_6011.method_12778(field_7518, player.method_5841().method_12789(field_7518));


        server.method_3760().method_14589(new class_2726(playerShadow, (byte) (player.field_6241 * 256 / 360)), playerShadow.method_51469().method_27983());
        server.method_3760().method_14581(new class_2703(class_2703.class_5893.field_29136, playerShadow));
        //player.world.getChunkManager().updatePosition(playerShadow);
        playerShadow.method_31549().field_7479 = player.method_31549().field_7479;
        return playerShadow;
    }

    public static EntityPlayerMPFake respawnFake(MinecraftServer server, class_3218 level, GameProfile profile, class_8791 cli)
    {
        return new EntityPlayerMPFake(server, level, profile, cli, false);
    }

    public static boolean isSpawningPlayer(String username)
    {
        return spawning.contains(username);
    }

    private EntityPlayerMPFake(MinecraftServer server, class_3218 worldIn, GameProfile profile, class_8791 cli, boolean shadow)
    {
        super(server, worldIn, profile, cli);
        isAShadow = shadow;
    }

    @Override
    public void method_6116(final class_1304 slot, final class_1799 previous, final class_1799 stack)
    {
        if (!method_6115()) super.method_6116(slot, previous, stack);
    }

    @Override
    public void method_5768(class_3218 level)
    {
        kill(Messenger.s("Killed"));
    }

    public void kill(class_2561 reason)
    {
        shakeOff();

        if (reason.method_10851() instanceof class_2588 text && text.method_11022().equals("multiplayer.disconnect.duplicate_login")) {
            this.field_13987.method_10839(new class_9812(reason));
        } else {
            this.method_5682().method_63588(new class_3738(this.method_5682().method_3780(), () -> {
                this.field_13987.method_10839(new class_9812(reason));
            }));
        }
    }

    @Override
    public void method_5773()
    {
        if (this.method_5682().method_3780() % 10 == 0)
        {
            this.field_13987.method_14372();
            this.method_51469().method_14178().method_14096(this);
        }
        try
        {
            super.method_5773();
            this.method_14226();
        }
        catch (NullPointerException ignored)
        {
            // happens with that paper port thingy - not sure what that would fix, but hey
            // the game not gonna crash violently.
        }


    }

    private void shakeOff()
    {
        if (method_5854() instanceof class_1657) method_5848();
        for (class_1297 passenger : method_5736())
        {
            if (passenger instanceof class_1657) passenger.method_5848();
        }
    }

    @Override
    public void method_6078(class_1282 cause)
    {
        shakeOff();
        super.method_6078(cause);
        method_6033(20);
        this.field_7493 = new class_1702();
        kill(this.method_6066().method_5548());
    }

    @Override
    public String method_14209()
    {
        return "127.0.0.1";
    }

    @Override
    public boolean method_39426() {
        return CarpetSettings.allowListingFakePlayers;
    }

    @Override
    protected void method_5623(double y, boolean onGround, class_2680 state, class_2338 pos) {
        method_65942(0.0, y, 0.0, onGround);
    }

    @Override
    public class_3222 method_5731(class_5454 serverLevel)
    {
        super.method_61275(serverLevel);
        if (field_13989) {
            class_2799 p = new class_2799(class_2799.class_2800.field_12774);
            field_13987.method_12068(p);
        }

        // If above branch was taken, *this* has been removed and replaced, the new instance has been set
        // on 'our' connection (which is now theirs, but we still have a ref).
        if (field_13987.field_14140.method_14208()) {
            field_13987.field_14140.method_14240();
        }
        return field_13987.field_14140;
    }
}
