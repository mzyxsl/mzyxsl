package carpet.patches;

import carpet.fakes.ClientConnectionInterface;
import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2598;
import net.minecraft.class_9127;

public class FakeClientConnection extends class_2535
{
    public FakeClientConnection(class_2598 p)
    {
        super(p);
        // compat with adventure-platform-fabric. This does NOT trigger other vanilla handlers for establishing a channel
        // also makes #isOpen return true, allowing enderpearls to teleport fake players
        ((ClientConnectionInterface)this).setChannel(new EmbeddedChannel());
    }

    @Override
    public void method_10757()
    {
    }

    @Override
    public void method_10768()
    {
    }

    @Override
    public void method_52912(class_2547 packetListener)
    {
    }

    @Override
    public <T extends class_2547> void method_56330(class_9127<T> protocolInfo, T packetListener)
    {
    }
}