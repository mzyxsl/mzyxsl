package carpet.logging;

import carpet.CarpetServer;
import carpet.helpers.HopperCounter;
import carpet.logging.logHelpers.PacketCounter;
import carpet.utils.Messenger;
import carpet.utils.SpawnReporter;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_2772;
import net.minecraft.class_3222;
import net.minecraft.class_4802;
import net.minecraft.class_5321;
import net.minecraft.class_8915;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;

public class HUDController
{
    private static final List<Consumer<MinecraftServer>> HUDListeners = new ArrayList<>();

    /**
     * Adds listener to be called when HUD is updated for logging information
     * @param listener - a method to be called when new HUD inforation are collected
     */
    public static void register(Consumer<MinecraftServer> listener)
    {
        HUDListeners.add(listener);
    }

    public static final Map<class_3222, List<class_2561>> player_huds = new HashMap<>();
//keyed with player names so unlogged players don't hold the reference
    public static final Map<String, class_2561> scarpet_headers = new HashMap<>();

    public static final Map<String, class_2561> scarpet_footers = new HashMap<>();

    public static void resetScarpetHUDs() {
        scarpet_headers.clear();
        scarpet_footers.clear();
    }

    public static void addMessage(class_3222 player, class_2561 hudMessage)
    {
        if (player == null) return;
        if (!player_huds.containsKey(player))
        {
            player_huds.put(player, new ArrayList<>());
        }
        else
        {
            player_huds.get(player).add(class_2561.method_43470("\n"));
        }
        player_huds.get(player).add(hudMessage);
    }

    public static void clearPlayer(class_3222 player)
    {
        class_2772 packet = new class_2772(class_2561.method_43470(""), class_2561.method_43470(""));
        player.field_13987.method_14364(packet);
    }


    public static void update_hud(MinecraftServer server, List<class_3222> force)
    {
        if (((server.method_3780() % 20 != 0) && force == null) || CarpetServer.minecraft_server == null)
            return;

        player_huds.clear();

        server.method_3760().method_14571().forEach(p -> {
            class_2561 scarpetFOoter = scarpet_footers.get(p.method_5820());
            if (scarpetFOoter != null) HUDController.addMessage(p, scarpetFOoter);
        });

        if (LoggerRegistry.__tps)
            LoggerRegistry.getLogger("tps").log(()-> send_tps_display(server));

        if (LoggerRegistry.__mobcaps)
            LoggerRegistry.getLogger("mobcaps").log((option, player) -> {
                class_5321<class_1937> dim = switch (option) {
                    case "overworld" -> class_1937.field_25179;
                    case "nether" -> class_1937.field_25180;
                    case "end" -> class_1937.field_25181;
                    default -> player.method_37908().method_27983();
                };
                return new class_2561[]{SpawnReporter.printMobcapsForDimension(server.method_3847(dim), false).get(0)};
            });

        if(LoggerRegistry.__counter)
            LoggerRegistry.getLogger("counter").log((option)->send_counter_info(server, option));

        if (LoggerRegistry.__packets)
            LoggerRegistry.getLogger("packets").log(HUDController::packetCounter);

        // extensions have time to pitch in.
        HUDListeners.forEach(l -> l.accept(server));

        Set<class_3222> targets = new HashSet<>(player_huds.keySet());
        if (force!= null) targets.addAll(force);
        for (class_3222 player: targets)
        {
            class_2772 packet = new class_2772(
                        scarpet_headers.getOrDefault(player.method_5820(), class_2561.method_43470("")),
                        Messenger.c(player_huds.getOrDefault(player, List.of()).toArray(new Object[0]))
                    );
            player.field_13987.method_14364(packet);
        }
    }
    private static class_2561 [] send_tps_display(MinecraftServer server)
    {
        double MSPT = ((double)server.method_54834())/ class_4802.field_33869;
        class_8915 trm = server.method_54833();

        double TPS = 1000.0D / Math.max(trm.method_54670()?0.0:trm.method_54749(), MSPT);
        if (trm.method_54754()) {
            TPS = 0;
        }
        String color = Messenger.heatmap_color(MSPT,trm.method_54749());
        return new class_2561[]{Messenger.c(
                "g TPS: ", String.format(Locale.US, "%s %.1f",color, TPS),
                "g  MSPT: ", String.format(Locale.US,"%s %.1f", color, MSPT))};
    }

    private static class_2561[] send_counter_info(MinecraftServer server, String colors)
    {
        List <class_2561> res = new ArrayList<>();
        for (String color : colors.split(","))
        {
            HopperCounter counter = HopperCounter.getCounter(color);
            if (counter != null) res.addAll(counter.format(server, false, true));
        }
        return res.toArray(new class_2561[0]);
    }
    private static class_2561 [] packetCounter()
    {
        class_2561 [] ret =  new class_2561[]{
                Messenger.c("w I/" + PacketCounter.totalIn + " O/" + PacketCounter.totalOut),
        };
        PacketCounter.reset();
        return ret;
    }
}
