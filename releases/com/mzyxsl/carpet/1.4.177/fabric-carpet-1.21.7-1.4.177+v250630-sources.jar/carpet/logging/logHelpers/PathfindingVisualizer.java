package carpet.logging.logHelpers;

import carpet.helpers.ParticleDisplay;
import carpet.logging.LoggerRegistry;
import net.minecraft.class_1297;
import net.minecraft.class_2390;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3222;

public class PathfindingVisualizer
{
    public static void slowPath(class_1297 entity, class_243 target, float miliseconds, boolean successful)
    {
        if (!LoggerRegistry.__pathfinding) return;
        LoggerRegistry.getLogger("pathfinding").log( (option, player)->
        {
            if (!(player instanceof class_3222))
                return null;
            int minDuration;
            try
            {
                minDuration = Integer.parseInt(option);
            }
            catch (NumberFormatException ignored)
            {
                return  null;
            }
            if (miliseconds < minDuration)
                return null;
            if (player.method_5858(entity) > 1000 && player.method_5707(target) > 1000)
                return null;
            if (minDuration < 1)
                minDuration = 1;

            class_2394 accent = successful ? class_2398.field_11211 : class_2398.field_11231;
            class_2394 color = (miliseconds/minDuration < 2)? new class_2390(0xffffff00, 1) : ((miliseconds/minDuration < 4)?new class_2390(0xFFFF7700, 1): new class_2390(0xFFFF0000, 1));
            ParticleDisplay.drawParticleLine((class_3222) player, entity.method_19538(), target, color, accent, 5, 0.5);
            return null;
        });
    }
}
