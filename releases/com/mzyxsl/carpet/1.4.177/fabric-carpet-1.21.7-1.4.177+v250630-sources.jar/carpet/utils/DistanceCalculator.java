package carpet.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import net.minecraft.class_2168;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3532;

public class DistanceCalculator
{
    public static final HashMap<String, class_243> START_POINT_STORAGE = new HashMap<>();

    public static boolean hasStartingPoint(class_2168 source)
    {
        return START_POINT_STORAGE.containsKey(source.method_9214());
    }

    public static List<class_2561> findDistanceBetweenTwoPoints(class_243 pos1, class_243 pos2)
    {
        double dx = class_3532.method_15379((float)pos1.field_1352-(float)pos2.field_1352);
        double dy = class_3532.method_15379((float)pos1.field_1351-(float)pos2.field_1351);
        double dz = class_3532.method_15379((float)pos1.field_1350-(float)pos2.field_1350);
        double manhattan = dx+dy+dz;
        double spherical = Math.sqrt(dx*dx + dy*dy + dz*dz);
        double cylindrical = Math.sqrt(dx*dx + dz*dz);
        List<class_2561> res = new ArrayList<>();
        res.add(Messenger.c("w Distance between ",
                Messenger.tp("c",pos1),"w  and ",
                Messenger.tp("c",pos2),"w :"));
        res.add(Messenger.c("w  - Spherical: ", String.format("wb %.2f", spherical)));
        res.add(Messenger.c("w  - Cylindrical: ", String.format("wb %.2f", cylindrical)));
        res.add(Messenger.c("w  - Manhattan: ", String.format("wb %.1f", manhattan)));
        return res;
    }

    public static int distance(class_2168 source, class_243 pos1, class_243 pos2)
    {
        Messenger.send(source, findDistanceBetweenTwoPoints(pos1, pos2));
        return 1;
    }

    public static int setStart(class_2168 source, class_243 pos)
    {
        START_POINT_STORAGE.put(source.method_9214(), pos);
        Messenger.m(source,"gi Initial point set to: ", Messenger.tp("g",pos));
        return 1;
    }

    public static int setEnd(class_2168 source, class_243 pos)
    {
        if ( !hasStartingPoint(source) )
        {
            START_POINT_STORAGE.put(source.method_9214(), pos);
            Messenger.m(source,"gi There was no initial point for "+source.method_9214());
            Messenger.m(source,"gi Initial point set to: ", Messenger.tp("g",pos));
            return 0;
        }
        Messenger.send(source, findDistanceBetweenTwoPoints( START_POINT_STORAGE.get(source.method_9214()), pos));
        return 1;
    }
}
