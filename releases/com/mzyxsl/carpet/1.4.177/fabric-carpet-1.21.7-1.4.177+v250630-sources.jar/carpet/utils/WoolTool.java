package carpet.utils;

import carpet.CarpetSettings;
import carpet.helpers.HopperCounter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.class_1767;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

import static java.util.Map.entry;

/**
 * A series of utility functions and variables for dealing predominantly with hopper counters and determining which counter
 * to add their items to, as well as helping dealing with carpet functionality.
 */
public class WoolTool
{
    /**
     * A map from a wool {@link class_2248} to its {@link class_1767} which is used in {@link WoolTool#getWoolColorAtPosition}
     * to get the colour of wool at a position.
     */
    private static final Map<class_2248, class_1767> WOOL_BLOCK_TO_DYE = Map.ofEntries(
            entry(class_2246.field_10446, class_1767.field_7952),
            entry(class_2246.field_10095, class_1767.field_7946),
            entry(class_2246.field_10215, class_1767.field_7958),
            entry(class_2246.field_10294, class_1767.field_7951),
            entry(class_2246.field_10490, class_1767.field_7947),
            entry(class_2246.field_10028, class_1767.field_7961),
            entry(class_2246.field_10459, class_1767.field_7954),
            entry(class_2246.field_10423, class_1767.field_7944),
            entry(class_2246.field_10222, class_1767.field_7967),
            entry(class_2246.field_10619, class_1767.field_7955),
            entry(class_2246.field_10259, class_1767.field_7945),
            entry(class_2246.field_10514, class_1767.field_7966),
            entry(class_2246.field_10113, class_1767.field_7957),
            entry(class_2246.field_10170, class_1767.field_7942),
            entry(class_2246.field_10314, class_1767.field_7964),
            entry(class_2246.field_10146, class_1767.field_7963)
    );

    /**
     * The method which gets triggered when a player places a carpet, and decides what to do based on the carpet's colour:
     * <ul>
     *     <li>Red - Resets the counter of the colour of wool underneath the carpet (if there is no wool, then nothing happens)</li>
     *     <li>Green - Prints the contents of the counter of the colour of wool underneath the carpet</li>
     * </ul>
     */
    public static void carpetPlacedAction(class_1767 color, class_3222 placer, class_2338 pos, class_3218 worldIn)
    {
        if (!CarpetSettings.carpets)
        {
            return;
        }
        switch (color)
        {
            case field_7954:
                if (!"false".equals(CarpetSettings.commandSpawn))
                    Messenger.send(placer, SpawnReporter.report(pos, worldIn));

                break;
            case field_7963:
                if (!"false".equals(CarpetSettings.commandSpawn))
                    Messenger.send(placer, SpawnReporter.handleWoolAction(pos, worldIn));
                break;
            case field_7957:
                if (!"false".equals(CarpetSettings.commandDistance))
                {
                    class_2168 source = placer.method_64396();
                    if (!DistanceCalculator.hasStartingPoint(source) || placer.method_5715()) {
                        DistanceCalculator.setStart(source, class_243.method_24954(pos) ); // zero padded pos
                    }
                    else {
                        DistanceCalculator.setEnd(source, class_243.method_24954(pos));
                    }
                }
                break;
            case field_7944:
                if (!"false".equals(CarpetSettings.commandInfo))
                    Messenger.send(placer, BlockInfo.blockInfo(pos.method_10074(), worldIn));
                break;
            case field_7942:
                if (CarpetSettings.hopperCounters)
                {
                    class_1767 under = getWoolColorAtPosition(worldIn, pos.method_10074());
                    if (under == null) return;
                    HopperCounter counter = HopperCounter.getCounter(under);
                    Messenger.send(placer, counter.format(worldIn.method_8503(), false, false));
                }
                break;
            case field_7964:
                if (CarpetSettings.hopperCounters)
                {
                    class_1767 under = getWoolColorAtPosition(worldIn, pos.method_10074());
                    if (under == null) return;
                    HopperCounter counter = HopperCounter.getCounter(under);
                    counter.reset(placer.method_5682());
                    List<class_2561> res = new ArrayList<>();
                    res.add(Messenger.s(String.format("%s counter reset",under.toString())));
                    Messenger.send(placer, res);
                }
                break;
        }
    }

    /**
     * Gets the colour of wool at the position, for hoppers to be able to decide whether to add their items to the global counter.
     */
    @Nullable
    public static class_1767 getWoolColorAtPosition(class_1937 worldIn, class_2338 pos)
    {
        class_2680 state = worldIn.method_8320(pos);
        return WOOL_BLOCK_TO_DYE.get(state.method_26204());
    }
}
