package carpet.utils;

import carpet.CarpetSettings;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import it.unimi.dsi.fastutil.objects.Object2LongOpenHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1311;
import net.minecraft.class_1317;
import net.minecraft.class_1767;
import net.minecraft.class_1937;
import net.minecraft.class_1948;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2794;
import net.minecraft.class_2902;
import net.minecraft.class_3108;
import net.minecraft.class_3218;
import net.minecraft.class_3341;
import net.minecraft.class_3481;
import net.minecraft.class_3532;
import net.minecraft.class_3701;
import net.minecraft.class_3730;
import net.minecraft.class_5138;
import net.minecraft.class_5321;
import net.minecraft.class_5483;
import net.minecraft.class_5575;
import net.minecraft.class_6010;
import net.minecraft.class_6012;
import net.minecraft.class_6880;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.Nullable;

import static net.minecraft.class_1311.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class SpawnReporter
{
    private static final class_1311[] CACHED_MOBCATEGORY_VALUES = class_1311.values();
    public static boolean mockSpawns = false;

    public static final HashMap<class_5321<class_1937>, Integer> chunkCounts = new HashMap<>();

    public static final HashMap<Pair<class_5321<class_1937>, class_1311>, Object2LongOpenHashMap<class_1299<?>>> spawn_stats = new HashMap<>();
    public static double mobcap_exponent = 0.0D;
    
    public static final Object2LongOpenHashMap<Pair<class_5321<class_1937>, class_1311>> spawn_attempts = new Object2LongOpenHashMap<>();
    public static final Object2LongOpenHashMap<Pair<class_5321<class_1937>, class_1311>> overall_spawn_ticks = new Object2LongOpenHashMap<>();
    public static final Object2LongOpenHashMap<Pair<class_5321<class_1937>, class_1311>> spawn_ticks_full = new Object2LongOpenHashMap<>();
    public static final Object2LongOpenHashMap<Pair<class_5321<class_1937>, class_1311>> spawn_ticks_fail = new Object2LongOpenHashMap<>();
    public static final Object2LongOpenHashMap<Pair<class_5321<class_1937>, class_1311>> spawn_ticks_succ = new Object2LongOpenHashMap<>();
    public static final Object2LongOpenHashMap<Pair<class_5321<class_1937>, class_1311>> spawn_ticks_spawns = new Object2LongOpenHashMap<>();
    public static final Object2LongOpenHashMap<Pair<class_5321<class_1937>, class_1311>> spawn_cap_count = new Object2LongOpenHashMap<>();
    public static final HashMap<Pair<class_5321<class_1937>, class_1311>, EvictingQueue<Pair<class_1299<?>, class_2338>>> spawned_mobs = new HashMap<>();
    public static final HashMap<class_1311, Integer> spawn_tries = new HashMap<>();

    private static int spawnTrackingStartTime = 0;
    private static class_3341 trackedSpawningArea = null;
    // in case game gets each thread for each world - these need to belong to workd.
    public static Object2LongOpenHashMap<class_1311> local_spawns = null; // per world
    public static HashSet<class_1311> first_chunk_marker = null;

    public static void registerSpawn(class_1308 mob, class_1311 cat, class_2338 pos)
    {
        if (trackedSpawningArea != null && !trackedSpawningArea.method_14662(pos))
        {
            return;
        }
        Pair<class_5321<class_1937>, class_1311> key = Pair.of(mob.method_37908().method_27983(), cat);
        spawn_stats.get(key).addTo(mob.method_5864(), 1);
        spawned_mobs.get(key).put(Pair.of(mob.method_5864(), pos));
        if (!local_spawns.containsKey(cat))
        {
            CarpetSettings.LOG.error("Rogue spawn detected for category "+cat.method_6133()+" for mob "+mob.method_5864().method_5897().getString()+". If you see this message let carpet peeps know about it on github issues.");
            local_spawns.put(cat, 0L);
        }
        local_spawns.addTo(cat, 1);
    }

    public static final int MAGIC_NUMBER = (int)Math.pow(17.0D, 2.0D);
    /*public static double currentMagicNumber()
    {
        return MAGIC_NUMBER / (Math.pow(2.0,(SpawnReporter.mobcap_exponent/4)));
    }*/

    public static List<class_2561> printMobcapsForDimension(class_3218 world, boolean multiline)
    {
        class_5321<class_1937> dim = world.method_27983();
        String name = dim.method_29177().method_12832();
        List<class_2561> lst = new ArrayList<>();
        if (multiline)
            lst.add(Messenger.s(String.format("Mobcaps for %s:",name)));
        class_1948.class_5262 lastSpawner = world.method_14178().method_27908();
        Object2IntMap<class_1311> dimCounts = lastSpawner.method_27830();
        int chunkcount = chunkCounts.getOrDefault(dim, -1);
        if (dimCounts == null || chunkcount < 0)
        {
            lst.add(Messenger.c("g   --UNAVAILABLE--"));
            return lst;
        }

        List<String> shortCodes = new ArrayList<>();
        for (class_1311 category : cachedMobCategories())
        {
            int cur = dimCounts.getOrDefault(category, -1);
            int max = (int)(chunkcount * ((double)category.method_6134() / MAGIC_NUMBER)); // from ServerChunkManager.CHUNKS_ELIGIBLE_FOR_SPAWNING
            String color = Messenger.heatmap_color(cur, max);
            String mobColor = Messenger.creatureTypeColor(category);
            if (multiline)
            {
                int rounds = spawn_tries.get(category);
                lst.add(Messenger.c(String.format("w   %s: ", category.method_6133()),
                        (cur < 0) ? "g -" : (color + " " + cur), "g  / ", mobColor + " " + max,
                        (rounds == 1) ? "w " : String.format("gi  (%d rounds/tick)", spawn_tries.get(category))
                ));
            }
            else
            {
                shortCodes.add(color+" "+((cur<0)?"-":cur));
                shortCodes.add("g /");
                shortCodes.add(mobColor+" "+max);
                shortCodes.add("g ,");
            }
        }
        if (!multiline)
        {
            if (shortCodes.size() > 0)
            {
                shortCodes.remove(shortCodes.size() - 1);
                lst.add(Messenger.c(shortCodes.toArray(new Object[0])));
            }
            else
            {
                lst.add(Messenger.c("g   --UNAVAILABLE--"));
            }

        }
        return lst;
    }
    
    public static List<class_2561> getRecentSpawns(class_1937 world, class_1311 category)
    {
        List<class_2561> lst = new ArrayList<>();
        if (!trackingSpawns())
        {
            lst.add(Messenger.s("Spawn tracking not started"));
            return lst;
        }
        String categoryName = category.method_6133();
        
        lst.add(Messenger.s(String.format("Recent %s spawns:", categoryName)));
        for (Pair<class_1299<?>, class_2338> pair : spawned_mobs.get(Pair.of(world.method_27983(), category)).keySet())
        {
            lst.add( Messenger.c(
                    "w  - ",
                    Messenger.tp("wb",pair.getRight()),
                    String.format("w : %s", pair.getLeft().method_5897().getString())
                    ));
        }
        
        if (lst.size() == 1)
        {
            lst.add(Messenger.s(" - Nothing spawned yet, sorry."));
        }
        return lst;

    }
    
    public static List<class_2561> handleWoolAction(class_2338 pos, class_3218 worldIn)
    {
        class_1767 under = WoolTool.getWoolColorAtPosition(worldIn, pos.method_10074());
        if (under == null)
        {
            if (trackingSpawns())
            {
                return makeTrackingReport(worldIn);
            }
            else
            {
                return printMobcapsForDimension(worldIn, true );
            }
        }
        class_1311 category = getCategoryFromWoolColor(under);
        if (category != null)
        {
            if (trackingSpawns())
            {
                return getRecentSpawns(worldIn, category);
            }
            else
            {
                return printEntitiesByType(category, worldIn, true);
                
            }
            
        }
        if (trackingSpawns())
        {
            return makeTrackingReport(worldIn);
        }
        else
        {
            return printMobcapsForDimension(worldIn, true );
        }
        
    }
    
    public static class_1311 getCategoryFromWoolColor(class_1767 color)
    {
        return switch (color)
        {
            case field_7964   -> field_6302;
            case field_7942 -> field_6294;
            case field_7966  -> field_6300;
            case field_7957 -> field_6303;
            case field_7955  -> field_24460;
            default    -> null;
        };
    }
    
    public static List<class_2561> printEntitiesByType(class_1311 cat, class_3218 worldIn, boolean all)
    {
        List<class_2561> lst = new ArrayList<>();
        lst.add( Messenger.s(String.format("Loaded entities for %s category:", cat)));
        for (class_1297 entity : worldIn.method_18198(class_5575.method_31795(class_1297.class), (e) -> e.method_5864().method_5891() == cat))
        {
            boolean persistent = entity instanceof class_1308 mob && ( mob.method_5947() || mob.method_17326());
            if (!all && persistent)
                continue;

            class_1299<?> type = entity.method_5864();
            class_2338 pos = entity.method_24515();
            lst.add( Messenger.c(
                    "w  - ",
                    Messenger.tp(persistent ? "gb" : "wb", pos),
                    String.format(persistent ? "g : %s" : "w : %s", type.method_5897().getString())
            ));

        }
        if (lst.size() == 1)
        {
            lst.add(Messenger.s(" - Empty."));
        }
        return lst;
    }
    
    public static void initializeMocking()
    {
        mockSpawns = true;
    }
    public static void stopMocking()
    {
        mockSpawns = false;
    }

    public static void resetSpawnStats(MinecraftServer server, boolean full)
    {
        if (full)
        {
            for (class_1311 category : cachedMobCategories())
                spawn_tries.put(category, 1);
        }
        overall_spawn_ticks.clear();
        spawn_attempts.clear();
        spawn_ticks_full.clear();
        spawn_ticks_fail.clear();
        spawn_ticks_succ.clear();
        spawn_ticks_spawns.clear();
        spawn_cap_count.clear();

        // can't fast-path to clear given different worlds could have different amount of worlds
        for (class_1311 category : cachedMobCategories()) {
            for (class_5321<class_1937> world : server.method_29435()) {
                Pair<class_5321<class_1937>, class_1311> key = Pair.of(world, category);
                spawn_stats.put(key, new Object2LongOpenHashMap<>());
                spawned_mobs.put(key, new EvictingQueue<>());
            }
        }
        spawnTrackingStartTime = 0;
    }

    public static class_1311[] cachedMobCategories() {
        return CACHED_MOBCATEGORY_VALUES;
    }

    public static boolean trackingSpawns() {
        return spawnTrackingStartTime != 0L;
    }

    public static void startTracking(MinecraftServer server, class_3341 trackedArea) {
        resetSpawnStats(server, false);
        spawnTrackingStartTime = server.method_3780();
        trackedSpawningArea = trackedArea;
    }

    public static void stopTracking(MinecraftServer server) {
        resetSpawnStats(server, false);
        SpawnReporter.spawnTrackingStartTime = 0;
        trackedSpawningArea = null;
    }

    private static String getWorldCode(class_5321<class_1937> world)
    {
        if (world == class_1937.field_25179) return "";
        return "("+Character.toUpperCase(world.method_29177().method_12832().charAt("THE_".length()))+")";
    }
    
    public static List<class_2561> makeTrackingReport(class_1937 worldIn)
    {
        List<class_2561> report = new ArrayList<>();
        if (!trackingSpawns())
        {
            report.add(Messenger.c(
                    "w Spawn tracking is disabled, type '",
                    "wi /spawn tracking start","/spawn tracking start",
                    "w ' to enable"));
            return report;
        }
        int duration = worldIn.method_8503().method_3780() - spawnTrackingStartTime;
        report.add(Messenger.c("bw --------------------"));
        String simulated = mockSpawns ? "[SIMULATED] " : "";
        String location = (trackedSpawningArea != null) ? String.format("[in (%d, %d, %d)x(%d, %d, %d)]",
                trackedSpawningArea.method_35415(), trackedSpawningArea.method_35416(), trackedSpawningArea.method_35417(),
                trackedSpawningArea.method_35418(), trackedSpawningArea.method_35419(), trackedSpawningArea.method_35420() ):"";
        report.add(Messenger.s(String.format("%sSpawn statistics %s: for %.1f min", simulated, location, (duration/72000.0)*60)));

        for (class_1311 category : cachedMobCategories())
        {
            for (class_5321<class_1937> dim : worldIn.method_8503().method_29435())
            {
                Pair<class_5321<class_1937>, class_1311> key = Pair.of(dim, category);
                if (spawn_ticks_spawns.getLong(key) > 0L)
                {
                    double hours = overall_spawn_ticks.getLong(key)/72000.0;
                    long spawnAttemptsForCategory = spawn_attempts.getLong(key);
                    report.add(Messenger.s(String.format(" > %s%s (%.1f min), %.1f m/t, %%{%.1fF %.1f- %.1f+}; %.2f s/att",
                        category.method_6133().substring(0,3), getWorldCode(dim),
                        60*hours,
                        (1.0D * spawn_cap_count.getLong(key)) / spawnAttemptsForCategory,
                        (100.0D * spawn_ticks_full.getLong(key)) / spawnAttemptsForCategory,
                        (100.0D * spawn_ticks_fail.getLong(key)) / spawnAttemptsForCategory,
                        (100.0D * spawn_ticks_succ.getLong(key)) / spawnAttemptsForCategory,
                        (1.0D * spawn_ticks_spawns.getLong(key)) / (spawn_ticks_fail.getLong(key) + spawn_ticks_succ.getLong(key))
                    )));
                    for (Object2LongMap.Entry<class_1299<?>> entry: spawn_stats.get(key).object2LongEntrySet())
                    {
                        report.add(Messenger.s(String.format("   - %s: %d spawns, %d per hour",
                                entry.getKey().method_5897().getString(),
                                entry.getLongValue(),
                                (72000 * entry.getLongValue()/duration ))));
                    }
                }
            }
        }
        return report;
    }

    public static void killEntity(class_1309 entity)
    {
        if (entity.method_5765())
        {
            entity.method_5854().method_31472();
        }
        if (entity.method_5782())
        {
            for (class_1297 e: entity.method_5685())
            {
                e.method_31472();
            }
        }
        if (entity instanceof class_3701)
        {
            for (class_1297 e: entity.method_37908().method_8335(entity, entity.method_5829()))
            {
                e.method_31472();
            }
        }
        entity.method_31472();
    }

    // yeeted from NaturalSpawner - temporary access fix
    private static class_6012<class_5483.class_1964> getSpawnEntries(class_3218 serverLevel, class_5138 structureManager, class_2794 chunkGenerator, class_1311 mobCategory, class_2338 blockPos, @Nullable class_6880<class_1959> holder) {
        return class_1948.method_38091(blockPos, serverLevel, mobCategory, structureManager) ? class_3108.field_13705 : chunkGenerator.method_12113(holder != null ? holder : serverLevel.method_23753(blockPos), structureManager, mobCategory, blockPos);
    }

    public static List<class_2561> report(class_2338 pos, class_3218 worldIn)
    {
        List<class_2561> rep = new ArrayList<>();
        int x = pos.method_10263();
        int y = pos.method_10264();
        int z = pos.method_10260();
        class_2791 chunk = worldIn.method_22350(pos);
        int lc = chunk.method_12005(class_2902.class_2903.field_13202, x, z) + 1;
        String relativeHeight = (y == lc) ? "right at it." : String.format("%d blocks %s it.", class_3532.method_15382(y - lc), (y >= lc) ? "above" : "below");
        rep.add(Messenger.s(String.format("Maximum spawn Y value for (%+d, %+d) is %d. You are " + relativeHeight, x, z, lc)));
        rep.add(Messenger.s("Spawns:"));
        for (class_1311 category : cachedMobCategories())
        {
            String categoryCode = String.valueOf(category).substring(0, 3);
            class_6012<class_5483.class_1964> lst = getSpawnEntries(worldIn, worldIn.method_27056(), worldIn.method_14178().method_12129(), category, pos, worldIn.method_23753(pos));
            if (lst != null && !lst.method_34993())
            {
                for (class_6010<class_5483.class_1964> wspawnEntry : lst.method_34994())
                {
                    class_5483.class_1964 spawnEntry = wspawnEntry.comp_2542();
                    if (class_1317.method_6159(spawnEntry.comp_3488()) == null)
                        continue; // vanilla bug
                    boolean canSpawn = class_1317.method_56558(spawnEntry.comp_3488(), worldIn, pos);
                    int willSpawn = -1;
                    boolean fits = false;
                    
                    class_1308 mob;
                    try
                    {
                        mob = (class_1308) spawnEntry.comp_3488().method_5883(worldIn, class_3730.field_16459);
                    }
                    catch (Exception e)
                    {
                        CarpetSettings.LOG.warn("Exception while creating mob for spawn reporter", e);
                        return rep;
                    }
                    
                    if (canSpawn)
                    {
                        willSpawn = 0;
                        for (int attempt = 0; attempt < 50; ++attempt)
                        {
                            float f = x + 0.5F;
                            float f1 = z + 0.5F;
                            mob.method_5808(f, y, f1, worldIn.field_9229.method_43057() * 360.0F, 0.0F);
                            fits = worldIn.method_17892(mob);
                            class_1299<?> etype = mob.method_5864();

                            for (int i = 0; i < 20; ++i)
                            {
                                if (
                                        class_1317.method_20638(etype,worldIn, class_3730.field_16459, pos, worldIn.field_9229) &&
                                        class_1317.method_56558(etype, worldIn, pos) &&
                                        mob.method_5979(worldIn, class_3730.field_16459)
                                    // && mob.canSpawn(worldIn) // entity collisions // mostly - except ocelots
                                )
                                {
                                    if (etype == class_1299.field_6081)
                                    {
                                        class_2680 blockState = worldIn.method_8320(pos.method_10074());
                                        if ((pos.method_10264() < worldIn.method_8615()) || !(blockState.method_27852(class_2246.field_10219) || blockState.method_26164(class_3481.field_15503))) {
                                           continue;
                                        }
                                    }
                                    willSpawn += 1;
                                }
                            }
                            mob.method_5943(worldIn, worldIn.method_8404(mob.method_24515()), class_3730.field_16459, null);
                            // the code invokes onInitialSpawn after getCanSpawHere
                            fits = fits && worldIn.method_17892(mob);
                            
                            killEntity(mob);
                            
                            try
                            {
                                mob = (class_1308) spawnEntry.comp_3488().method_5883(worldIn, class_3730.field_16459);
                            }
                            catch (Exception e)
                            {
                                CarpetSettings.LOG.warn("Exception while creating mob for spawn reporter", e);
                                return rep;
                            }
                        }
                    }
                    
                    String mobTypeName = mob.method_5864().method_5897().getString();
                    //String pack_size = Integer.toString(mob.getMaxSpawnClusterSize());//String.format("%d-%d", animal.minGroupCount, animal.maxGroupCount);
                    int weight = wspawnEntry.comp_2543();
                    if (canSpawn)
                    {
                        String color = (fits && willSpawn > 0) ? "e" : "gi";
                        rep.add(Messenger.c(
                                String.format("%s %s: %s (%d:%d-%d/%d), can: ", color, categoryCode, mobTypeName, weight, spawnEntry.comp_3489(), spawnEntry.comp_3490(),  mob.method_5945()),
                                "l YES",
                                color + " , fit: ",
                                (fits ? "l YES" : "r NO"),
                                color + " , will: ",
                                ((willSpawn > 0)?"l ":"r ") + Math.round((double)willSpawn) / 10 + "%"
                        ));
                    }
                    else
                    {
                        rep.add(Messenger.c(String.format("gi %s: %s (%d:%d-%d/%d), can: ", categoryCode, mobTypeName, weight, spawnEntry.comp_3489(), spawnEntry.comp_3490(), mob.method_5945()), "n NO"));
                    }
                    killEntity(mob);
                }
            }
        }
        return rep;
    }
}
