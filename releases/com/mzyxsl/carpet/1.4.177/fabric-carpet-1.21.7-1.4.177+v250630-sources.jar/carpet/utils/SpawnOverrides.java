package carpet.utils;

import carpet.CarpetSettings;
import it.unimi.dsi.fastutil.longs.LongSet;
import org.apache.commons.lang3.tuple.Pair;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2338;
import net.minecraft.class_2806;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_3449;
import net.minecraft.class_4076;
import net.minecraft.class_5138;
import net.minecraft.class_5321;
import net.minecraft.class_5483;
import net.minecraft.class_6012;
import net.minecraft.class_7058;
import net.minecraft.class_7061;
import net.minecraft.class_7151;
import net.minecraft.class_7924;

public class SpawnOverrides {
    final private static Map<Pair<class_1311, class_5321<class_3195>>, Pair<BooleanSupplier, class_7061>> carpetOverrides = new HashMap<>();

    static {
        addOverride(() -> CarpetSettings.huskSpawningInTemples, class_1311.field_6302, class_7058.field_37173, class_7061.class_7062.field_37200,
                class_6012.method_66214(new class_5483.class_1964(class_1299.field_6071, 1, 1))
        );
        addOverride(() -> CarpetSettings.shulkerSpawningInEndCities, class_1311.field_6302, class_7058.field_37184, class_7061.class_7062.field_37199,
                class_6012.method_66214(new class_5483.class_1964(class_1299.field_6109, 4, 4))
        );
        addOverride(() -> CarpetSettings.piglinsSpawningInBastions, class_1311.field_6302, class_7058.field_37186, class_7061.class_7062.field_37199,
                class_6012.<class_5483.class_1964>method_66215()
                        .method_34975(new class_5483.class_1964(class_1299.field_25751,1, 2), 5)
                        .method_34975(new class_5483.class_1964(class_1299.field_22281, 2, 4), 10)
                        .method_34975(new class_5483.class_1964(class_1299.field_21973, 1, 2), 2)
                        .method_34974()
        );

    }

    public static void addOverride(BooleanSupplier when, class_1311 cat, class_5321<class_3195> poo,
                                   class_7061.class_7062 type, class_6012<class_5483.class_1964> spawns) {
        carpetOverrides.put(Pair.of(cat, poo), Pair.of(when, new class_7061(type, spawns)));
    }

    public static class_6012<class_5483.class_1964> test(class_5138 structureFeatureManager, LongSet foo,
                                                                  class_1311 cat, class_3195 confExisting, class_2338 where) {
        class_2960 resource = structureFeatureManager.method_41036().method_30530(class_7924.field_41246).method_10221(confExisting);
        class_5321<class_3195> key = class_5321.method_29179(class_7924.field_41246, resource);
        final Pair<BooleanSupplier, class_7061> spawnData = carpetOverrides.get(Pair.of(cat, key));
        if (spawnData == null || !spawnData.getKey().getAsBoolean()) return null;
        class_7061 override = spawnData.getRight();
        if (override.comp_514() == class_7061.class_7062.field_37200) {
            if (structureFeatureManager.method_28388(where, confExisting).method_16657())
                return override.comp_515();
        } else {
            List<class_3449> starts = new ArrayList<>(1);
            structureFeatureManager.method_41032(confExisting, foo, starts::add);
            for (class_3449 start : starts) {
                if (start != null && start.method_16657() && structureFeatureManager.method_41033(where, start)) {
                    return override.comp_515();
                }
            }
        }
        return null;
    }

    public static boolean isStructureAtPosition(class_3218 level, class_5321<class_3195> structureKey, class_2338 pos)
    {
        final class_3195 fortressFeature = level.method_30349().method_30530(class_7924.field_41246).method_29107(structureKey);
        if (fortressFeature == null) {
            return false;
        }
        return level.method_27056().method_28388(pos, fortressFeature).method_16657();
    }

    public static List<class_3449> startsForFeature(class_3218 level, class_4076 sectionPos, class_7151<?> structure) {
        Map<class_3195, LongSet> allrefs = level.method_22342(sectionPos.method_18674(), sectionPos.method_18687(), class_2806.field_16422).method_12179();
        List<class_3449> result = new ArrayList<>();
        for (var entry: allrefs.entrySet())
        {
            class_3195 existing = entry.getKey();
            if (existing.method_41618() == structure)
            {
                level.method_27056().method_41032(existing, entry.getValue(), result::add);
            }
        }
        return result;
    }
}
