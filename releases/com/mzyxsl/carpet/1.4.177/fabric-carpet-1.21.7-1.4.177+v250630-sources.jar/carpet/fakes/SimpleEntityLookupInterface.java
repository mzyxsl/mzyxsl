package carpet.fakes;

import java.util.List;
import net.minecraft.class_1923;
import net.minecraft.class_5568;

public interface SimpleEntityLookupInterface<T extends class_5568>
{
    List<T> getChunkEntities(class_1923 chpos);
}
