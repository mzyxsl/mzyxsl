package carpet.fakes;

import net.minecraft.class_1297;
import net.minecraft.class_5268;
import net.minecraft.class_5577;

public interface ServerWorldInterface {
    class_5268 getWorldPropertiesCM();
    class_5577<class_1297> getEntityLookupCMPublic();
}
