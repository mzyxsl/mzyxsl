package carpet.fakes;

import java.util.Random;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5819;

public interface CoralFeatureInterface
{
    boolean growSpecific(class_1937 worldIn, class_5819 random, class_2338 pos, class_2680 blockUnder);
}
