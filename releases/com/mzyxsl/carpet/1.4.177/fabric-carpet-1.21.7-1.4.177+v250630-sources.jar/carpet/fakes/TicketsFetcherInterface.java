package carpet.fakes;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.util.List;
import net.minecraft.class_3228;

public interface TicketsFetcherInterface
{
    Long2ObjectOpenHashMap<List<class_3228>> getTicketsByPosition();
}
