package carpet.fakes;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public interface PistonBlockInterface
{
    boolean publicShouldExtend(class_1937 world_1, class_2338 blockPos_1, class_2350 direction_1);
}
