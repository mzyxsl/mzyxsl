package carpet.fakes;

import net.minecraft.class_2535;

public interface ServerGamePacketListenerImplInterface {
    class_2535 getConnection();
}
