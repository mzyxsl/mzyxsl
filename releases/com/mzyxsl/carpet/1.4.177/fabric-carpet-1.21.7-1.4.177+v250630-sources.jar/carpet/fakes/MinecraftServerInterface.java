package carpet.fakes;

import java.util.Map;
import java.util.function.BooleanSupplier;
import carpet.script.CarpetScriptServer;
import net.minecraft.class_1937;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.server.MinecraftServer;

public interface MinecraftServerInterface
{
    void forceTick(BooleanSupplier sup);
    class_32.class_5143 getCMSession();
    Map<class_5321<class_1937>, class_3218> getCMWorlds();
    void reloadAfterReload(class_5455 newRegs);

    MinecraftServer.class_6897 getResourceManager();

    void addScriptServer(CarpetScriptServer scriptServer);
    CarpetScriptServer getScriptServer();
}
