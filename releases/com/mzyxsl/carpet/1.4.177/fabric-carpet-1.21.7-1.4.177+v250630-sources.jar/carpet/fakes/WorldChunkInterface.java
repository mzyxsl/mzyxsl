package carpet.fakes;

import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public interface WorldChunkInterface
{
    class_2680 setBlockStateWithBlockEntity(class_2338 blockPos, class_2680 newBlockState, class_2586 newBlockEntity, int flags);
}
