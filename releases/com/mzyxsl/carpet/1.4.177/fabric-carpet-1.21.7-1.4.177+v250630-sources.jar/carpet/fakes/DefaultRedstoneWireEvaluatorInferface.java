package carpet.fakes;

import net.minecraft.class_1937;
import net.minecraft.class_2338;


public interface DefaultRedstoneWireEvaluatorInferface
{
    int calculateTargetStrengthCM(final class_1937 level, final class_2338 pos);
}
