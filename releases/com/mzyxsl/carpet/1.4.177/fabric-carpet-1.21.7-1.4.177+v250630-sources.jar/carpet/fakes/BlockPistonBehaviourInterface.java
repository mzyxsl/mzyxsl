package carpet.fakes;

import carpet.mixins.PistonStructureResolver_customStickyMixin;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2674;
import net.minecraft.class_2680;

/**
 * Opt-in Interface that allows for more control on a blocks interaction within the {@link class_2674} via {@link PistonStructureResolver_customStickyMixin}
 */
public interface BlockPistonBehaviourInterface {

    /**
     * @return whether this block is sticky in any way when moved by pistons
     */
    boolean isSticky(class_2680 state);

    /**
     * @return whether the neighboring block is pulled along if this block is moved by pistons
     */
    boolean isStickyToNeighbor(class_1937 level, class_2338 pos, class_2680 state, class_2338 neighborPos, class_2680 neighborState, class_2350 dir, class_2350 moveDir);
}
