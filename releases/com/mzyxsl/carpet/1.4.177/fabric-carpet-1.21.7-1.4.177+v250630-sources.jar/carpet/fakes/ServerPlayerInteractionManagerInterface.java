package carpet.fakes;

import net.minecraft.class_2338;

public interface ServerPlayerInteractionManagerInterface
{
    class_2338 getCurrentBreakingBlock();

    int getCurrentBlockBreakingProgress();

    void setBlockBreakingProgress(int progress);
}
