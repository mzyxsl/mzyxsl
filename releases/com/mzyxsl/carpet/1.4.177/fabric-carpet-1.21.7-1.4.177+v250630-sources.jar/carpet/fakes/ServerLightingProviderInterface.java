package carpet.fakes;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1923;
import net.minecraft.class_2791;

public interface ServerLightingProviderInterface
{
    void invokeUpdateChunkStatus(class_1923 pos);

    void removeLightData(class_2791 chunk);

    CompletableFuture<Void> relight(class_2791 chunk);

    void resetLight(class_2791 chunk, class_1923 pos);
}
