package carpet.fakes;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_7165;

public interface LevelInterface
{
    Map<class_1299<?>, class_1297> getPrecookedMobs();
    
    boolean setBlockStateWithBlockEntity(class_2338 blockPos, class_2680 blockState, class_2586 newBlockEntity, int int1);

    List<class_1297> getOtherEntitiesLimited(@Nullable class_1297 except, class_238 box, Predicate<? super class_1297> predicate, int limit);

    class_7165 getNeighborUpdater();
}
