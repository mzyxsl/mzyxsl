package carpet.helpers;

import net.minecraft.class_2394;
import net.minecraft.class_243;
import net.minecraft.class_3222;

public class ParticleDisplay
{
    public static void drawParticleLine(class_3222 player, class_243 from, class_243 to, class_2394 mainParticle, class_2394 accentParticle, int count, double spread)
    {

        if (accentParticle != null) player.method_51469().method_14166(
                player,
                accentParticle,
                true, true,
                to.field_1352, to.field_1351, to.field_1350, count,
                spread, spread, spread, 0.0);

        double lineLengthSq = from.method_1025(to);
        if (lineLengthSq == 0) return;

        class_243 incvec = to.method_1020(from).method_1029();//    multiply(50/sqrt(lineLengthSq));
        for (class_243 delta = new class_243(0.0,0.0,0.0);
             delta.method_1027() < lineLengthSq;
             delta = delta.method_1019(incvec.method_1021(player.method_51469().field_9229.method_43057())))
        {
            player.method_51469().method_14166(
                    player,
                    mainParticle,
                    true, true,
                    delta.field_1352+from.field_1352, delta.field_1351+from.field_1351, delta.field_1350+from.field_1350, 1,
                    0.0, 0.0, 0.0, 0.0);
        }
    }

}
