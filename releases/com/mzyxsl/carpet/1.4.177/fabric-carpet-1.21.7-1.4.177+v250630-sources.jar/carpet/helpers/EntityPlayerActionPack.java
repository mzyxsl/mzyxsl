package carpet.helpers;

import carpet.fakes.ServerPlayerInterface;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1496;
import net.minecraft.class_1533;
import net.minecraft.class_1661;
import net.minecraft.class_1690;
import net.minecraft.class_1695;
import net.minecraft.class_1799;
import net.minecraft.class_2183;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2735;
import net.minecraft.class_2846;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import carpet.patches.EntityPlayerMPFake;
import carpet.script.utils.Tracer;

public class EntityPlayerActionPack
{
    private final class_3222 player;

    private final Map<ActionType, Action> actions = new EnumMap<>(ActionType.class);

    private class_2338 currentBlock;
    private int blockHitDelay;
    private boolean isHittingBlock;
    private float curBlockDamageMP;

    private boolean sneaking;
    private boolean sprinting;
    private float forward;
    private float strafing;

    private int itemUseCooldown;

    public EntityPlayerActionPack(class_3222 playerIn)
    {
        player = playerIn;
        stopAll();
    }
    public void copyFrom(EntityPlayerActionPack other)
    {
        actions.putAll(other.actions);
        currentBlock = other.currentBlock;
        blockHitDelay = other.blockHitDelay;
        isHittingBlock = other.isHittingBlock;
        curBlockDamageMP = other.curBlockDamageMP;

        sneaking = other.sneaking;
        sprinting = other.sprinting;
        forward = other.forward;
        strafing = other.strafing;

        itemUseCooldown = other.itemUseCooldown;
    }

    public EntityPlayerActionPack start(ActionType type, Action action)
    {
        Action previous = actions.remove(type);
        if (previous != null) type.stop(player, previous);
        if (action != null)
        {
            actions.put(type, action);
            type.start(player, action); // noop
        }
        return this;
    }

    public EntityPlayerActionPack setSneaking(boolean doSneak)
    {
        sneaking = doSneak;
        player.method_5660(doSneak);
        if (sprinting && sneaking)
            setSprinting(false);
        return this;
    }
    public EntityPlayerActionPack setSprinting(boolean doSprint)
    {
        sprinting = doSprint;
        player.method_5728(doSprint);
        if (sneaking && sprinting)
            setSneaking(false);
        return this;
    }

    public EntityPlayerActionPack setForward(float value)
    {
        forward = value;
        return this;
    }
    public EntityPlayerActionPack setStrafing(float value)
    {
        strafing = value;
        return this;
    }
    public EntityPlayerActionPack look(class_2350 direction)
    {
        return switch (direction)
        {
            case field_11043 -> look(180, 0);
            case field_11035 -> look(0, 0);
            case field_11034  -> look(-90, 0);
            case field_11039  -> look(90, 0);
            case field_11036    -> look(player.method_36454(), -90);
            case field_11033  -> look(player.method_36454(), 90);
        };
    }
    public EntityPlayerActionPack look(class_241 rotation)
    {
        return look(rotation.field_1343, rotation.field_1342);
    }

    public EntityPlayerActionPack look(float yaw, float pitch)
    {
        player.method_36456(yaw % 360); //setYaw
        player.method_36457(class_3532.method_15363(pitch, -90, 90)); // setPitch
        // maybe player.moveTo(player.getX(), player.getY(), player.getZ(), yaw, Mth.clamp(pitch,-90.0F, 90.0F));
        return this;
    }

    public EntityPlayerActionPack lookAt(class_243 position)
    {
        player.method_5702(class_2183.class_2184.field_9851, position);
        return this;
    }

    public EntityPlayerActionPack turn(float yaw, float pitch)
    {
        return look(player.method_36454() + yaw, player.method_36455() + pitch);
    }

    public EntityPlayerActionPack turn(class_241 rotation)
    {
        return turn(rotation.field_1343, rotation.field_1342);
    }

    public EntityPlayerActionPack stopMovement()
    {
        setSneaking(false);
        setSprinting(false);
        forward = 0.0F;
        strafing = 0.0F;
        return this;
    }


    public EntityPlayerActionPack stopAll()
    {
        for (ActionType type : actions.keySet()) type.stop(player, actions.get(type));
        actions.clear();
        return stopMovement();
    }

    public EntityPlayerActionPack mount(boolean onlyRideables)
    {
        //test what happens
        List<class_1297> entities;
        if (onlyRideables)
        {
            entities = player.method_51469().method_8333(player, player.method_5829().method_1009(3.0D, 1.0D, 3.0D),
                    e -> e instanceof class_1695 || e instanceof class_1690 || e instanceof class_1496);
        }
            else
        {
            entities = player.method_51469().method_8335(player, player.method_5829().method_1009(3.0D, 1.0D, 3.0D));
        }
        if (entities.size()==0)
            return this;
        class_1297 closest = null;
        double distance = Double.POSITIVE_INFINITY;
        class_1297 currentVehicle = player.method_5854();
        for (class_1297 e: entities)
        {
            if (e == player || (currentVehicle == e))
                continue;
            double dd = player.method_5858(e);
            if (dd<distance)
            {
                distance = dd;
                closest = e;
            }
        }
        if (closest == null) return this;
        if (closest instanceof class_1496 && onlyRideables)
            ((class_1496) closest).method_5992(player, class_1268.field_5808);
        else
            player.method_5873(closest,true);
        return this;
    }
    public EntityPlayerActionPack dismount()
    {
        player.method_5848();
        return this;
    }

    public void onUpdate()
    {
        Map<ActionType, Boolean> actionAttempts = new HashMap<>();
        actions.values().removeIf(e -> e.done);
        for (Map.Entry<ActionType, Action> e : actions.entrySet())
        {
            ActionType type = e.getKey();
            Action action = e.getValue();
            // skipping attack if use was successful
            if (!(actionAttempts.getOrDefault(ActionType.USE, false) && type == ActionType.ATTACK))
            {
                Boolean actionStatus = action.tick(this, type);
                if (actionStatus != null)
                    actionAttempts.put(type, actionStatus);
            }
            // optionally retrying use after successful attack and unsuccessful use
            if (type == ActionType.ATTACK
                    && actionAttempts.getOrDefault(ActionType.ATTACK, false)
                    && !actionAttempts.getOrDefault(ActionType.USE, true) )
            {
                // according to MinecraftClient.handleInputEvents
                Action using = actions.get(ActionType.USE);
                if (using != null) // this is always true - we know use worked, but just in case
                {
                    using.retry(this, ActionType.USE);
                }
            }
        }
        float vel = sneaking?0.3F:1.0F;
        // The != 0.0F checks are needed given else real players can't control minecarts, however it works with fakes and else they don't stop immediately
        if (forward != 0.0F || player instanceof EntityPlayerMPFake) {
            player.field_6250 = forward * vel;
        }
        if (strafing != 0.0F || player instanceof EntityPlayerMPFake) {
            player.field_6212 = strafing * vel;
        }
    }

    static class_239 getTarget(class_3222 player)
    {
        double reach = player.field_13974.method_14268() ? 5 : 4.5f;
        return Tracer.rayTrace(player, 1, reach, false);
    }

    private void dropItemFromSlot(int slot, boolean dropAll)
    {
        class_1661 inv = player.method_31548(); // getInventory;
        if (!inv.method_5438(slot).method_7960())
            player.method_7329(inv.method_5434(slot,
                    dropAll ? inv.method_5438(slot).method_7947() : 1
            ), false, true); // scatter, keep owner
    }

    public void drop(int selectedSlot, boolean dropAll)
    {
        class_1661 inv = player.method_31548(); // getInventory;
        if (selectedSlot == -2) // all
        {
            for (int i = inv.method_5439(); i >= 0; i--)
                dropItemFromSlot(i, dropAll);
        }
        else // one slot
        {
            if (selectedSlot == -1)
                selectedSlot = inv.method_67532();
            dropItemFromSlot(selectedSlot, dropAll);
        }
    }

    public void setSlot(int slot)
    {
        player.method_31548().method_61496(slot-1);
        player.field_13987.method_14364(new class_2735(slot-1));
    }

    public enum ActionType
    {
        USE(true)
        {
            @Override
            boolean execute(class_3222 player, Action action)
            {
                EntityPlayerActionPack ap = ((ServerPlayerInterface) player).getActionPack();
                if (ap.itemUseCooldown > 0)
                {
                    ap.itemUseCooldown--;
                    return true;
                }
                if (player.method_6115())
                {
                    return true;
                }
                class_239 hit = getTarget(player);
                for (class_1268 hand : class_1268.values())
                {
                    switch (hit.method_17783())
                    {
                        case field_1332:
                        {
                            player.method_14234();
                            class_3218 world = player.method_51469();
                            class_3965 blockHit = (class_3965) hit;
                            class_2338 pos = blockHit.method_17777();
                            class_2350 side = blockHit.method_17780();
                            if (pos.method_10264() < player.method_51469().method_31600() - (side == class_2350.field_11036 ? 1 : 0) && world.method_8505(player, pos))
                            {
                                class_1269 result = player.field_13974.method_14262(player, world, player.method_5998(hand), hand, blockHit);
                                if (result instanceof class_1269.class_9860 success)
                                {
                                    if (success.comp_2909() == class_1269.class_9861.field_52428) player.method_6104(hand);
                                    ap.itemUseCooldown = 3;
                                    return true;
                                }
                            }
                            break;
                        }
                        case field_1331:
                        {
                            player.method_14234();
                            class_3966 entityHit = (class_3966) hit;
                            class_1297 entity = entityHit.method_17782();
                            boolean handWasEmpty = player.method_5998(hand).method_7960();
                            boolean itemFrameEmpty = (entity instanceof class_1533) && ((class_1533) entity).method_6940().method_7960();
                            class_243 relativeHitPos = entityHit.method_17784().method_1023(entity.method_23317(), entity.method_23318(), entity.method_23321());
                            if (entity.method_5664(player, relativeHitPos, hand).method_23665())
                            {
                                ap.itemUseCooldown = 3;
                                return true;
                            }
                            // fix for SS itemframe always returns CONSUME even if no action is performed
                            if (player.method_7287(entity, hand).method_23665() && !(handWasEmpty && itemFrameEmpty))
                            {
                                ap.itemUseCooldown = 3;
                                return true;
                            }
                            break;
                        }
                    }
                    class_1799 handItem = player.method_5998(hand);
                    if (player.field_13974.method_14256(player, player.method_51469(), handItem, hand).method_23665())
                    {
                        ap.itemUseCooldown = 3;
                        return true;
                    }
                }
                return false;
            }

            @Override
            void inactiveTick(class_3222 player, Action action)
            {
                EntityPlayerActionPack ap = ((ServerPlayerInterface) player).getActionPack();
                ap.itemUseCooldown = 0;
                player.method_6075();
            }
        },
        ATTACK(true) {
            @Override
            boolean execute(class_3222 player, Action action) {
                class_239 hit = getTarget(player);
                switch (hit.method_17783()) {
                    case field_1331: {
                        class_3966 entityHit = (class_3966) hit;
                        if (!action.isContinuous)
                        {
                            player.method_7324(entityHit.method_17782());
                            player.method_6104(class_1268.field_5808);
                        }
                        player.method_7350();
                        player.method_14234();
                        return true;
                    }
                    case field_1332: {
                        EntityPlayerActionPack ap = ((ServerPlayerInterface) player).getActionPack();
                        if (ap.blockHitDelay > 0)
                        {
                            ap.blockHitDelay--;
                            return false;
                        }
                        class_3965 blockHit = (class_3965) hit;
                        class_2338 pos = blockHit.method_17777();
                        class_2350 side = blockHit.method_17780();
                        if (player.method_21701(player.method_51469(), pos, player.field_13974.method_14257())) return false;
                        if (ap.currentBlock != null && player.method_51469().method_8320(ap.currentBlock).method_26215())
                        {
                            ap.currentBlock = null;
                            return false;
                        }
                        class_2680 state = player.method_51469().method_8320(pos);
                        boolean blockBroken = false;
                        if (player.field_13974.method_14257().method_8386())
                        {
                            player.field_13974.method_14263(pos, class_2846.class_2847.field_12968, side, player.method_51469().method_31600(), -1);
                            ap.blockHitDelay = 5;
                            blockBroken = true;
                        }
                        else  if (ap.currentBlock == null || !ap.currentBlock.equals(pos))
                        {
                            if (ap.currentBlock != null)
                            {
                                player.field_13974.method_14263(ap.currentBlock, class_2846.class_2847.field_12971, side, player.method_51469().method_31600(), -1);
                            }
                            player.field_13974.method_14263(pos, class_2846.class_2847.field_12968, side, player.method_51469().method_31600(), -1);
                            boolean notAir = !state.method_26215();
                            if (notAir && ap.curBlockDamageMP == 0)
                            {
                                state.method_26179(player.method_51469(), pos, player);
                            }
                            if (notAir && state.method_26165(player, player.method_51469(), pos) >= 1)
                            {
                                ap.currentBlock = null;
                                //instamine??
                                blockBroken = true;
                            }
                            else
                            {
                                ap.currentBlock = pos;
                                ap.curBlockDamageMP = 0;
                            }
                        }
                        else
                        {
                            ap.curBlockDamageMP += state.method_26165(player, player.method_51469(), pos);
                            if (ap.curBlockDamageMP >= 1)
                            {
                                player.field_13974.method_14263(pos, class_2846.class_2847.field_12973, side, player.method_51469().method_31600(), -1);
                                ap.currentBlock = null;
                                ap.blockHitDelay = 5;
                                blockBroken = true;
                            }
                            player.method_51469().method_8517(-1, pos, (int) (ap.curBlockDamageMP * 10));

                        }
                        player.method_14234();
                        player.method_6104(class_1268.field_5808);
                        return blockBroken;
                    }
                }
                return false;
            }

            @Override
            void inactiveTick(class_3222 player, Action action)
            {
                EntityPlayerActionPack ap = ((ServerPlayerInterface) player).getActionPack();
                if (ap.currentBlock == null) return;
                player.method_51469().method_8517(-1, ap.currentBlock, -1);
                player.field_13974.method_14263(ap.currentBlock, class_2846.class_2847.field_12971, class_2350.field_11033, player.method_51469().method_31600(), -1);
                ap.currentBlock = null;
            }
        },
        JUMP(true)
        {
            @Override
            boolean execute(class_3222 player, Action action)
            {
                if (action.limit == 1)
                {
                    if (player.method_24828()) player.method_6043(); // onGround
                }
                else
                {
                    player.method_6100(true);
                }
                return false;
            }

            @Override
            void inactiveTick(class_3222 player, Action action)
            {
                player.method_6100(false);
            }
        },
        DROP_ITEM(true)
        {
            @Override
            boolean execute(class_3222 player, Action action)
            {
                player.method_14234();
                player.method_37413(false); // dropSelectedItem
                return false;
            }
        },
        DROP_STACK(true)
        {
            @Override
            boolean execute(class_3222 player, Action action)
            {
                player.method_14234();
                player.method_37413(true); // dropSelectedItem
                return false;
            }
        },
        SWAP_HANDS(true)
        {
            @Override
            boolean execute(class_3222 player, Action action)
            {
                player.method_14234();
                class_1799 itemStack_1 = player.method_5998(class_1268.field_5810);
                player.method_6122(class_1268.field_5810, player.method_5998(class_1268.field_5808));
                player.method_6122(class_1268.field_5808, itemStack_1);
                return false;
            }
        };

        public final boolean preventSpectator;

        ActionType(boolean preventSpectator)
        {
            this.preventSpectator = preventSpectator;
        }

        void start(class_3222 player, Action action) {}
        abstract boolean execute(class_3222 player, Action action);
        void inactiveTick(class_3222 player, Action action) {}
        void stop(class_3222 player, Action action)
        {
            inactiveTick(player, action);
        }
    }

    public static class Action
    {
        public boolean done = false;
        public final int limit;
        public final int interval;
        public final int offset;
        private int count;
        private int next;
        private final boolean isContinuous;

        private Action(int limit, int interval, int offset, boolean continuous)
        {
            this.limit = limit;
            this.interval = interval;
            this.offset = offset;
            next = interval + offset;
            isContinuous = continuous;
        }

        public static Action once()
        {
            return new Action(1, 1, 0, false);
        }

        public static Action continuous()
        {
            return new Action(-1, 1, 0, true);
        }

        public static Action interval(int interval)
        {
            return new Action(-1, interval, 0, false);
        }

        public static Action interval(int interval, int offset)
        {
            return new Action(-1, interval, offset, false);
        }

        Boolean tick(EntityPlayerActionPack actionPack, ActionType type)
        {
            next--;
            Boolean cancel = null;
            if (next <= 0)
            {
                if (interval == 1 && !isContinuous)
                {
                    // need to allow entity to tick, otherwise won't have effect (bow)
                    // actions are 20 tps, so need to clear status mid tick, allowing entities process it till next time
                    if (!type.preventSpectator || !actionPack.player.method_7325())
                    {
                        type.inactiveTick(actionPack.player, this);
                    }
                }

                if (!type.preventSpectator || !actionPack.player.method_7325())
                {
                    cancel = type.execute(actionPack.player, this);
                }
                count++;
                if (count == limit)
                {
                    type.stop(actionPack.player, null);
                    done = true;
                    return cancel;
                }
                next = interval;
            }
            else
            {
                if (!type.preventSpectator || !actionPack.player.method_7325())
                {
                    type.inactiveTick(actionPack.player, this);
                }
            }
            return cancel;
        }

        void retry(EntityPlayerActionPack actionPack, ActionType type)
        {
            //assuming action run but was unsuccesful that tick, but opportunity emerged to retry it, lets retry it.
            if (!type.preventSpectator || !actionPack.player.method_7325())
            {
                type.execute(actionPack.player, this);
            }
            count++;
            if (count == limit)
            {
                type.stop(actionPack.player, null);
                done = true;
            }
        }
    }
}
