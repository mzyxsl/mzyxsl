package carpet.helpers;

import carpet.CarpetServer;
import carpet.script.utils.RecipeHelper;
import carpet.utils.Messenger;
import it.unimi.dsi.fastutil.objects.Object2LongLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2LongMap;
import net.minecraft.class_124;
import net.minecraft.class_1747;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_2185;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4275;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.util.Map.entry;

/**
 * The actual object residing in each hopper counter which makes them count the items and saves them. There is one for each
 * colour in MC.
 */

public class HopperCounter
{
    /**
     * A map of all the {@link HopperCounter} counters.
     */
    private static final Map<class_1767, HopperCounter> COUNTERS;

    /**
     * The default display colour of each item, which makes them look nicer when printing the counter contents to the chat
     */

    public static final class_5251 WHITE = class_5251.method_27718(class_124.field_1068);

    static
    {
        EnumMap<class_1767, HopperCounter> counterMap = new EnumMap<>(class_1767.class);
        for (class_1767 color : class_1767.values())
        {
            counterMap.put(color, new HopperCounter(color));
        }
        COUNTERS = Collections.unmodifiableMap(counterMap);
    }

    /**
     * The counter's colour, determined by the colour of wool it's pointing into
     */
    public final class_1767 color;
    /**
     * The string which is passed into {@link Messenger#m} which makes each counter name be displayed in the colour of
     * that counter.
     */
    private final String coloredName;
    /**
     * All the items stored within the counter, as a map of {@link class_1792} mapped to a {@code long} of the amount of items
     * stored thus far of that item type.
     */
    private final Object2LongMap<class_1792> counter = new Object2LongLinkedOpenHashMap<>();
    /**
     * The starting tick of the counter, used to calculate in-game time. Only initialised when the first item enters the
     * counter
     */
    private long startTick;
    /**
     * The starting millisecond of the counter, used to calculate IRl time. Only initialised when the first item enters
     * the counter
     */
    private long startMillis;
    // private PubSubInfoProvider<Long> pubSubProvider;

    private HopperCounter(class_1767 color)
    {
        startTick = -1;
        this.color = color;
        String hexColor = Integer.toHexString(color.method_16357());
        if (hexColor.length() < 6)
        {
            hexColor = "0".repeat(6 - hexColor.length()) + hexColor;
        }
        this.coloredName = '#' + hexColor + ' ' + color.method_7792();
    }

    /**
     * Method used to add items to the counter. Note that this is when the {@link HopperCounter#startTick} and
     * {@link HopperCounter#startMillis} variables are initialised, so you can place the counters and then start the farm
     * after all the collection is sorted out.
     */
    public void add(MinecraftServer server, class_1799 stack)
    {
        if (startTick < 0)
        {
            startTick = server.method_30002().method_8510();
            startMillis = System.currentTimeMillis();
        }
        class_1792 item = stack.method_7909();
        counter.put(item, counter.getLong(item) + stack.method_7947());
        // pubSubProvider.publish();
    }

    /**
     * Resets the counter, clearing its items but keeping the clock running.
     */
    public void reset(MinecraftServer server)
    {
        counter.clear();
        startTick = server.method_30002().method_8510();
        startMillis = System.currentTimeMillis();
        // pubSubProvider.publish();
    }

    /**
     * Resets all counters, clearing their items.
     *
     * @param fresh Whether or not to start the clocks going immediately or later.
     */
    public static void resetAll(MinecraftServer server, boolean fresh)
    {
        for (HopperCounter counter : COUNTERS.values())
        {
            counter.reset(server);
            if (fresh)
            {
                counter.startTick = -1;
            }
        }
    }

    /**
     * Prints all the counters to chat, nicely formatted, and you can choose whether to diplay in in game time or IRL time
     */
    public static List<class_2561> formatAll(MinecraftServer server, boolean realtime)
    {
        List<class_2561> text = new ArrayList<>();

        for (HopperCounter counter : COUNTERS.values())
        {
            List<class_2561> temp = counter.format(server, realtime, false);
            if (temp.size() > 1)
            {
                if (!text.isEmpty())
                {
                    text.add(Messenger.s(""));
                }
                text.addAll(temp);
            }
        }
        if (text.isEmpty())
        {
            text.add(Messenger.s("No items have been counted yet."));
        }
        return text;
    }

    /**
     * Prints a single counter's contents and timings to chat, with the option to keep it short (so no item breakdown,
     * only rates). Again, realtime displays IRL time as opposed to in game time.
     */
    public List<class_2561> format(MinecraftServer server, boolean realTime, boolean brief)
    {
        long ticks = Math.max(realTime ? (System.currentTimeMillis() - startMillis) / 50 : server.method_30002().method_8510() - startTick, 1);
        if (startTick < 0 || ticks == 0)
        {
            if (brief)
            {
                return Collections.singletonList(Messenger.c("b" + coloredName, "w : ", "gi -, -/h, - min "));
            }
            return Collections.singletonList(Messenger.c(coloredName, "w  hasn't started counting yet"));
        }
        long total = getTotalItems();
        if (total == 0)
        {
            if (brief)
            {
                return Collections.singletonList(Messenger.c("b" + coloredName, "w : ", "wb 0", "w , ", "wb 0", "w /h, ", String.format("wb %.1f ", ticks / (20.0 * 60.0)), "w min"));
            }
            return Collections.singletonList(Messenger.c("w No items for ", coloredName, String.format("w  yet (%.2f min.%s)",
                            ticks / (20.0 * 60.0), (realTime ? " - real time" : "")),
                    "nb  [X]", "^g reset", "!/counter " + color.method_7792() + " reset"));
        }
        if (brief)
        {
            return Collections.singletonList(Messenger.c("b" + coloredName, "w : ",
                    "wb " + total, "w , ",
                    "wb " + (total * (20 * 60 * 60) / ticks), "w /h, ",
                    String.format("wb %.1f ", ticks / (20.0 * 60.0)), "w min"
            ));
        }
        List<class_2561> items = new ArrayList<>();
        items.add(Messenger.c("w Items for ", coloredName,
                "w  (", String.format("wb %.2f", ticks * 1.0 / (20 * 60)), "w  min" + (realTime ? " - real time" : "") + "), ",
                "w total: ", "wb " + total, "w , (", String.format("wb %.1f", total * 1.0 * (20 * 60 * 60) / ticks), "w /h):",
                "nb [X]", "^g reset", "!/counter " + color + " reset"
        ));
        items.addAll(counter.object2LongEntrySet().stream().sorted((e, f) -> Long.compare(f.getLongValue(), e.getLongValue())).map(e ->
        {
            class_1792 item = e.getKey();
            class_5250 itemName = class_2561.method_43471(item.method_7876());
            class_2583 itemStyle = itemName.method_10866();
            class_5251 color = guessColor(item, server.method_30002());
            itemName.method_10862((color != null) ? itemStyle.method_27703(color) : itemStyle.method_10978(true));
            long count = e.getLongValue();
            return Messenger.c("g - ", itemName,
                    "g : ", "wb " + count, "g , ",
                    String.format("wb %.1f", count * (20.0 * 60.0 * 60.0) / ticks), "w /h"
            );
        }).collect(Collectors.toList()));
        return items;
    }

    /**
     * Converts a colour to have a low brightness and uniform colour, so when it prints the items in different colours
     * it's not too flashy and bright, but enough that it's not dull to look at.
     */
    public static int appropriateColor(int color)
    {
        if (color == 0)
        {
            return class_3620.field_16022.field_16011;
        }
        int r = (color >> 16 & 255);
        int g = (color >> 8 & 255);
        int b = (color & 255);
        if (r < 70)
        {
            r = 70;
        }
        if (g < 70)
        {
            g = 70;
        }
        if (b < 70)
        {
            b = 70;
        }
        return (r << 16) + (g << 8) + b;
    }

    /**
     * Maps items that don't get a good block to reference for colour, or those that colour is wrong to a number of blocks, so we can get their colours easily with the
     * {@link class_2248#method_26403()} method as these items have those same colours.
     */
    private static final Map<class_1792, class_2248> DEFAULTS = Map.ofEntries(
            entry(class_1802.field_8491, class_2246.field_10490),
            entry(class_1802.field_8880, class_2246.field_10314),
            entry(class_1802.field_17499, class_2246.field_10294),
            entry(class_1802.field_17500, class_2246.field_10215),
            entry(class_1802.field_17501, class_2246.field_10491),
            entry(class_1802.field_17502, class_2246.field_10314),
            entry(class_1802.field_17509, class_2246.field_10095),
            entry(class_1802.field_17510, class_2246.field_10491),
            entry(class_1802.field_17511, class_2246.field_10459),
            entry(class_1802.field_17512, class_2246.field_10491),
            entry(class_1802.field_17513, class_2246.field_10514),
            entry(class_1802.field_17515, class_2246.field_10146),
            entry(class_1802.field_17514, class_2246.field_10446),
            entry(class_1802.field_17516, class_2246.field_10580),
            entry(class_1802.field_17517, class_2246.field_10240),
            entry(class_1802.field_8600, class_2246.field_10161),
            entry(class_1802.field_8695, class_2246.field_10205),
            entry(class_1802.field_8620, class_2246.field_10085),
            entry(class_1802.field_8477, class_2246.field_10201),
            entry(class_1802.field_22020, class_2246.field_22108),
            entry(class_1802.field_17525, class_2246.field_10490),
            entry(class_1802.field_17526, class_2246.field_10215),
            entry(class_1802.field_17527, class_2246.field_10314),
            entry(class_1802.field_17529, class_2246.field_10459),
            entry(class_1802.field_8179, class_2246.field_10095),
            entry(class_1802.field_8279, class_2246.field_10314),
            entry(class_1802.field_8861, class_2246.field_10359),
            entry(class_1802.field_8389, class_2246.field_10459),
            entry(class_1802.field_8504, class_2246.field_10459),
            entry(class_1802.field_8726, class_2246.field_10611),
            entry(class_1802.field_8046, class_2246.field_10515),
            entry(class_1802.field_8367, class_2246.field_10205),
            entry(class_1802.field_8429, class_2246.field_10611),
            entry(class_1802.field_8209, class_2246.field_10218),
            entry(class_1802.field_8511, class_2246.field_10113),
            entry(class_1802.field_8323, class_2246.field_10143),
            entry(class_1802.field_8846, class_2246.field_10095),
            entry(class_1802.field_8567, class_2246.field_10611),
            entry(class_1802.field_8748, class_2246.field_10314),
            entry(class_1802.field_8186, class_2246.field_10515),
            entry(class_1802.field_8497, class_2246.field_46283),
            entry(class_1802.field_8635, class_2246.field_10030),
            entry(class_1802.field_8680, class_2246.field_10515),
            entry(class_1802.field_8054, class_2246.field_10423),
            entry(class_1802.field_8161, class_2246.field_10028),
            entry(class_1802.field_47830, class_2246.field_22109),
            entry(class_1802.field_8153, class_2246.field_10446),
            entry(class_1802.field_8145, class_2246.field_10146),
            entry(class_1802.field_8745, class_2246.field_9975),
            entry(class_1802.field_8601, class_2246.field_10171),
            entry(class_1802.field_8407, class_2246.field_10446),
            entry(class_1802.field_8621, class_2246.field_10104),
            entry(class_1802.field_8794, class_2246.field_10146),
            entry(class_1802.field_8543, class_2246.field_10491),
            entry(class_1802.field_8705, class_2246.field_10382),
            entry(class_1802.field_8187, class_2246.field_10164),
            entry(class_1802.field_8103, class_2246.field_10446),
            entry(class_1802.field_8696, class_2246.field_10460),
            entry(class_1802.field_8116, class_2246.field_10302),
            entry(class_1802.field_8606, class_2246.field_10166),
            entry(class_1802.field_8666, class_2246.field_10123),
            entry(class_1802.field_8108, class_2246.field_10143),
            entry(class_1802.field_8714, class_2246.field_10444),
            entry(class_1802.field_8478, class_2246.field_10184),
            entry(class_1802.field_8479, class_2246.field_10446),
            entry(class_1802.field_8183, class_2246.field_10205),
            entry(class_1802.field_8634, class_2246.field_22127),
            entry(class_1802.field_8137, class_2246.field_10201),
            entry(class_1802.field_8434, class_2246.field_10174),
            entry(class_1802.field_8662, class_2246.field_10135),
            entry(class_1802.field_8245, class_2246.field_10161),
            entry(class_1802.field_8233, class_2246.field_10286),
            entry(class_1802.field_8815, class_2246.field_10603),
            entry(class_1802.field_8864, class_2246.field_10166),
            entry(class_1802.field_8207, class_2246.field_10502),
            entry(class_1802.field_20414, class_2246.field_21212),
            entry(class_1802.field_8448, class_2246.field_10166),
            entry(class_1802.field_8288, class_2246.field_10143),
            entry(class_1802.field_8547, class_2246.field_10135),
            entry(class_1802.field_8070, class_2246.field_10446),
            entry(class_1802.field_8614, class_2246.field_10166),
            entry(class_1802.field_8803, class_2246.field_10166),
            //entry(Items.,Blocks.),
            entry(class_1802.field_27022, class_2246.field_27119),
            entry(class_1802.field_27063, class_2246.field_27159));

    /**
     * Gets the colour to print an item in when printing its count in a hopper counter.
     */
    public static class_5251 fromItem(class_1792 item, class_5455 registryAccess)
    {
        if (DEFAULTS.containsKey(item))
        {
            return class_5251.method_27717(appropriateColor(DEFAULTS.get(item).method_26403().field_16011));
        }
        if (item instanceof class_1769 dye)
        {
            return class_5251.method_27717(appropriateColor(dye.method_7802().method_7794().field_16011));
        }
        class_2248 block = null;
        final class_2378<class_1792> itemRegistry = registryAccess.method_30530(class_7924.field_41197);
        final class_2378<class_2248> blockRegistry = registryAccess.method_30530(class_7924.field_41254);
        class_2960 id = itemRegistry.method_10221(item);
        if (item instanceof class_1747 blockItem)
        {
            block = blockItem.method_7711();
        }
        else if (blockRegistry.method_17966(id).isPresent())
        {
            block = blockRegistry.method_63535(id);
        }
        if (block != null)
        {
            if (block instanceof class_2185)
            {
                return class_5251.method_27717(appropriateColor(((class_2185) block).method_9303().method_7794().field_16011));
            }
            if (block instanceof class_4275)
            {
                return class_5251.method_27717(appropriateColor(((class_4275) block).method_10622().method_7794().field_16011));
            }
            return class_5251.method_27717(appropriateColor(block.method_26403().field_16011));
        }
        return null;
    }

    /**
     * Guesses the item's colour from the item itself. It first calls {@link HopperCounter#fromItem} to see if it has a
     * valid colour there, if not just makes a guess, and if that fails just returns null
     */
    public static class_5251 guessColor(class_1792 item, class_1937 level)
    {
        class_5455 registryAccess = level.method_30349();
        class_5251 direct = fromItem(item, registryAccess);
        if (direct != null)
        {
            return direct;
        }
        if (CarpetServer.minecraft_server == null)
        {
            return WHITE;
        }

        class_2960 id = registryAccess.method_30530(class_7924.field_41197).method_10221(item);
        if (id == null)
        {
            return null;
        }

        for (class_1860<?> r : RecipeHelper.getRecipesForOutput(CarpetServer.minecraft_server.method_3772(), id, level))
        {
            for (class_1856 ingredient : r.method_61671().method_64675())
            {
                Optional<class_6880<class_1792>> match = ingredient.method_8105().filter(stack -> fromItem(stack.comp_349(), registryAccess) != null).findFirst();
                if (match.isPresent())
                {
                    return fromItem(match.get().comp_349(), registryAccess);
                }
            }
        }

        return null;
    }

    /**
     * Returns the hopper counter for the given color
     */
    public static HopperCounter getCounter(class_1767 color)
    {
        return COUNTERS.get(color);
    }

    /**
     * Returns the hopper counter from the colour name, if not null
     */
    public static HopperCounter getCounter(String color)
    {
        try
        {
            class_1767 colorEnum = class_1767.valueOf(color.toUpperCase(Locale.ROOT));
            return COUNTERS.get(colorEnum);
        }
        catch (IllegalArgumentException e)
        {
            return null;
        }
    }

    /**
     * The total number of items in the counter
     */
    public long getTotalItems()
    {
        return counter.isEmpty() ? 0 : counter.values().longStream().sum();
    }
}
