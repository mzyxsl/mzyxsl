package carpet.helpers;
//Author: masa

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1927;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import carpet.logging.logHelpers.ExplosionLogHelper;
import carpet.mixins.ExplosionAccessor;
import carpet.CarpetSettings;
import it.unimi.dsi.fastutil.objects.Object2DoubleOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import org.apache.commons.lang3.tuple.Pair;

public class OptimizedExplosion
{
    // masa's optimizations
    private static Object2DoubleOpenHashMap<Pair<class_243, class_238>> densityCache = new Object2DoubleOpenHashMap<>();
    private static Object2ObjectOpenHashMap<class_2338, class_2680> stateCache = new Object2ObjectOpenHashMap<>();
    private static Object2ObjectOpenHashMap<class_2338, class_3610> fluidCache = new Object2ObjectOpenHashMap<>();
    private static class_2338.class_2339 posMutable = new class_2338.class_2339(0, 0, 0);
    private static ObjectOpenHashSet<class_2338> affectedBlockPositionsSet = new ObjectOpenHashSet<>();
    private static boolean firstRay;
    private static boolean rayCalcDone;

    public static List<class_2338> doExplosionA(class_1927 e, ExplosionLogHelper eLogger) {
        ExplosionAccessor eAccess = (ExplosionAccessor) e;

        List<class_2338> toBlow;

        if (!CarpetSettings.explosionNoBlockDamage && eAccess.getDamageSource() != null) {
            rayCalcDone = false;
            firstRay = true;
            getAffectedPositionsOnPlaneY(e,  0,  0, 15,  0, 15); // bottom
            getAffectedPositionsOnPlaneY(e, 15,  0, 15,  0, 15); // top
            getAffectedPositionsOnPlaneX(e,  0,  1, 14,  0, 15); // west
            getAffectedPositionsOnPlaneX(e, 15,  1, 14,  0, 15); // east
            getAffectedPositionsOnPlaneZ(e,  0,  1, 14,  1, 14); // north
            getAffectedPositionsOnPlaneZ(e, 15,  1, 14,  1, 14); // south
            stateCache.clear();
            fluidCache.clear();

            toBlow = new ArrayList<>(affectedBlockPositionsSet);
            affectedBlockPositionsSet.clear();
        } else {
            toBlow = Collections.emptyList();
        }
        densityCache.clear();

        return toBlow;
    }

    private static void getAffectedPositionsOnPlaneX(class_1927 e, int x, int yStart, int yEnd, int zStart, int zEnd)
    {
        if (!rayCalcDone)
        {
            final double xRel = (double) x / 15.0D * 2.0D - 1.0D;

            for (int z = zStart; z <= zEnd; ++z)
            {
                double zRel = (double) z / 15.0D * 2.0D - 1.0D;

                for (int y = yStart; y <= yEnd; ++y)
                {
                    double yRel = (double) y / 15.0D * 2.0D - 1.0D;

                    if (checkAffectedPosition(e, xRel, yRel, zRel))
                    {
                        return;
                    }
                }
            }
        }
    }

    private static void getAffectedPositionsOnPlaneY(class_1927 e, int y, int xStart, int xEnd, int zStart, int zEnd)
    {
        if (!rayCalcDone)
        {
            final double yRel = (double) y / 15.0D * 2.0D - 1.0D;

            for (int z = zStart; z <= zEnd; ++z)
            {
                double zRel = (double) z / 15.0D * 2.0D - 1.0D;

                for (int x = xStart; x <= xEnd; ++x)
                {
                    double xRel = (double) x / 15.0D * 2.0D - 1.0D;

                    if (checkAffectedPosition(e, xRel, yRel, zRel))
                    {
                        return;
                    }
                }
            }
        }
    }

    private static void getAffectedPositionsOnPlaneZ(class_1927 e, int z, int xStart, int xEnd, int yStart, int yEnd)
    {
        if (!rayCalcDone)
        {
            final double zRel = (double) z / 15.0D * 2.0D - 1.0D;

            for (int x = xStart; x <= xEnd; ++x)
            {
                double xRel = (double) x / 15.0D * 2.0D - 1.0D;

                for (int y = yStart; y <= yEnd; ++y)
                {
                    double yRel = (double) y / 15.0D * 2.0D - 1.0D;

                    if (checkAffectedPosition(e, xRel, yRel, zRel))
                    {
                        return;
                    }
                }
            }
        }
    }

    private static boolean checkAffectedPosition(class_1927 e, double xRel, double yRel, double zRel)
    {
        ExplosionAccessor eAccess = (ExplosionAccessor) e;
        double len = Math.sqrt(xRel * xRel + yRel * yRel + zRel * zRel);
        double xInc = (xRel / len) * 0.3;
        double yInc = (yRel / len) * 0.3;
        double zInc = (zRel / len) * 0.3;
        float rand = eAccess.getLevel().field_9229.method_43057();
        float sizeRand = (CarpetSettings.tntRandomRange >= 0 ? (float) CarpetSettings.tntRandomRange : rand);
        float size = eAccess.getRadius() * (0.7F + sizeRand * 0.6F);
        class_243 vec3 = eAccess.getCenter();
        double posX = vec3.field_1352;
        double posY = vec3.field_1351;
        double posZ = vec3.field_1350;

        for (float f1 = 0.3F; size > 0.0F; size -= 0.22500001F)
        {
            posMutable.method_10102(posX, posY, posZ);

            // Don't query already cached positions again from the world
            class_2680 state = stateCache.get(posMutable);
            class_3610 fluid = fluidCache.get(posMutable);
            class_2338 posImmutable = null;

            if (state == null)
            {
                posImmutable = posMutable.method_10062();
                state = eAccess.getLevel().method_8320(posImmutable);
                stateCache.put(posImmutable, state);
                fluid = eAccess.getLevel().method_8316(posImmutable);
                fluidCache.put(posImmutable, fluid);
            }

            if (!state.method_26215())
            {
                float resistance = Math.max(state.method_26204().method_9520(), fluid.method_15760());

                if (eAccess.getSource() != null)
                {
                    resistance = eAccess.getSource().method_5774(e, eAccess.getLevel(), posMutable, state, fluid, resistance);
                }

                size -= (resistance + 0.3F) * 0.3F;
            }

            if (size > 0.0F)
            {
                if ((eAccess.getSource() == null || eAccess.getSource().method_5853(e, eAccess.getLevel(), posMutable, state, size)))
                    affectedBlockPositionsSet.add(posImmutable != null ? posImmutable : posMutable.method_10062());
            }
            else if (firstRay)
            {
                rayCalcDone = true;
                return true;
            }

            firstRay = false;

            posX += xInc;
            posY += yInc;
            posZ += zInc;
        }

        return false;
    }
}
